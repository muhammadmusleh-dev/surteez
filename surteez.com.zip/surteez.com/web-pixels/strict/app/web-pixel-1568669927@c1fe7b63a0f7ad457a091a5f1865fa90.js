(() => {
    var ft = Object.create;
    var kt = Object.defineProperty;
    var Et = Object.getOwnPropertyDescriptor;
    var Nt = Object.getOwnPropertyNames;
    var wt = Object.getPrototypeOf,
        At = Object.prototype.hasOwnProperty;
    var k = (c, e) => () => (c && (e = c(c = 0)), e);
    var Tt = (c, e) => () => (e || c((e = {
        exports: {}
    }).exports, e), e.exports);
    var Ot = (c, e, n, l) => {
        if (e && typeof e == "object" || typeof e == "function")
            for (let i of Nt(e)) !At.call(c, i) && i !== n && kt(c, i, {
                get: () => e[i],
                enumerable: !(l = Et(e, i)) || l.enumerable
            });
        return c
    };
    var qt = (c, e, n) => (n = c != null ? ft(wt(c)) : {}, Ot(e || !c || !c.__esModule ? kt(n, "default", {
        value: c,
        enumerable: !0
    }) : n, c));
    var h = (c, e, n) => new Promise((l, i) => {
        var _ = u => {
                try {
                    r(n.next(u))
                } catch (t) {
                    i(t)
                }
            },
            b = u => {
                try {
                    r(n.throw(u))
                } catch (t) {
                    i(t)
                }
            },
            r = u => u.done ? l(u.value) : Promise.resolve(u.value).then(_, b);
        r((n = n.apply(c, e)).next())
    });
    var vt, mt = k(() => {
        vt = "WebPixel::Render"
    });
    var v, St = k(() => {
        mt();
        v = c => shopify.extend(vt, c)
    });
    var xt = k(() => {
        St()
    });
    var Pt = k(() => {
        xt()
    });
    var It = Tt(g => {
        Pt();
        v(({
            configuration: c,
            analytics: e,
            browser: n,
            settings: l,
            init: i
        }) => {
            if (!l.shopId) {
                console.error("Triple Pixel wasn't Initialized. Triple Pixel stops executing!");
                return
            }
            let _ = {
                TripleName: l.shopId,
                ver: "2.16",
                plat: "SHOPIFY",
                isHeadless: !1,
                src: "SHOPIFY_EXT"
            };

            function b(t, o, a, s, d) {
                d === void 0 && (d = !1), s = new XMLHttpRequest, a ? (s.open("POST", t, !0), s.setRequestHeader("Content-Type", "application/json")) : s.open("GET", t, !0), s.send(JSON.stringify(a || {})), s.onreadystatechange = function() {
                    s.readyState === 4 && s.status === 200 ? d = s.responseText : (299 < s.status || s.status < 200) && o && !d && (d = !0, b(t, o - 1, a))
                }
            }
            e.subscribe("page_viewed", t => {
                u(t, "page_viewed")
            }), e.subscribe("product_viewed", t => {
                u(t, "product_viewed")
            }), e.subscribe("collection_viewed", t => {
                u(t, "collection_viewed")
            }), e.subscribe("product_added_to_cart", t => {
                u(t, "product_added_to_cart")
            }), e.subscribe("search_submitted", t => {
                u(t, "search_submitted")
            }), e.subscribe("checkout_started", t => h(null, null, function*() {
                var o;
                r(t, "config1", (o = i.data) == null ? void 0 : o.customer)
            })), e.subscribe("payment_info_submitted", t => h(null, null, function*() {
                var o;
                r(t, "config2", (o = i.data) == null ? void 0 : o.customer)
            })), e.subscribe("checkout_completed", t => h(null, null, function*() {
                var o;
                r(t, "config3", (o = i.data) == null ? void 0 : o.customer)
            })), e.subscribe("checkout_address_info_submitted", t => h(null, null, function*() {
                var o;
                r(t, "config4", (o = i.data) == null ? void 0 : o.customer)
            })), e.subscribe("checkout_contact_info_submitted", t => h(null, null, function*() {
                var o;
                r(t, "config5", (o = i.data) == null ? void 0 : o.customer)
            })), e.subscribe("checkout_shipping_info_submitted", t => h(null, null, function*() {
                var o;
                r(t, "config6", (o = i.data) == null ? void 0 : o.customer)
            }));

            function r(t, o, a) {
                return h(this, null, function*() {
                    var m, S, x, P, I, y, C, f, E, N, w, A, T, O, q, L, X, G, z, D, F, J, W, M, V, Y, Z, j, $, B, K, Q, R, U, H, tt, et, ot, ct, it, dt, at, nt, st, ut, rt, pt, ht, lt;
                    (S = (m = t.context.window.location) == null ? void 0 : m.href) != null && S.includes("fw_debug_params") && console.log("000");
                    let s = t.context.window[atob("c2NyZWVu")],
                        d = ((x = i == null ? void 0 : i.context) == null ? void 0 : x.navigator) || {},
                        yt = (d == null ? void 0 : d.language) || (d == null ? void 0 : d.browserLanguage) || (d == null ? void 0 : d.userLanguage) || (d == null ? void 0 : d.systemLanguage),
                        Ct = {
                            id: Date.now().toString(36) + "_" + Math.random().toString(36),
                            add_eid: t.id,
                            action: o,
                            avatar: yield n.localStorage.getItem("true_rand_gen_sequence.dat_"), avatar2: yield n.localStorage.getItem("true_rand_gen_sequence.dat_tmp"), time: s[atob("d2lkdGg=")] + ":" + s[atob("aGVpZ2h0")], host: _.TripleName, plat: _.plat, url: (P = t.context.window.location) == null ? void 0 : P.href, ref: (I = t.context.document) == null ? void 0 : I.referrer, title: (y = t.context.document) == null ? void 0 : y.title, ver: _.ver, email: ((C = t.data.checkout) == null ? void 0 : C.email) || (a == null ? void 0 : a.email) || ((E = (f = t.data.checkout) == null ? void 0 : f.shippingAddress) == null ? void 0 : E.email) || ((w = (N = t.data.checkout) == null ? void 0 : N.billingAddress) == null ? void 0 : w.email), phone: ((A = t.data.checkout) == null ? void 0 : A.phone) || (a == null ? void 0 : a.phone) || ((O = (T = t.data.checkout) == null ? void 0 : T.shippingAddress) == null ? void 0 : O.phone) || ((L = (q = t.data.checkout) == null ? void 0 : q.billingAddress) == null ? void 0 : L.phone), token: (X = t.data.checkout) == null ? void 0 : X.token, orderId: (z = (G = t.data.checkout) == null ? void 0 : G.order) == null ? void 0 : z.id, firstName: (a == null ? void 0 : a.firstName) || ((J = (F = (D = t.data.checkout) == null ? void 0 : D.order) == null ? void 0 : F.customer) == null ? void 0 : J.firstName) || ((M = (W = t.data.checkout) == null ? void 0 : W.shippingAddress) == null ? void 0 : M.firstName), lastName: (a == null ? void 0 : a.lastName) || ((Z = (Y = (V = t.data.checkout) == null ? void 0 : V.order) == null ? void 0 : Y.customer) == null ? void 0 : Z.lastName) || (($ = (j = t.data.checkout) == null ? void 0 : j.shippingAddress) == null ? void 0 : $.lastName), province_code: (K = (B = t.data.checkout) == null ? void 0 : B.shippingAddress) == null ? void 0 : K.provinceCode, country_code: ((Q = t.data.checkout) == null ? void 0 : Q.country_code) || ((U = (R = t.data.checkout) == null ? void 0 : R.shippingAddress) == null ? void 0 : U.country_code) || ((tt = (H = t.data.checkout) == null ? void 0 : H.billingAddress) == null ? void 0 : tt.country_code), city: (ot = (et = t.data.checkout) == null ? void 0 : et.shippingAddress) == null ? void 0 : ot.city, zip: (it = (ct = t.data.checkout) == null ? void 0 : ct.shippingAddress) == null ? void 0 : it.zip, i: (at = (dt = t.data.checkout) == null ? void 0 : dt.lineItems) == null ? void 0 : at.map(p => {
                                var gt, _t, bt;
                                return {
                                    i: (_t = (gt = p.variant) == null ? void 0 : gt.product) == null ? void 0 : _t.id,
                                    v: (bt = p.variant) == null ? void 0 : bt.id,
                                    q: p.quantity,
                                    p: p.finalLinePrice
                                }
                            }), v: (st = (nt = t.data.checkout) == null ? void 0 : nt.subtotalPrice) == null ? void 0 : st.amount, cur: (rt = (ut = t.data.checkout) == null ? void 0 : ut.subtotalPrice) == null ? void 0 : rt.currencyCode, os_lang: JSON.stringify([yt]), discount_v: (pt = t.data.checkout.discountsAmount) == null ? void 0 : pt.amount, disc_c: (ht = t.data.checkout.discountApplications) == null ? void 0 : ht.map(p => p.title), notes: (lt = t.data.checkout.attributes) == null ? void 0 : lt.map(p => ({
                                k: p.key,
                                v: p.value
                            }))
                        };
                    b("https://api.config-security.com/event", 5, Ct)
                })
            }

            function u(t, o) {
                return h(this, null, function*() {
                    l.shopId == "madisonbraids.myshopify.com" && (yield n.localStorage.setItem(`TW_EXT_${o}`, JSON.stringify({
                        i: t.id,
                        t: Date.now()
                    })))
                })
            }
        })
    });
    var Kt = qt(It());
})();