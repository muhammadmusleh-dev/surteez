(() => {
    var y = Object.defineProperty,
        l = Object.defineProperties;
    var f = Object.getOwnPropertyDescriptors;
    var i = Object.getOwnPropertySymbols;
    var T = Object.prototype.hasOwnProperty,
        x = Object.prototype.propertyIsEnumerable;
    var n = (o, e, t) => e in o ? y(o, e, {
            enumerable: !0,
            configurable: !0,
            writable: !0,
            value: t
        }) : o[e] = t,
        a = (o, e) => {
            for (var t in e || (e = {})) T.call(e, t) && n(o, t, e[t]);
            if (i)
                for (var t of i(e)) x.call(e, t) && n(o, t, e[t]);
            return o
        },
        m = (o, e) => l(o, f(e));
    var d = "WebPixel::Render";
    var r = o => shopify.extend(d, o);
    r(({
        analytics: o,
        init: e
    }) => {
        var p, s;
        let t = (s = (p = e == null ? void 0 : e.data) == null ? void 0 : p.shop) == null ? void 0 : s.myshopifyDomain;
        o.subscribe("product_viewed", c => {
            fetch("https://bundlesuiteapp.simplesuiteapps.com/api/analytics", {
                method: "POST",
                credentials: "include",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(m(a({}, c), {
                    myshopifyDomain: t
                }))
            })
        })
    });
})();