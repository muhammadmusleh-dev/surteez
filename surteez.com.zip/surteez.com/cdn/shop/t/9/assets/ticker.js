! function() {
    "use strict";
    customElements.get("ticker-bar") || customElements.define("ticker-bar", class extends HTMLElement {
        constructor() {
            super(), this.resizeEvent = window.theme.debounce((() => this.checkWidth()), 100)
        }
        connectedCallback() {
            this.autoplay = this.hasAttribute("data-autoplay"), this.scale = this.querySelector("[data-ticker-scale]"), this.text = this.querySelector("[data-ticker-text]"), this.comparitor = this.text.cloneNode(!0), this.comparitor.classList.add("ticker__comparitor"), this.appendChild(this.comparitor), this.scale.classList.remove("ticker--unloaded"), document.addEventListener("theme:resize:width", this.resizeEvent), this.checkWidth()
        }
        checkWidth() {
            const t = 2 * window.getComputedStyle(this).paddingLeft.replace("px", "");
            if (this.clientWidth - t < this.comparitor.clientWidth || this.autoplay) {
                if (1 === this.scale.childElementCount) {
                    if (this.text.classList.add("ticker--animated"), this.clone = this.text.cloneNode(!0), this.clone.setAttribute("data-clone", ""), this.scale.appendChild(this.clone), this.autoplay)
                        for (let t = 0; t < 10; t++) {
                            const t = this.text.cloneNode(!0);
                            t.setAttribute("data-clone", ""), this.scale.appendChild(t)
                        }
                    let t = this.getAttribute("data-marquee-speed");
                    null === t && (t = 100);
                    const e = 100,
                        i = 1.63 * (100 / parseInt(t, 10)),
                        s = this.text.clientWidth / e * i;
                    this.scale.style.setProperty("--animation-time", `${s}s`), this.tickerAnimationPause()
                }
            } else {
                this.text.classList.add("ticker--animated");
                this.scale.querySelectorAll("[data-clone]").forEach((t => t.parentNode.removeChild(t))), this.text.classList.remove("ticker--animated")
            }
        }
        tickerAnimationPause() {
            let t = 0,
                e = !1;
            this.addEventListener("mouseenter", (() => {
                e = !0, t = setTimeout((() => {
                    e && this.querySelectorAll("[data-ticker-text]").forEach((t => {
                        t.style.animationPlayState = "paused"
                    })), clearTimeout(t)
                }), 500)
            })), this.addEventListener("mouseleave", (() => {
                e = !1, this.querySelectorAll("[data-ticker-text]").forEach((t => {
                    t.style.animationPlayState = "running"
                }))
            }))
        }
        disconnectedCallback() {
            document.removeEventListener("theme:resize:width", this.resizeEvent)
        }
    })
}();