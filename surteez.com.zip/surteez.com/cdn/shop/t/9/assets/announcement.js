! function() {
    "use strict";
    customElements.get("announcement-bar") || customElements.define("announcement-bar", class extends HTMLElement {
        constructor() {
            super(), this.barHolder = this, this.locationPath = location.href, this.slides = this.barHolder.querySelectorAll("[data-slide]"), this.slider = this.barHolder.querySelector("[data-slider]"), this.static = this.barHolder.querySelector("[data-static]"), this.parallax = this.barHolder.querySelector("[data-parallax-animation]"), this.flkty = null
        }
        connectedCallback() {
            this.removeAnnouncement(), this.checkSlidesClasses(), this.slider && (this.initSlider(), document.addEventListener("theme:resize:width", this.initSlider.bind(this))), this.updateSVGClipPathIDs()
        }
        removeAnnouncement() {
            for (let e = 0; e < this.slides.length; e++) {
                const t = this.slides[e];
                t.hasAttribute("data-target-referrer") && (-1 !== this.locationPath.indexOf(t.getAttribute("data-target-referrer")) || window.Shopify.designMode || t.parentNode.removeChild(t))
            }
        }
        checkSlidesClasses() {
            if (0 !== this.slides.length) {
                const e = this.barHolder.querySelectorAll("[data-slide].mobile"),
                    t = this.barHolder.querySelectorAll("[data-slide].desktop");
                this.slides.length === e.length ? this.barHolder.parentNode.classList.add("mobile") : this.slides.length === t.length && this.barHolder.parentNode.classList.add("desktop")
            }
        }
        initSlider() {
            const e = this.slider.querySelectorAll("[data-slide]"),
                t = this.slider.hasAttribute("data-slider-arrows");
            if (e) {
                let e = "[data-slide]";
                e = window.innerWidth < theme.sizes.small ? "[data-slide]:not(.desktop)" : "[data-slide]:not(.mobile)", null != this.flkty && this.flkty.destroy(), this.flkty = new window.theme.Flickity(this.slider, {
                    cellSelector: e,
                    pageDots: !1,
                    prevNextButtons: t,
                    wrapAround: !0,
                    autoPlay: parseInt(this.slider.getAttribute("data-slider-speed"), 10),
                    on: {
                        ready: () => {
                            setTimeout((() => this.refresh()), 10)
                        },
                        change: e => {
                            this.flkty.cells.forEach(((t, i) => {
                                t.element.querySelectorAll("text-highlight").forEach((t => {
                                    t.setTriggerAttribute(Boolean(i === e))
                                }))
                            }))
                        }
                    }
                }), this.flkty.reposition()
            }
        }
        refresh() {
            this.querySelectorAll("ticker-bar") ? .forEach((e => {
                "function" == typeof e.resizeEvent && e.resizeEvent()
            })), this.updateSVGClipPathIDs()
        }
        updateSVGClipPathIDs() {
            this.barHolder.querySelectorAll("[data-slide]").forEach(((e, t) => {
                const i = e.querySelector("clipPath");
                if (i) {
                    const s = `${i.id}_${t}`;
                    i.id = s;
                    const l = e.querySelector("g[clip-path]");
                    l && l.setAttribute("clip-path", `url(#${s})`)
                }
            }))
        }
        disconnectedCallback() {
            document.removeEventListener("theme:resize:width", this.initSlider.bind(this))
        }
    })
}();