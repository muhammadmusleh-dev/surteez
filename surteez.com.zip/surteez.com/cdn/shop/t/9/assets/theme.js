/*
 * @license
 * Palo Alto Theme (c)
 *
 * The contents of this file should not be modified.
 * add any minor changes to assets/custom.js
 *
 */
! function(t) {
    "use strict";
    ! function() {
        const t = {
            NODE_ENV: "production"
        };
        try {
            if (process) return process.env = Object.assign({}, process.env), void Object.assign(process.env, t)
        } catch (t) {}
        globalThis.process = {
            env: t
        }
    }(), window.theme = window.theme || {}, window.theme.sizes = {
        mobile: 480,
        small: 768,
        large: 1024,
        widescreen: 1440
    }, window.theme.keyboardKeys = {
        TAB: "Tab",
        ENTER: "Enter",
        NUMPADENTER: "NumpadEnter",
        ESCAPE: "Escape",
        SPACE: "Space",
        LEFTARROW: "ArrowLeft",
        RIGHTARROW: "ArrowRight"
    }, window.theme.focusable = 'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])', window.theme.getWindowWidth = function() {
        return window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth
    }, window.theme.getWindowHeight = function() {
        return window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight
    }, window.theme.isDesktop = function() {
        return window.theme.getWindowWidth() >= window.theme.sizes.small
    }, window.theme.isMobile = function() {
        return window.theme.getWindowWidth() < window.theme.sizes.small
    };
    window.theme.PUB_SUB_EVENTS = {
        cartUpdate: "cart-update",
        quantityUpdate: "quantity-update",
        optionValueSelectionChange: "option-value-selection-change",
        variantChange: "variant-change",
        cartError: "cart-error"
    };
    window.theme.formatMoney = function(t, e) {
        "string" == typeof t && (t = t.replace(".", ""));
        let i = "";
        const s = /\{\{\s*(\w+)\s*\}\}/,
            o = e || "${{amount}}";

        function n(t, e = 2, i = ",", s = ".") {
            if (isNaN(t) || null == t) return 0;
            const o = (t = (t / 100).toFixed(e)).split(".");
            return o[0].replace(/(\d)(?=(\d\d\d)+(?!\d))/g, `$1${i}`) + (o[1] ? s + o[1] : "")
        }
        switch (o.match(s)[1]) {
            case "amount":
                i = n(t, 2);
                break;
            case "amount_no_decimals":
                i = n(t, 0);
                break;
            case "amount_with_comma_separator":
                i = n(t, 2, ".", ",");
                break;
            case "amount_no_decimals_with_comma_separator":
                i = n(t, 0, ".", ",");
                break;
            case "amount_with_apostrophe_separator":
                i = n(t, 2, "'", ".");
                break;
            case "amount_no_decimals_with_space_separator":
                i = n(t, 0, " ", "");
                break;
            case "amount_with_space_separator":
                i = n(t, 2, " ", ",");
                break;
            case "amount_with_period_and_space_separator":
                i = n(t, 2, " ", ".")
        }
        return o.replace(s, i)
    }, window.theme.debounce = function(t, e) {
        let i;
        return function() {
            if (t) {
                const s = () => t.apply(this, arguments);
                clearTimeout(i), i = setTimeout(s, e)
            }
        }
    };
    const e = {
            body: "body",
            main: "[data-main]",
            collectionFilters: "[data-collection-filters]",
            footer: '[data-section-type*="footer"]',
            header: "[data-header-height]",
            stickyHeader: '[data-site-header][data-position="fixed"]',
            announcementBar: "[data-announcement-bar]",
            collectionStickyBar: "[data-collection-sticky-bar]",
            logoTextLink: "[data-logo-text-link]"
        },
        i = {
            templateCollection: "template-collection",
            templateSearch: "template-search",
            supportsTransparentHeader: "supports-transparent-header"
        };
    window.theme.getScreenOrientation = function() {
        return window.matchMedia("(orientation: portrait)").matches ? "portrait" : window.matchMedia("(orientation: landscape)").matches ? "landscape" : void 0
    };
    let s = window.theme.getScreenOrientation();

    function o() {
        document.addEventListener("theme:resize", n), window.theme.setVars(), document.dispatchEvent(new CustomEvent("theme:vars"), {
            bubbles: !1
        })
    }

    function n() {
        a(!0)
    }

    function a(t = !1) {
        const o = document.querySelector(e.body),
            n = document.querySelector(e.collectionFilters),
            a = null !== document.querySelector(e.logoTextLink);
        let {
            windowHeight: r,
            headerHeight: c,
            headerInitialHeight: d,
            announcementBarHeight: h,
            footerHeight: u,
            collectionStickyBarHeight: p
        } = window.theme.readHeights();
        a && (c = function() {
            document.documentElement.style.setProperty("--header-height", "auto"), document.documentElement.style.setProperty("--header-sticky-height", "auto");
            const t = document.querySelector(e.header).offsetHeight;
            return requestAnimationFrame((() => {
                document.documentElement.style.setProperty("--header-height", `${t}px`), document.documentElement.style.setProperty("--header-sticky-height", `${t}px`)
            })), t
        }());
        const m = window.isHeaderTransparent && document.querySelector(e.main).firstElementChild.classList.contains(i.supportsTransparentHeader) ? r - h : r - d - h;
        let g = l() ? r - window.stickyHeaderHeight : r;
        const v = o.classList.contains(i.templateCollection),
            b = o.classList.contains(i.templateSearch),
            w = v && n || b && n;
        if (document.documentElement.style.setProperty("--footer-height", `${u}px`), document.documentElement.style.setProperty("--content-full", `${m}px`), document.documentElement.style.setProperty("--content-min", r - c - u + "px"), document.documentElement.style.setProperty("--collection-sticky-bar-height", `${p}px`), w && (g = r), !t) return void document.documentElement.style.setProperty("--full-height", `${g}px`);
        const y = window.theme.getScreenOrientation();
        y !== s && (document.documentElement.style.setProperty("--full-height", `${g}px`), s = y)
    }

    function r(t) {
        const e = document.querySelector(t);
        return e ? (e.hasAttribute("data-collection-sticky-bar") && document.documentElement.style.setProperty("--collection-sticky-bar-height", "auto"), e.clientHeight) : 0
    }

    function l() {
        return document.querySelector(e.stickyHeader)
    }
    window.theme.readHeights = function() {
        var t, i;
        const s = {};
        return s.windowHeight = Math.min(window.screen.height, window.innerHeight), s.footerHeight = r(e.footer), s.headerHeight = r(e.header), s.stickyHeaderHeight = l() ? window.stickyHeaderHeight : 0, s.headerInitialHeight = parseInt((null === (t = document.querySelector(e.header)) || void 0 === t ? void 0 : t.dataset.height) || (null === (i = document.querySelector(e.header)) || void 0 === i ? void 0 : i.offsetHeight)) || 0, s.announcementBarHeight = r(e.announcementBar), s.collectionStickyBarHeight = r(e.collectionStickyBar), s
    }, window.theme.setVars = function() {
        a()
    }, window.addEventListener("DOMContentLoaded", o), document.addEventListener("shopify:section:load", o);
    let c = {};
    window.publish = function(t, e) {
        if (c[t]) {
            const i = c[t].map((t => t(e)));
            return Promise.all(i)
        }
        return Promise.resolve()
    }, window.subscribe = function(t, e) {
        return void 0 === c[t] && (c[t] = []), c[t] = [...c[t], e],
            function() {
                c[t] = c[t].filter((t => t !== e))
            }
    }, window.theme.scrollTo = t => {
        const {
            stickyHeaderHeight: e
        } = window.theme.readHeights();
        window.scrollTo({
            top: t + Math.round(window.scrollY) - e,
            left: 0,
            behavior: "smooth"
        })
    };
    const d = {
        state: {
            firstFocusable: null,
            lastFocusable: null,
            trigger: null,
            mainTrigger: null
        },
        trapFocus: function(t) {
            var e = Array.from(t.container.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex^="-"])')).filter((function(t) {
                var e = t.offsetWidth,
                    i = t.offsetHeight;
                return 0 !== e && 0 !== i && "none" !== getComputedStyle(t).getPropertyValue("display")
            }));
            e = e.filter((function(t) {
                return !t.classList.contains("deferred-media__poster")
            })), this.state.firstFocusable = e[0], this.state.lastFocusable = e[e.length - 1], t.elementToFocus || (t.elementToFocus = this.state.firstFocusable || t.container), this._setupHandlers(), document.addEventListener("focusin", this._onFocusInHandler), document.addEventListener("focusout", this._onFocusOutHandler), t.container.setAttribute("tabindex", "-1"), t.elementToFocus.focus()
        },
        removeTrapFocus: function(t) {
            const e = !document.body.classList.contains("no-outline");
            t && t.container && t.container.removeAttribute("tabindex"), document.removeEventListener("focusin", this._onFocusInHandler), this.state.trigger && e && this.state.trigger.focus()
        },
        _manageFocus: function(t) {
            t.code === theme.keyboardKeys.TAB && (t.target !== this.state.lastFocusable || t.shiftKey || (t.preventDefault(), this.state.firstFocusable.focus()), t.target === this.state.firstFocusable && t.shiftKey && (t.preventDefault(), this.state.lastFocusable.focus()))
        },
        _onFocusOut: function() {
            document.removeEventListener("keydown", this._manageFocusHandler)
        },
        _onFocusIn: function(t) {
            t.target !== this.state.lastFocusable && t.target !== this.state.firstFocusable || document.addEventListener("keydown", this._manageFocusHandler)
        },
        _setupHandlers: function() {
            this._onFocusInHandler || (this._onFocusInHandler = this._onFocusIn.bind(this)), this._onFocusOutHandler || (this._onFocusOutHandler = this._onFocusIn.bind(this)), this._manageFocusHandler || (this._manageFocusHandler = this._manageFocus.bind(this))
        }
    };
    window.theme = window.theme || {}, window.theme.a11y = d, window.theme.throttle = (t, e) => {
        let i, s;
        return function o(...n) {
            const a = Date.now();
            s = clearTimeout(s), !i || a - i >= e ? (t.apply(null, n), i = a) : s = setTimeout(o.bind(null, ...n), e - (a - i))
        }
    }, window.theme.wrap = (t, e = "", i) => {
        const s = i || document.createElement("div");
        return s.classList.add(e), s.setAttribute("data-scroll-lock-scrollable", ""), t.parentNode.insertBefore(s, t), s.appendChild(t)
    }, window.theme.wrapElements = function(t) {
        t.querySelectorAll("table").forEach((t => {
            window.theme.wrap(t, "table-wrapper")
        }))
    }, window.addEventListener("DOMContentLoaded", window.theme.wrapElements(document)), document.addEventListener("shopify:section:load", (t => window.theme.wrapElements(t.target)));
    window.HTMLUpdateUtility = class t {
        static viewTransition(e, i, s = [], o = []) {
            null == s || s.forEach((t => t(i)));
            const n = document.createElement("div");
            t.setInnerHTML(n, i.outerHTML);
            const a = n.firstChild,
                r = Date.now();
            e.querySelectorAll("[id], [form]").forEach((t => {
                t.id && (t.id = `${t.id}-${r}`), t.form && t.setAttribute("form", `${t.form.getAttribute("id")}-${r}`)
            })), e.parentNode.insertBefore(a, e), e.style.display = "none", null == o || o.forEach((t => t(a))), setTimeout((() => e.remove()), 500)
        }
        static setInnerHTML(t, e) {
            t.innerHTML = e, t.querySelectorAll("script").forEach((t => {
                const e = document.createElement("script");
                Array.from(t.attributes).forEach((t => {
                    e.setAttribute(t.name, t.value)
                })), e.appendChild(document.createTextNode(t.innerHTML)), t.parentNode.replaceChild(e, t)
            }))
        }
    };
    const h = {
        overflowBackground: "[data-overflow-background]",
        overflowFrame: "[data-overflow-frame]",
        overflowContent: "[data-overflow-content]",
        overflowContainer: "[data-overflow-container]",
        overflowWrapper: "[data-overflow-wrapper]"
    };

    function u(t, e) {
        let i = 0;
        e.forEach((t => {
            i = t.offsetHeight > i ? t.offsetHeight : i
        }));
        const s = t.querySelectorAll(h.overflowBackground);
        [t, ...s].forEach((t => {
            t.style.setProperty("min-height", `calc(${i}px + var(--header-height))`)
        }))
    }

    function p(t) {
        if (window.innerWidth < window.theme.sizes.small) {
            return void t.querySelectorAll(h.overflowFrame).forEach((t => {
                const e = t.querySelectorAll(h.overflowContent);
                u(t, e)
            }))
        }
        let e = 0;
        const i = t.querySelectorAll(h.overflowFrame);
        t.querySelectorAll(h.overflowContent).forEach((t => {
            t.offsetHeight > e && (e = t.offsetHeight)
        }));
        [...i, ...t.querySelectorAll(h.overflowBackground)].forEach((t => {
            t.style.setProperty("min-height", `${e}px`)
        })), t.style.setProperty("min-height", `${e}px`)
    }

    function m(t) {
        const e = t.querySelectorAll(h.overflowContainer);
        e && e.forEach((t => {
            const e = t.querySelectorAll(h.overflowContent);
            u(t, e), document.addEventListener("theme:resize", (() => {
                u(t, e)
            }))
        }));
        const i = t.querySelectorAll(h.overflowWrapper);
        i && i.forEach((t => {
            p(t), document.addEventListener("theme:resize", (() => {
                p(t)
            }))
        }))
    }

    function g() {
        document.dispatchEvent(new CustomEvent("theme:resize", {
            bubbles: !0
        })), window.lastWindowWidth !== window.innerWidth && (document.dispatchEvent(new CustomEvent("theme:resize:width", {
            bubbles: !0
        })), window.lastWindowWidth = window.innerWidth)
    }
    window.lastWindowWidth = window.innerWidth;
    let v = window.pageYOffset,
        b = null,
        w = null,
        y = null,
        f = null,
        E = 0;
    const L = {
        quickViewVisible: "js-quick-view-visible",
        cartDrawerOpen: "js-drawer-open-cart"
    };

    function S(e) {
        setTimeout((() => {
            E && clearTimeout(E), t.disablePageScroll(e.detail, {
                allowTouchMove: t => "TEXTAREA" === t.tagName
            }), document.documentElement.setAttribute("data-scroll-locked", "")
        }))
    }

    function C(t) {
        const e = t.detail;
        e ? E = setTimeout(k, e) : k()
    }

    function k() {
        document.body.classList.contains(L.quickViewVisible) || document.body.classList.contains(L.cartDrawerOpen) || (t.clearQueueScrollLocks(), t.enablePageScroll(), document.documentElement.removeAttribute("data-scroll-locked"))
    }
    const A = {
            loading: "is-loading",
            imgIn: "img-in"
        },
        T = {
            img: "img.is-loading",
            section: "[data-section-type]"
        };

    function q(t) {
        t.querySelectorAll(T.img).forEach((t => {
            if (t.complete) {
                t.classList.remove(A.loading), t.parentNode.classList.remove(A.loading);
                const e = t.closest(T.section);
                e && e.classList.add(A.imgIn)
            }
        }))
    }
    const H = "img",
        I = "template",
        P = ".shopify-section",
        D = "[data-deferred-content]",
        M = "[data-product-image]",
        x = "srcset",
        F = "data-loaded",
        _ = "data-deferred-container";
    let O = class extends HTMLElement {
        connectedCallback() {
            0 != this.deferredTriggers.length ? this.deferredTriggers.forEach((t => {
                t.addEventListener("mouseenter", (() => {
                    this.hasAttribute(F) || this.loadTemplate()
                }), {
                    once: !0
                })
            })) : this.container.addEventListener("mouseenter", (() => {
                this.hasAttribute(F) || this.loadTemplate()
            }), {
                once: !0
            })
        }
        loadTemplate() {
            var t;
            const e = document.createElement("div"),
                i = this.querySelector(I);
            if (!i || !(null == i || null === (t = i.content) || void 0 === t ? void 0 : t.firstElementChild)) return;
            e.appendChild(i.content.firstElementChild.cloneNode(!0));
            const s = e.querySelector(D);
            if (!s) return;
            this.append(s), this.setAttribute(F, !0);
            s.querySelectorAll(H).length > 0 && this.reloadSrcset(this)
        }
        reloadSrcset(t) {
            t && t.querySelectorAll(H).forEach((t => {
                if (!t.parentNode.matches(M)) {
                    const e = t.getAttribute(x);
                    t.setAttribute(x, ""), t.setAttribute(x, e)
                }
            }))
        }
        constructor() {
            super(), this.container = this, this.hasAttribute(_) && (this.container = this.closest(this.getAttribute(_)) || this.closest(P)), this.deferredTriggers = this.container.querySelectorAll(this.dataset.deferredTriggers)
        }
    };
    const V = ".shopify-section",
        B = "[data-slider]",
        $ = "[data-hover-slideshow-holder]",
        W = "[data-hover-slideshow-item]",
        R = "[data-hover-slideshow-progress]",
        z = ".flickity-button",
        N = "fill";
    let U = class extends HTMLElement {
        get holder() {
            return this.querySelector($)
        }
        get items() {
            return [...this.querySelectorAll(W)]
        }
        get progress() {
            return this.querySelector(R)
        }
        connectedCallback() {
            "slideshow" !== theme.settings.productGridHover || window.theme.touch || this.init()
        }
        init() {
            this.section = this.closest(V), this.outerSliders = this.section.querySelectorAll(B), this.autoplaySpeed = 2200, this.timer = 0, this.flkty = new window.theme.Flickity.data(this.holder), !this.flkty.isActive && this.items.length > 1 && (this.flkty = new window.theme.Flickity(this.holder, {
                draggable: !this.outerSliders.length,
                cellSelector: W,
                contain: !0,
                wrapAround: !0,
                imagesLoaded: !0,
                pageDots: !1,
                prevNextButtons: !1,
                adaptiveHeight: !1,
                pauseAutoPlayOnHover: !1,
                selectedAttraction: .2,
                friction: 1,
                on: {
                    ready: () => {
                        this.section.style.setProperty("--autoplay-speed", `${this.autoplaySpeed}ms`), setTimeout((() => this.flkty.resize()), 1e3)
                    },
                    change: () => {
                        this.timer && clearTimeout(this.timer), this.progress.classList.remove(N), this.progress.offsetWidth, requestAnimationFrame((() => this.progress.classList.add(N))), this.timer = setTimeout((() => this.progress.classList.remove(N)), this.autoplaySpeed)
                    },
                    dragEnd: () => {
                        this.flkty.playPlayer()
                    }
                }
            }), this.addEventListener("mouseenter", (() => {
                this.progress.classList.add(N), this.timer && clearTimeout(this.timer), this.timer = setTimeout((() => this.progress.classList.remove(N)), this.autoplaySpeed), this.flkty.options.autoPlay = this.autoplaySpeed, this.flkty.playPlayer()
            })), this.addEventListener("mouseleave", (() => {
                this.flkty.stopPlayer(), this.timer && clearTimeout(this.timer), this.progress.classList.remove(N)
            }))), this.addEventListener("click", (t => {
                t.target.matches(z) && t.preventDefault()
            }))
        }
        constructor() {
            super()
        }
    };
    const j = "btn--top",
        Q = "btn--right",
        K = "btn--bottom",
        Y = "btn--left",
        X = "btn--text";
    let G = class extends HTMLElement {
        connectedCallback() {
            this.button.classList.contains(X) || this.button.addEventListener("mouseenter", this.detectEntrySide)
        }
        detectEntrySide(t) {
            const e = this.button.getBoundingClientRect();
            this.class && this.button.classList.remove(this.class);
            const i = t.clientX,
                s = t.clientY,
                o = i - e.left,
                n = e.right - i,
                a = s - e.top,
                r = e.bottom - s;
            this.class = o < n && o < a && o < r ? Y : n < o && n < a && n < r ? Q : a < o && a < n && a < r ? j : K, this.button.classList.add(this.class)
        }
        disconnectedCallback() {
            this.button.removeEventListener("mouseenter", this.detectEntrySide)
        }
        constructor() {
            super(), this.button = this.parentElement, this.class = "", this.detectEntrySide = this.detectEntrySide.bind(this)
        }
    };
    const J = {
            inputSearch: 'input[type="search"]',
            inputType: 'input[name="type"]',
            form: "form",
            allVisibleElements: '[role="option"]',
            ariaSelected: '[aria-selected="true"]',
            selectedOption: '[aria-selected="true"] a, button[aria-selected="true"]',
            popularSearches: "[data-popular-searches]",
            popdownBody: "[data-popdown-body]",
            mainInputSearch: "[data-main-input-search]",
            predictiveSearchResults: "[data-predictive-search-results]",
            predictiveSearch: "predictive-search",
            searchForm: "search-form"
        },
        Z = "is-searched",
        tt = "template-search";
    let et = class extends HTMLElement {
        getQuery() {
            return this.input.value.trim()
        }
        onFocus() {
            this.currentSearchTerm = this.getQuery()
        }
        onChange() {
            this.classList.toggle(Z, !this.isFormCleared()), this.searchTerm = this.getQuery()
        }
        isFormCleared() {
            return 0 === this.input.value.length
        }
        submit() {
            this.form.submit()
        }
        reset() {
            this.input.val = ""
        }
        onFormSubmit(t) {
            this.getQuery().length && !this.querySelector(J.selectedLink) || t.preventDefault()
        }
        onKeydown(t) {
            "ArrowUp" !== t.code && "ArrowDown" !== t.code || t.preventDefault()
        }
        onKeyup(t) {
            switch (!this.getQuery().length && this.predictiveSearch && this.close(!0), t.preventDefault(), t.code) {
                case "ArrowUp":
                    this.switchOption("up");
                    break;
                case "ArrowDown":
                    this.switchOption("down");
                    break;
                case "Enter":
                    this.selectOption()
            }
        }
        switchOption(t) {
            const e = "up" === t,
                i = this.classList.contains(Z) && this.predictiveSearchResults ? this.predictiveSearchResults : this.popularSearches;
            if (!i) return;
            this.selectedElement = i.querySelector(J.ariaSelected);
            const s = Array.from(i.querySelectorAll(J.allVisibleElements)).filter((t => null !== t.offsetParent));
            let o = 0;
            if (e && !this.selectedElement) return;
            let n = -1,
                a = 0;
            for (; - 1 === n && a <= s.length;) s[a] === this.selectedElement && (n = a), a++;
            !e && this.selectedElement ? o = n === s.length - 1 ? 0 : n + 1 : e && (o = 0 === n ? s.length - 1 : n - 1), o !== n && (this.activeElement = s[o], this.handleFocusableDescendants())
        }
        selectOption() {
            const t = this.querySelector(J.selectedOption);
            t && t.click()
        }
        handleFocusableDescendants(t = !1) {
            const e = this.selectedElement ? this.selectedElement : this.querySelector(J.ariaSelected);
            var i;
            if (e && e.setAttribute("aria-selected", !1), !this.activeElement || t) return this.selectedElement = null, null === (i = this.activeElement) || void 0 === i || i.setAttribute("aria-selected", !1), this.input.setAttribute("aria-expanded", !1), void this.input.setAttribute("aria-activedescendant", "");
            this.activeElement.setAttribute("aria-selected", !0), this.input.setAttribute("aria-activedescendant", this.activeElement.id)
        }
        constructor() {
            var t;
            super(), this.input = this.querySelector(J.inputSearch), this.form = this.querySelector(J.form), this.popdownBody = this.closest(J.popdownBody), this.popularSearches = null === (t = this.popdownBody) || void 0 === t ? void 0 : t.querySelector(J.popularSearches), this.predictiveSearchResults = this.querySelector(J.predictiveSearchResults), this.predictiveSearch = this.matches(J.predictiveSearch), this.searchForm = this.matches(J.searchForm), this.selectedElement = null, this.activeElement = null, this.searchTerm = "", this.currentSearchTerm = "", this.isSearchPage = document.body.classList.contains(tt), this.input.addEventListener("input", window.theme.debounce((t => {
                this.onChange(t)
            }), 300).bind(this)), this.input.addEventListener("focus", this.onFocus.bind(this)), this.input.form.addEventListener("submit", this.onFormSubmit.bind(this)), this.addEventListener("keyup", this.onKeyup.bind(this)), this.addEventListener("keydown", this.onKeydown.bind(this)), this.isSearchPage && (this.mainInputType = document.querySelector(`${J.mainInputSearch} ${J.inputType}`), this.inputType = this.querySelector(J.inputType), this.inputType.value = this.mainInputType.value)
        }
    };
    customElements.define("search-form", et);
    const it = "predictive-search",
        st = "#shopify-section-api-predictive-search",
        ot = "[data-predictive-search-results]",
        nt = "[data-predictive-search-status]",
        at = "[data-predictive-search-live-region-count-value]",
        rt = "[data-search-results-wrapper]",
        lt = "reset",
        ct = "data-aos-anchor",
        dt = "aria-hidden",
        ht = "open",
        ut = "loading",
        pt = "data-loading-text",
        mt = "results";
    customElements.define("predictive-search", class extends et {
        connectedCallback() {
            this.predictiveSearchResults.addEventListener("transitionend", (t => {
                t.target !== this.predictiveSearchResults || this.getQuery().length || (this.classList.remove(lt), requestAnimationFrame((() => this.clearResultsHTML())))
            }))
        }
        onChange() {
            super.onChange(), this.classList.remove(lt), this.searchTerm.length ? requestAnimationFrame((() => this.getSearchResults(this.searchTerm))) : this.classList.add(lt)
        }
        onFocus() {
            super.onFocus(), this.currentSearchTerm.length && (this.searchTerm !== this.currentSearchTerm ? this.onChange() : "true" === this.getAttribute(mt) ? this.open() : this.getSearchResults(this.searchTerm))
        }
        getSearchResults(t) {
            const e = t.replace(" ", "-").toLowerCase(),
                i = parseInt(window.theme.settings.suggestionsResultsLimit);
            let s = "query";
            s += window.theme.settings.suggestArticles ? ",article" : "", s += window.theme.settings.suggestCollections ? ",collection" : "", s += window.theme.settings.suggestProducts ? ",product" : "", s += window.theme.settings.suggestPages ? ",page" : "", this.setLiveRegionLoadingState(), this.cachedResults[e] ? this.renderSearchResults(this.cachedResults[e]) : fetch(`${theme.routes.predictiveSearchUrl}?q=${encodeURIComponent(t)}&resources[type]=${s}&resources[limit]=${i}&section_id=api-predictive-search`, {
                signal: this.abortController.signal
            }).then((t => {
                if (!t.ok) {
                    var e = new Error(t.status);
                    throw this.close(), e
                }
                return t.text()
            })).then((t => {
                const i = (new DOMParser).parseFromString(t, "text/html").querySelector(st).innerHTML;
                this.allPredictiveSearchInstances.forEach((t => {
                    t.cachedResults[e] = i
                })), this.renderSearchResults(i)
            })).catch((t => {
                if (20 !== (null == t ? void 0 : t.code)) throw this.close(), t
            }))
        }
        switchOption(t) {
            super.switchOption(t), this.statusElement && (this.statusElement.textContent = "")
        }
        setLiveRegionLoadingState() {
            this.statusElement = this.statusElement || this.querySelector(nt), this.loadingText = this.loadingText || this.getAttribute(pt), this.setLiveRegionText(this.loadingText), this.setAttribute(ut, !0)
        }
        setLiveRegionText(t) {
            this.statusElement.setAttribute(dt, "false"), this.statusElement.textContent = t, setTimeout((() => {
                this.statusElement.setAttribute(dt, "true")
            }), 1e3)
        }
        renderSearchResults(t) {
            this.predictiveSearchResults.innerHTML = t;
            const e = this.predictiveSearchResults.parentElement.id,
                i = this.predictiveSearchResults.querySelector(rt),
                s = i.id;
            i.id = `${s}--${e}`, i.setAttribute(ct, `#${i.id}`), this.setAttribute(mt, !0), this.setLiveRegionResults(), this.open()
        }
        setLiveRegionResults() {
            this.removeAttribute(ut), this.setLiveRegionText(this.querySelector(at).textContent)
        }
        open() {
            this.setAttribute(ht, !0)
        }
        close(t = !1) {
            this.closeResults(t)
        }
        closeResults(t = !1) {
            t && (this.reset(), this.removeAttribute(mt), this.classList.remove(lt)), this.removeAttribute(ut), this.removeAttribute(ht)
        }
        clearResultsHTML() {
            this.predictiveSearchResults.innerHTML = ""
        }
        constructor() {
            super(), this.abortController = new AbortController, this.allPredictiveSearchInstances = document.querySelectorAll(it), this.predictiveSearchResults = this.querySelector(ot), this.cachedResults = {}
        }
    });
    let gt = class extends HTMLElement {
        constructor() {
            super(), document.addEventListener("DOMContentLoaded", (() => {
                document.documentElement.classList.remove("page-loading")
            }))
        }
    };
    const vt = {
            aos: "[data-aos]:not(.aos-animate)",
            aosAnchor: "[data-aos-anchor]",
            animatable: "[data-aos], [data-aos-anchor]",
            watchMutations: '[id^="api-cart-items-"], [data-collection-filters], [data-collection-products], #AjaxinateLoop, [data-tab="resultsProducts"]',
            textHighlight: "text-highlight",
            counterUps: "text-count-up",
            flickitySlider: ".flickity-slider",
            slide: "[data-slide]",
            carouselMobile: ".carousel--mobile"
        },
        bt = {
            aosAnimate: "aos-animate",
            isLoading: "is-loading",
            isSelected: ".is-selected"
        },
        wt = {
            aos: "data-aos",
            aosAnchor: "data-aos-anchor",
            aosIntersection: "data-aos-intersection",
            aosDebounce: "data-aos-debounce",
            aosCustomInit: "data-aos-custom-init",
            aosWatchAnchors: "data-aos-watch-anchors",
            aosTrigger: "data-aos-trigger",
            aosCarouselMobile: "data-aos-carousel-mobile",
            aosCarouselDesktop: "data-aos-carousel-desktop"
        },
        yt = .1,
        ft = 0;
    let Et = new Set;

    function Lt(t) {
        t.length && (t.forEach((t => {
            const e = t.dataset.aosAnchor;
            let i;
            "" != e && (i = document.getElementById(e.slice(1))), i && !Et.has(t) && Et.add(i)
        })), Et.forEach((t => {
            St.observe(t)
        })))
    }
    const St = new IntersectionObserver(((t, e) => {
        t.forEach((t => {
            const i = t.target,
                s = t.intersectionRatio,
                o = t.isIntersecting;
            let n, a = yt;
            i.hasAttribute(wt.aosIntersection) && (a = Number(i.getAttribute(wt.aosIntersection)));
            let r = ft;
            i.hasAttribute(wt.aosDebounce) && (r = Number(i.getAttribute(wt.aosDebounce))), o && s > a && (0 !== r ? (n && clearTimeout(n), n = setTimeout((() => Ct(i)), r)) : Ct(i), e.unobserve(i), Et.delete(i))
        }))
    }), {
        root: null,
        rootMargin: "0px",
        threshold: [0, .05, .1, .15, .2, .25, .5, .75, 1]
    });

    function Ct(t) {
        if (!t) return;
        if (kt(t), t.hasAttribute(wt.aosCarouselDesktop) && window.theme.isDesktop()) {
            if (t.querySelector(vt.flickitySlider)) {
                const e = t.querySelectorAll(vt.slide),
                    i = [...e].filter((t => {
                        if (t.matches(bt.isSelected)) return t
                    })),
                    s = [...e].filter((t => {
                        if (!t.matches(bt.isSelected)) return t
                    }));
                if (i.length > 0) {
                    const t = i[i.length - 1].id;
                    i[i.length - 1].setAttribute(wt.aosTrigger, `#${t}`), s.forEach((e => {
                        e.querySelectorAll(vt.animatable).forEach((e => {
                            e.setAttribute(wt.aosAnchor, `#${t}`)
                        }))
                    }))
                }
            }
        }
        if (t.hasAttribute(wt.aosCarouselMobile) && window.theme.isMobile()) {
            const e = t.querySelector(vt.carouselMobile);
            if (e) {
                const t = [...e.children],
                    i = t[0].id;
                t.length > 1 && (t[0].setAttribute(wt.aosTrigger, `#${i}`), t.forEach((t => {
                    t.querySelectorAll(vt.animatable).forEach((t => {
                        t.setAttribute(wt.aosAnchor, `#${i}`)
                    }))
                })))
            }
        }
        if (t.hasAttribute(wt.aosTrigger)) {
            const e = t.getAttribute(wt.aosTrigger);
            document.querySelectorAll(`[${wt.aosAnchor}="${e}"]`).forEach((t => kt(t)))
        }
        let e = t.querySelectorAll(vt.aos);
        if (t.hasAttribute(wt.aosWatchAnchors)) {
            e = [...e].filter((e => {
                const i = !!e.hasAttribute(wt.aosAnchor) && e.getAttribute(wt.aosAnchor);
                if (i && `#${t.id}` === i) return e
            }))
        }
        e.forEach((e => {
            e.hasAttribute(wt.aosCustomInit) ? t.dispatchEvent(new CustomEvent("theme:target:animate", {
                bubbles: !0,
                detail: e
            })) : kt(e)
        }))
    }

    function kt(t) {
        requestAnimationFrame((() => t.classList.add(bt.aosAnimate))),
            function(t) {
                const e = t.querySelectorAll(vt.textHighlight);
                e.forEach((t => t.shouldAnimate()))
            }(t),
            function(t) {
                const e = t.querySelectorAll(vt.counterUps);
                e.forEach((t => t.shouldAnimate()))
            }(t)
    }

    function At() {
        Lt(document.querySelectorAll(vt.aosAnchor)),
            function() {
                const t = t => t instanceof HTMLElement;
                new MutationObserver((e => {
                    for (const i of e) {
                        if ("childList" === !i.type) return;
                        const e = i.target,
                            s = [...i.addedNodes],
                            o = [...i.removedNodes],
                            n = e.matches(vt.watchMutations) || s.some((e => !!t(e) && e.matches(vt.watchMutations))) || o.some((e => !!t(e) && e.matches(vt.watchMutations))),
                            a = e.matches(vt.animatable) || s.some((e => !!t(e) && e.matches(vt.animatable))),
                            r = null !== e.querySelector(`[${wt.aosAnchor}="#${e.id}"]`);
                        (a || r || n) && Lt(e.querySelectorAll(vt.aosAnchor))
                    }
                })).observe(document.body, {
                    attributes: !1,
                    childList: !0,
                    subtree: !0
                })
            }()
    }
    const Tt = t => {
            clearTimeout(t.countUpTimeout), t._countUpOrigInnerHTML && (t.innerHTML = t._countUpOrigInnerHTML, t._countUpOrigInnerHTML = void 0), t.style.visibility = ""
        },
        qt = (t, e = {}) => {
            const {
                duration: i = 1e3,
                delay: s = 16
            } = e, o = i / s, n = t.toString().split(/(<[^>]+>|[0-9.][,.0-9]*[0-9]*)/), a = [];
            for (let t = 0; t < o; t++) a.push("");
            for (let t = 0; t < n.length; t++)
                if (/([0-9.][,.0-9]*[0-9]*)/.test(n[t]) && !/<[^>]+>/.test(n[t])) {
                    let e = n[t];
                    const i = [...e.matchAll(/[.,]/g)].map((t => ({
                        char: t[0],
                        i: e.length - t.index - 1
                    }))).sort(((t, e) => t.i - e.i));
                    e = e.replace(/[.,]/g, "");
                    let s = a.length - 1;
                    for (let t = o; t >= 1; t--) {
                        let n = parseInt(e / o * t, 10);
                        n = i.reduce(((t, {
                            char: e,
                            i: i
                        }) => t.length <= i ? t : t.slice(0, -i) + e + t.slice(-i)), n.toString()), a[s--] += n
                    }
                } else
                    for (let e = 0; e < o; e++) a[e] += n[t];
            return a[a.length] = t.toString(), a
        };
    const Ht = "data-count-up-duration",
        It = "data-count-up-init";
    let Pt = class extends HTMLElement {
        connectedCallback() {
            theme.settings.animationsEnabled || this.startCountUp()
        }
        attributeChangedCallback(t, e, i) {
            null === e && t === It && "true" === i && this.startCountUp()
        }
        shouldAnimate() {
            requestAnimationFrame((() => this.setTriggerAttribute()))
        }
        setTriggerAttribute(t = !0) {
            this.setAttribute(It, t)
        }
        startCountUp() {
            ((t, e = {}) => {
                const {
                    action: i = "start",
                    duration: s = 1e3,
                    delay: o = 16
                } = e;
                if ("stop" === i) return void Tt(t);
                if (Tt(t), !/[0-9]/.test(t.innerHTML)) return;
                const n = qt(t.innerHTML, {
                    duration: s || t.getAttribute("data-duration"),
                    delay: o || t.getAttribute("data-delay")
                });
                t._countUpOrigInnerHTML = t.innerHTML, t.innerHTML = n[0] || "&nbsp;", t.style.visibility = "visible";
                const a = function() {
                    t.innerHTML = n.shift() || "&nbsp;", n.length ? (clearTimeout(t.countUpTimeout), t.countUpTimeout = setTimeout(a, o)) : t._countUpOrigInnerHTML = void 0
                };
                t.countUpTimeout = setTimeout(a, o)
            })(this, {
                duration: this.duration,
                delay: .016 * this.duration
            })
        }
        constructor() {
            super(), this.container = this, this.countUpDuration = this.getAttribute(Ht), this.duration = 100 / parseInt(this.countUpDuration, 10) * 1e3
        }
    };
    var Dt, Mt, xt;

    function Ft(t) {
        this.status = t.status || null, this.headers = t.headers || null, this.json = t.json || null, this.body = t.body || null
    }
    xt = [It], (Mt = "observedAttributes") in (Dt = Pt) ? Object.defineProperty(Dt, Mt, {
            value: xt,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : Dt[Mt] = xt, window.requestIdleCallback = window.requestIdleCallback || function(t) {
            var e = Date.now();
            return setTimeout((function() {
                t({
                    didTimeout: !1,
                    timeRemaining: function() {
                        return Math.max(0, 50 - (Date.now() - e))
                    }
                })
            }), 1)
        }, window.cancelIdleCallback = window.cancelIdleCallback || function(t) {
            clearTimeout(t)
        }, window.addEventListener("resize", window.theme.debounce(g, 50)),
        function() {
            let t;
            window.addEventListener("scroll", (function() {
                t && window.cancelAnimationFrame(t), t = window.requestAnimationFrame((function() {
                    ! function() {
                        const t = window.pageYOffset;
                        t > v ? (w = !0, b = !1) : t < v ? (w = !1, b = !0) : (b = null, w = null), v = t, document.dispatchEvent(new CustomEvent("theme:scroll", {
                            detail: {
                                up: b,
                                down: w,
                                position: t
                            },
                            bubbles: !1
                        })), b && !y && document.dispatchEvent(new CustomEvent("theme:scroll:up", {
                            detail: {
                                position: t
                            },
                            bubbles: !1
                        })), w && !f && document.dispatchEvent(new CustomEvent("theme:scroll:down", {
                            detail: {
                                position: t
                            },
                            bubbles: !1
                        })), f = w, y = b
                    }()
                }))
            }), {
                passive: !0
            }), window.addEventListener("theme:scroll:lock", S), window.addEventListener("theme:scroll:unlock", C)
        }(), "ontouchstart" in window || navigator.maxTouchPoints > 0 || navigator.msMaxTouchPoints > 0 ? (document.documentElement.className = document.documentElement.className.replace("no-touch", "supports-touch"), window.theme.touch = !0) : window.theme.touch = !1, document.addEventListener("load", (t => {
            if ("img" == t.target.tagName.toLowerCase() && t.target.classList.contains(A.loading)) {
                t.target.classList.remove(A.loading), t.target.parentNode.classList.remove(A.loading);
                const e = t.target.closest(T.section);
                e && e.classList.add(A.imgIn)
            }
        }), !0), window.addEventListener("DOMContentLoaded", (() => {
            m(document), q(document), window.theme.settings.animationsEnabled && At()
        })), document.addEventListener("shopify:section:load", (t => {
            const e = t.target;
            window.dispatchEvent(new Event("resize"), {
                bubbles: !0
            }), m(e), window.theme.settings.animationsEnabled && At()
        })), document.addEventListener("shopify:section:reorder", (t => {
            t.target, window.theme.settings.animationsEnabled && At()
        })), customElements.get("deferred-loading") || customElements.define("deferred-loading", O), customElements.get("loading-overlay") || customElements.define("loading-overlay", gt), customElements.get("text-count-up") || customElements.define("text-count-up", Pt), customElements.get("hover-slideshow") || customElements.define("hover-slideshow", U), customElements.get("hover-button") || customElements.define("hover-button", G),
        function() {
            function t(t) {
                var e = window.innerWidth || document.documentElement.clientWidth,
                    i = window.innerHeight || document.documentElement.clientHeight,
                    s = t.getBoundingClientRect();
                return s.top >= 0 && s.bottom <= i && s.left >= 0 && s.right <= e
            }

            function e(t) {
                var e = window.innerWidth || document.documentElement.clientWidth,
                    i = window.innerHeight || document.documentElement.clientHeight,
                    s = t.getBoundingClientRect(),
                    o = s.left >= 0 && s.left <= e || s.right >= 0 && s.right <= e,
                    n = s.top >= 0 && s.top <= i || s.bottom >= 0 && s.bottom <= i;
                return o && n
            }
            window.visibilityHelper = {
                isElementTotallyVisible: t,
                isElementPartiallyVisible: e,
                inViewportPartially: function(t, i) {
                    function s() {
                        var s = e(t);
                        s != o && (o = s, "function" == typeof i && i(s, t))
                    }
                    var o = e(t);
                    window.addEventListener("load", s), window.addEventListener("resize", s), window.addEventListener("scroll", s)
                },
                inViewportTotally: function(e, i) {
                    function s() {
                        var s = t(e);
                        s != o && (o = s, "function" == typeof i && i(s, e))
                    }
                    var o = t(e);
                    window.addEventListener("load", s), window.addEventListener("resize", s), window.addEventListener("scroll", s)
                }
            }
        }(), customElements.get("header-component") || customElements.define("header-component", class extends HTMLElement {
            connectedCallback() {
                this.classList.contains("js__header__clone") || (this.initTransparentHeader(), window.minWidth = this.getMinWidth(), this.listenWidth(), this.initMobileNavToggle(), this.handleTextLinkLogos(), this.initStickyHeader(), this.handleBackgroundEvents(), document.body.addEventListener("touchstart", this.handleTouchstartEvent, {
                    passive: !0
                }), this.updateHeaderHover())
            }
            initTransparentHeader() {
                const t = "true" === this.dataset.transparent,
                    e = document.querySelector("[data-main]").children[0];
                if (!e) return;
                const i = e.querySelector("[data-prevent-transparent-header]:first-of-type");
                window.isHeaderTransparent = t && e.classList.contains("supports-transparent-header") && !i
            }
            getMinWidth() {
                const t = this.headerWrapper.currentStyle || window.getComputedStyle(this.headerWrapper),
                    e = 2 * parseInt(t.paddingLeft),
                    i = this.cloneNode(!0);
                i.classList.add("js__header__clone"), document.body.appendChild(i);
                const s = i.querySelectorAll("[data-takes-space]"),
                    o = this.getAttribute("data-nav-alignment"),
                    n = this._sumSplitWidths(s, o);
                return document.body.removeChild(i), n + 20 * s.length + e
            }
            listenWidth() {
                this.checkWidthEvent = this.checkWidth.bind(this), "ResizeObserver" in window ? (this.resizeObserver = new ResizeObserver(this.checkWidthEvent), this.resizeObserver.observe(this)) : document.addEventListener("theme:resize", this.checkWidthEvent), this.checkWidth()
            }
            checkWidth() {
                if (this.isResizing) return;
                this.isResizing = !0;
                const t = window.innerWidth < window.minWidth,
                    e = this.classList.contains("site-header--compress");
                t && !e ? this.classList.add("site-header--compress") : !t && e && this.classList.remove("site-header--compress"), this.isResizing = !1
            }
            updateHeaderHover() {
                requestAnimationFrame((() => {
                    const t = this.matches(":hover"),
                        e = this.classList.contains("site-header--hovered");
                    t && !e && this.classList.add("site-header--hovered")
                }))
            }
            handleTouchstart(t) {
                const e = this.contains(t.target),
                    i = this.querySelector(".is-visible[data-nav-item]");
                !e && i && i.dispatchEvent(new Event("mouseleave", {
                    bubbles: !0
                }))
            }
            handleTextLinkLogos() {
                if (null === this.logoTextLink) return;
                const t = this.offsetHeight;
                document.documentElement.style.setProperty("--header-height", `${t}px`), document.documentElement.style.setProperty("--header-sticky-height", `${t}px`)
            }
            initStickyHeader() {
                this.headerSticky = this.hasAttribute("data-header-sticky"), this.hasScrolled = !1, this.hasCollectionFilters = document.querySelector("[data-collection-filters]"), this.position = this.dataset.position;
                if ("fixed" === this.position && !this.hasCollectionFilters) return this.headerState(), void document.addEventListener("theme:scroll", this.headerStateEvent);
                document.body.classList.remove("has-scrolled"), window.isHeaderTransparent && this.classList.add("site-header--transparent")
            }
            headerState(t) {
                const e = parseInt(this.dataset.height || this.offsetHeight),
                    i = document.querySelector("[data-announcement-wrapper]"),
                    s = e + (i ? i.offsetHeight : 0),
                    o = window.pageYOffset || document.documentElement.scrollTop,
                    n = t && t.detail && t.detail.up;
                this.hasScrolled = o > s, document.body.classList.toggle("has-scrolled", this.hasScrolled);
                const a = o < s + window.stickyHeaderHeight && n;
                if (document.body.classList.toggle("hide-header", a), window.isHeaderTransparent) {
                    const t = !this.hasScrolled || a;
                    this.classList.toggle("site-header--transparent", t)
                }
                if (this.classList.contains("site-header--hovered")) {
                    const t = this.querySelector(".is-visible[data-nav-item]");
                    if (null != t) t.dispatchEvent(new Event("mouseenter", {
                        bubbles: !0
                    }));
                    else {
                        const t = this.hasScrolled ? window.stickyHeaderHeight : e;
                        this.background.style.setProperty("--header-background-height", `${t}px`)
                    }
                }
            }
            handleBackgroundEvents() {
                this.headerWrapper.addEventListener("mouseenter", this.updateBackgroundHeightEvent), this.headerWrapper.addEventListener("mouseleave", this.updateBackgroundHeightEvent), this.addEventListener("focusout", this.updateBackgroundHeightEvent), document.addEventListener("theme:cart:close", this.updateBackgroundHeightEvent), document.addEventListener("theme:search:close", this.updateBackgroundHeightEvent)
            }
            updateBackgroundHeight(t) {
                const e = matchMedia("(pointer:fine)").matches,
                    i = !document.body.classList.contains("no-outline"),
                    s = e && !i;
                if (!t) return;
                let o = ["js-drawer-open", "js-drawer-open-cart", "js-quick-view-visible", "js-quick-view-from-cart"].some((t => document.body.classList.contains(t)));
                ("mouseenter" === t.type || o) && (this.headerHeight = this.hasScrolled ? window.stickyHeaderHeight : this.offsetHeight, this.classList.add("site-header--hovered"), this.classList.contains("site-header--menu-opened") || this.background.style.setProperty("--header-background-height", `${this.headerHeight}px`)), "mouseenter" !== t.type && requestAnimationFrame((() => {
                    if (o = ["js-drawer-open", "js-drawer-open-cart", "js-quick-view-visible", "js-quick-view-from-cart"].some((t => document.body.classList.contains(t))), o) return;
                    if ("focusout" === t.type && !e) return;
                    if ("theme:search:close" === t.type && !s) return;
                    if (this.hasScrolled) return;
                    const n = null === document.activeElement.closest("header-component"),
                        a = document.body.classList.contains("search-opened"),
                        r = this.classList.contains("site-header--menu-opened");
                    a || r || ("focusout" !== t.type || n) && (this.classList.remove("site-header--hovered"), this.background.style.setProperty("--header-background-height", "0px"), i || document.activeElement.blur())
                }))
            }
            initMobileNavToggle() {
                var t;
                null === (t = this.mobileMenuTrigger) || void 0 === t || t.addEventListener("click", (() => {
                    if (!document.body.classList.contains("js-drawer-open")) {
                        if (document.body.classList.contains("search-opened")) return void document.addEventListener("theme:search:close", this.triggerDrawerOpeningEvent);
                        this.triggerDrawerOpening(this.mobileMenuTrigger)
                    }
                }))
            }
            triggerDrawerOpening(t) {
                document.dispatchEvent(new CustomEvent("theme:drawer:opening", {
                    bubbles: !0,
                    detail: {
                        element: t
                    }
                })), document.removeEventListener("theme:search:close", this.triggerDrawerOpeningEvent)
            }
            _sumSplitWidths(t, e) {
                let i = [];
                t.forEach((t => {
                    i.push(t.clientWidth)
                }));
                let [s, o, n] = i;
                if ("left" === e) {
                    const t = s;
                    s = o, o = t
                }
                return "right" !== e && (s > n ? n = s : s = n), s + o + n
            }
            disconnectedCallback() {
                var t;
                "ResizeObserver" in window ? null === (t = this.resizeObserver) || void 0 === t || t.disconnect() : document.removeEventListener("theme:resize", this.checkWidthEvent);
                document.documentElement.style.removeProperty("--header-height"), document.documentElement.style.removeProperty("--header-sticky-height"), document.body.classList.remove("js-drawer-open", "js-drawer-open-cart", "js-quick-view-visible", "js-quick-view-from-cart"), document.removeEventListener("theme:scroll", this.headerStateEvent), document.removeEventListener("theme:cart:close", this.updateBackgroundHeightEvent), document.removeEventListener("theme:search:close", this.updateBackgroundHeightEvent), document.body.removeEventListener("touchstart", this.handleTouchstartEvent)
            }
            constructor() {
                super(), this.background = document.querySelector("[data-header-background]"), this.headerWrapper = this.querySelector("[data-wrapper]"), this.logoTextLink = this.querySelector("[data-logo-text-link]"), this.nav = this.querySelector("[data-nav]"), this.mobileMenuTrigger = this.querySelector("[data-mobile-menu-trigger]"), this.headerStateEvent = this.headerState.bind(this), this.handleTouchstartEvent = this.handleTouchstart.bind(this), this.updateBackgroundHeightEvent = this.updateBackgroundHeight.bind(this), this.triggerDrawerOpeningEvent = () => this.triggerDrawerOpening(this.mobileMenuTrigger)
            }
        }), customElements.get("hover-disclosure") || customElements.define("hover-disclosure", class extends HTMLElement {
            connectedCallback() {
                this.setAttribute("aria-haspopup", !0), this.setAttribute("aria-expanded", !1), this.setAttribute("aria-controls", this.key), this.connectHoverToggle(), this.handleTablets()
            }
            setBackgroundHeight() {
                const t = document.body.classList.contains("has-scrolled") ? window.stickyHeaderHeight : this.header.offsetHeight;
                this.grandparent ? (this.disclosure.style.height = "auto", this.dropdownHeight = this.disclosure.offsetHeight + t) : this.dropdownHeight = t, this.background.style.setProperty("--header-background-height", `${this.dropdownHeight}px`), window.innerWidth < theme.sizes.small && this.hideDisclosure()
            }
            showDisclosure() {
                this.isVisible || (this.isVisible = !0, this.setBackgroundHeight(), document.addEventListener("theme:resize", this.setBackgroundHeightEvent), this.header.classList.contains("site-header--compress") || (this.grandparent && document.body.classList.add("megamenu-opened"), this.header.classList.add("site-header--menu-opened")), this.setAttribute("aria-expanded", !0), this.classList.add("is-visible"), this.disclosure.classList.add("is-visible"), this.updateHeaderHover())
            }
            hideDisclosure() {
                this.isVisible && (this.isVisible = !1, this.background.style.removeProperty("--header-background-height"), document.removeEventListener("theme:resize", this.setBackgroundHeightEvent), this.classList.remove("is-visible"), this.disclosure.classList.remove("is-visible"), this.setAttribute("aria-expanded", !1), this.header.classList.remove("site-header--menu-opened"), document.body.classList.remove("megamenu-opened"))
            }
            updateHeaderHover() {
                requestAnimationFrame((() => {
                    const t = this.header.matches(":hover"),
                        e = this.header.classList.contains("site-header--hovered");
                    t && !e && this.header.classList.add("site-header--hovered")
                }))
            }
            handleTablets() {
                this.addEventListener("touchstart", (t => {
                    if (!this.classList.contains("is-visible")) {
                        t.preventDefault();
                        const e = this.header.querySelectorAll(".is-visible[data-nav-item]");
                        if (e.length > 0) return void e.forEach((t => {
                            if (t !== this) {
                                t.dispatchEvent(new Event("mouseleave", {
                                    bubbles: !0
                                }));
                                const e = () => {
                                    requestAnimationFrame((() => {
                                        this.showDisclosure()
                                    })), t.removeEventListener("transitionend", e)
                                };
                                t.addEventListener("transitionend", e)
                            }
                        }));
                        this.showDisclosure()
                    }
                }))
            }
            connectHoverToggle() {
                this.addEventListener("mouseenter", (() => this.showDisclosure())), this.link.addEventListener("focus", (() => this.showDisclosure())), this.addEventListener("mouseleave", (() => this.hideDisclosure())), this.addEventListener("focusout", (t => {
                    this.contains(t.relatedTarget) || this.hideDisclosure()
                })), this.addEventListener("keyup", (t => {
                    "Escape" === t.code && this.hideDisclosure()
                }))
            }
            constructor() {
                super(), this.key = this.getAttribute("aria-controls"), this.link = this.querySelector("[data-top-link]"), this.grandparent = this.classList.contains("grandparent"), this.disclosure = document.getElementById(this.key), this.header = this.closest("[data-site-header]"), this.background = document.querySelector("[data-header-background]"), this.setBackgroundHeightEvent = () => this.setBackgroundHeight()
            }
        }), window.theme.waitForAnimationEnd = function(t) {
            return new Promise((e => {
                function i(s) {
                    s.target == t && (t.removeEventListener("animationend", i), t.removeEventListener("transitionend", i), e())
                }
                null == t || t.addEventListener("animationend", i), null == t || t.addEventListener("transitionend", i)
            }))
        }, Ft.prototype = Error.prototype;
    const _t = 1,
        Ot = {
            history: !1,
            focus: !1,
            mainClass: "pswp--notification pswp--not-close-btn",
            closeOnVerticalDrag: !1
        };
    const Vt = {
        cartDrawerEnabled: "drawer" === window.theme.settings.cartType,
        timers: {
            addProductTimeout: 1e3
        },
        animations: {
            data: "data-aos",
            method: "fade-up"
        }
    };
    customElements.get("cart-element") || customElements.define("cart-element", class extends HTMLElement {
        connectedCallback() {
            var t;
            this.cart = this, this.cartToggleButtons = document.querySelectorAll("[data-cart-drawer-toggle]"), this.isCartPage = this.hasAttribute("data-cart-page"), this.cartDrawerEnabled = Vt.cartDrawerEnabled, this.isCartDrawer = !1, this.cartDrawerEnabled && (this.isCartDrawer = this.hasAttribute("data-cart-drawer")), this.cartCount = this.getCartItemCount(), this.assignArguments(), this.recipientErrors = "true" === (null === (t = this.form) || void 0 === t ? void 0 : t.getAttribute("data-recipient-errors")), this.flktyUpsell = null, this.form = null, this.variantTitle = null, this.a11y = window.theme.a11y, this.build = this.build.bind(this), this.addToCart = this.addToCart.bind(this), this.updateCart = this.updateCart.bind(this), this.getCart = this.getCart.bind(this), this.openCartDrawer = this.openCartDrawer.bind(this), this.closeCartDrawer = this.closeCartDrawer.bind(this), this.toggleCartDrawer = this.toggleCartDrawer.bind(this), this.formSubmitHandler = window.theme.throttle(this.formSubmitHandler.bind(this), 50), this.closeCartError = () => {
                this.cartErrorHolder.classList.remove("is-expanded")
            }, this.cartDrawerCloseEvent = null, this.hasItemsInCart = this.hasItemsInCart.bind(this), this.toggleClassesOnContainers = this.toggleClassesOnContainers.bind(this), this.totalItems = 0, this.isCartDrawerOpen = !1, this.isCartDrawerLoaded = !1, this.cartUpdateFailed = !1, this.showCannotAddMoreInCart = !1, this.discountError = !1, this.shippingDiscountError = !1, this.pendingDiscountCheck = null, this.activeDiscountFetch = null, this.cartEvents(), this.cartAddEvent = this.cartAddEvent.bind(this), document.addEventListener("theme:cart:add", this.cartAddEvent), this.isCartDrawer && this.cartDrawerToggleEvents(), this.initCartUpdate(), this.isCartPage && this.renderPairProducts(), this.isCartDrawer && (document.addEventListener("theme:popup:open", this.closeCartDrawer), document.addEventListener("theme:cart:refresh", this.getCart))
        }
        assignArguments() {
            this.outerSection = this.cart.closest("[data-section-id]"), this.emptyMessage = this.cart.querySelector("[data-empty-message]"), this.emptyMessageBottom = this.cart.querySelector("[data-empty-message-bottom]"), this.buttonHolder = this.cart.querySelector("[data-foot-holder]"), this.itemsHolder = this.cart.querySelector("[data-items-holder]"), this.cartItemsQty = this.cart.querySelector("[data-cart-items-qty]"), this.itemsWrapper = this.cart.querySelector("[data-items-wrapper]"), this.items = this.cart.querySelectorAll("[data-cart-item]"), this.cartTotal = this.cart.querySelector("[data-cart-total]"), this.cartTotalPrice = this.cart.querySelector("[data-cart-total-price]"), this.cartMessage = this.cart.querySelectorAll("[data-cart-message]"), this.cartOriginalTotal = this.cart.querySelector("[data-cart-original-total]"), this.cartErrorHolder = this.cart.querySelector("[data-cart-errors]"), this.cartCloseErrorMessage = this.cart.querySelector("[data-cart-error-close]"), this.pairProductsHolder = this.cart.querySelector("[data-pair-products-holder]"), this.cartNoteHolder = this.cart.querySelector("[data-cart-notes-holder]"), this.discountsInput = this.cart.querySelector("[data-discount-input]"), this.discountsField = this.cart.querySelector("[data-discount-field]"), this.discountsButton = this.cart.querySelector("[data-apply-discount]"), this.discountErrorMessage = this.cart.querySelector("[data-discount-error-message]"), this.existingDiscountCodes = [], this.discounts = this.cart.querySelectorAll("[data-discount-body]"), this.pairProducts = this.cart.querySelector("[data-pair-products]"), this.priceHolder = this.cart.querySelector("[data-cart-price-holder]"), this.upsellHolders = this.cart.querySelectorAll("[data-upsell-holder]"), this.cartTermsCheckbox = this.cart.querySelector("[data-cart-acceptance-checkbox]"), this.cartCheckoutButtonWrapper = this.cart.querySelector("[data-cart-checkout-buttons]"), this.cartCheckoutButton = this.cart.querySelector("[data-cart-checkout-button]"), this.cartForm = this.cart.querySelector("[data-cart-form]"), this.isCartDrawer && (this.cartDrawerBody = this.cart.querySelector("[data-cart-drawer-body]")), this.cartItemCount = 0, this.subtotal = window.theme.subtotal, this.button = null;
            const {
                headerInitialHeight: t,
                announcementBarHeight: e
            } = window.theme.readHeights();
            this.headerInitialHeight = t, this.announcementBarHeight = e, this.cartMessage.length > 0 && (this.cartFreeLimitShipping = 100 * Number(this.cartMessage[0].getAttribute("data-limit")) * window.Shopify.currency.rate), this.bindDiscountEventListeners(), this.updateProgress()
        }
        clearDiscountErrors() {
            this.discountErrorMessage && (this.discountErrorMessage.classList.add("hidden"), this.discountErrorMessage.textContent = ""), this.discountError = !1, this.shippingDiscountError = !1, this.pendingDiscountCheck = null
        }
        bindDiscountEventListeners() {
            var t, e;
            null === (t = this.discountsButton) || void 0 === t || t.addEventListener("click", (t => {
                t.preventDefault();
                const e = this.discountsInput.value.trim();
                this.discountsInput.value = "", e && this.applyDiscount(e)
            })), null === (e = document.querySelectorAll("[data-discount-body]")) || void 0 === e || e.forEach((t => {
                var e;
                const i = t.dataset.discountCode;
                null === (e = t.querySelector("[data-discount-remove]")) || void 0 === e || e.addEventListener("click", (t => {
                    t.preventDefault(), this.removeDiscount(i)
                }))
            })), this.discountsInput && (this.onDiscountInputChange && this.discountsInput.removeEventListener("input", this.onDiscountInputChange), this.onDiscountInputChange = () => this.clearDiscountErrors(), this.discountsInput.addEventListener("input", this.onDiscountInputChange));
            const i = document.getElementById("discounts");
            if (i) {
                const t = document.querySelector(`[data-collapsible-trigger][aria-controls="${i.id}"]`);
                t && (this.onDiscountCollapsibleToggle && (t.removeEventListener("click", this.onDiscountCollapsibleToggle), t.removeEventListener("keyup", this.onDiscountCollapsibleToggle)), this.onDiscountCollapsibleToggle = () => this.clearDiscountErrors(), t.addEventListener("click", this.onDiscountCollapsibleToggle), t.addEventListener("keyup", this.onDiscountCollapsibleToggle))
            }
        }
        initCartUpdate() {
            var t;
            this.items = document.querySelectorAll("[data-cart-item]"), null === (t = this.items) || void 0 === t || t.forEach((t => {
                this.cartUpdateEvent(t)
            }))
        }
        cartUpdateEvent(t) {
            t.addEventListener("theme:cart:update", (e => {
                this.updateCart({
                    id: e.detail.id,
                    quantity: e.detail.quantity
                }, t)
            }))
        }
        cartEvents() {
            const t = document.querySelectorAll("[data-item-remove]");
            this.totalItems = t.length, null == t || t.forEach((t => {
                const e = t.closest("[data-cart-item]");
                t.addEventListener("click", (i => {
                    i.preventDefault(), t.classList.contains("is-disabled") || this.updateCart({
                        id: e.getAttribute("data-id"),
                        quantity: 0
                    }, e)
                }))
            })), this.cartCloseErrorMessage && (this.cartCloseErrorMessage.removeEventListener("click", this.closeCartError), this.cartCloseErrorMessage.addEventListener("click", this.closeCartError)), this.cartTermsCheckbox && (this.cartTermsCheckbox.removeEventListener("change", this.formSubmitHandler), this.cartCheckoutButtonWrapper.removeEventListener("click", this.formSubmitHandler), this.cartForm.removeEventListener("submit", this.formSubmitHandler), this.cartTermsCheckbox.addEventListener("change", this.formSubmitHandler), this.cartCheckoutButtonWrapper.addEventListener("click", this.formSubmitHandler), this.cartForm.addEventListener("submit", this.formSubmitHandler))
        }
        cartAddEvent(t) {
            const e = t.detail.button,
                i = null == e ? void 0 : e.matches("[data-add-to-cart]"),
                s = null == e ? void 0 : e.closest("[data-add-to-cart]");
            if (i || s) {
                var o, n, a;
                t.preventDefault(), this.button = i ? e : s, this.form = e.closest("form"), this.recipientErrors = "true" === (null === (o = this.form) || void 0 === o ? void 0 : o.getAttribute("data-recipient-errors")), this.formWrapper = this.button.closest("[data-form-wrapper]");
                const r = null === (n = this.formWrapper) || void 0 === n ? void 0 : n.classList.contains("variant--soldout"),
                    l = this.button.hasAttribute("disabled"),
                    c = this.button.closest("[data-quick-view-onboarding]"),
                    d = this.button.hasAttribute("data-notification-popup"),
                    h = null === (a = this.form) || void 0 === a ? void 0 : a.querySelector('[type="file"]');
                if (l || h || c) return;
                if (window.theme.closeAllTooltips(), r && d) return void new class {
                    init() {
                        const t = this.variantId ? `&variant=${this.variantId}` : "",
                            e = `${theme.routes.root}products/${this.handle}?section_id=api-notification${t}`;
                        this.loadPhotoswipeFromFetch(e)
                    }
                    loadPhotoswipeFromFetch(t) {
                        fetch(t).then((t => t.text())).then((t => {
                            const e = [{
                                html: t
                            }];
                            new window.theme.LoadPhotoswipe(e, Ot, _t)
                        })).catch((t => console.log("error: ", t)))
                    }
                    constructor(t) {
                        this.button = t, this.a11y = window.theme.a11y, this.a11y.state.trigger = this.button, this.handle = this.button.getAttribute("data-handle"), this.variantId = this.button.getAttribute("data-variant-id"), this.init()
                    }
                }(this.button);
                const u = new FormData(this.form),
                    p = this.form.getAttribute("data-max-inventory-reached"),
                    m = this.form.getAttribute("data-error-message-position");
                this.variantTitle = this.form.getAttribute("data-variant-title"), this.showCannotAddMoreInCart = !1, "true" === p && "cart" === m && (this.showCannotAddMoreInCart = !0), this.addToCart(u)
            }
        }
        getCart() {
            if (this.isCartDrawer && !this.isCartDrawerLoaded) {
                const t = !1;
                this.renderCartDrawer(t)
            }
            fetch(theme.routes.cart_url + "?section_id=api-cart-items").then(this.handleErrors).then((t => t.text())).then((t => {
                const e = document.createElement("div");
                e.innerHTML = t;
                const i = e.querySelector("[data-api-content]");
                this.build(i)
            })).catch((t => console.log(t)))
        }
        addToCart(t) {
            this.cartDrawerEnabled && this.button && (this.button.classList.add("is-loading"), this.button.setAttribute("disabled", !0)), fetch(theme.routes.cart_add_url, {
                method: "POST",
                headers: {
                    "X-Requested-With": "XMLHttpRequest",
                    Accept: "application/javascript"
                },
                body: t
            }).then((t => t.json())).then((t => {
                this.button.disabled = !0, this.addLoadingClass(), t.status && (this.addToCartError(t), this.removeLoadingClass(), !this.showCannotAddMoreInCart) || (this.hideAddToCartErrorMessage(), this.cartDrawerEnabled ? (this.getCart(), this.showCannotAddMoreInCart && this.updateErrorText(this.variantTitle), this.scrollToCartTop()) : window.location = theme.routes.cart_url)
            })).catch((t => console.log(t)))
        }
        updateCart(t = {}, e = null) {
            let i = t.quantity;
            null !== e && (i ? e.classList.add("is-loading") : e.classList.add("is-removed")), this.disableCartButtons(), this.addLoadingClass();
            const s = this.cart.querySelector(`[data-item="${t.id}"]`) || e,
                o = (null == s ? void 0 : s.hasAttribute("data-item-index")) ? parseInt(s.getAttribute("data-item-index")) : 0,
                n = (null == s ? void 0 : s.hasAttribute("data-item-title")) ? s.getAttribute("data-item-title") : null;
            if (0 === o) return;
            const a = {
                line: o,
                quantity: i
            };
            fetch(theme.routes.cart_change_url, {
                method: "post",
                headers: {
                    "Content-Type": "application/json",
                    Accept: "application/json"
                },
                body: JSON.stringify(a)
            }).then((t => {
                if (400 === t.status) {
                    const e = new Error(t.status);
                    throw this.cartDrawerEnabled ? this.getCart() : window.location = theme.routes.cart_url, e
                }
                return t.text()
            })).then((t => {
                if (JSON.parse(t).errors) return this.cartUpdateFailed = !0, this.updateErrorText(n), this.toggleErrorMessage(), this.resetLineItem(e), this.enableCartButtons(), this.removeLoadingClass(), void this.scrollToCartTop();
                this.getCart()
            })).catch((t => {
                console.log(t), this.enableCartButtons(), this.removeLoadingClass()
            }))
        }
        resetLineItem(t) {
            const e = t.querySelector("[data-quantity-field]"),
                i = t.querySelector("[data-quantity-select]");
            let s = e.getAttribute("value");
            const o = e.getAttribute("data-quantity-max");
            e && (e.value > o && (s = o), e.value = s, i && (i.innerText = s)), t.classList.remove("is-loading")
        }
        async applyDiscount(t) {
            const e = String(t || "").trim();
            if (!e) return;
            const i = await this.getExistingDiscountCodes(),
                s = e.toLowerCase();
            if ([...i, ...this.existingDiscountCodes].some((t => String(t).toLowerCase() === s))) return void(this.discountErrorMessage && (this.discountErrorMessage.classList.remove("hidden"), this.discountErrorMessage.textContent = window.theme.strings.discount_already_applied));
            const o = [...i, e].join(",");
            this.updateCartDiscounts(o, e)
        }
        async removeDiscount(t) {
            const e = await this.getExistingDiscountCodes(),
                i = String(t || "").toLowerCase(),
                s = e.find((t => String(t).toLowerCase() === i));
            if (!s) return;
            const o = e.filter((t => t !== s)).join(",");
            this.updateCartDiscounts(o)
        }
        createDiscountAbortController() {
            return this.activeDiscountFetch && this.activeDiscountFetch.abort(), this.activeDiscountFetch = new AbortController, this.activeDiscountFetch
        }
        async getExistingDiscountCodes() {
            try {
                const t = await fetch(`${window.Shopify.routes.root}cart.js`, {
                    headers: {
                        Accept: "application/json"
                    }
                });
                if (!t.ok) throw new Error(`HTTP error! status: ${t.status}`);
                const e = await t.json();
                return (Array.isArray(e.discount_codes) ? e.discount_codes : []).filter((t => t.applicable)).map((t => t.code))
            } catch (t) {
                return Array.isArray(this.existingDiscountCodes) ? this.existingDiscountCodes.slice() : []
            }
        }
        async updateAndParse(t, e) {
            const i = await fetch(window.theme.routes.cart_update_url, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Accept: "application/json"
                },
                body: JSON.stringify({
                    discount: t
                }),
                signal: e
            });
            if (!i.ok) throw new Error(`HTTP error! status: ${i.status}`);
            const s = await i.text();
            try {
                const t = JSON.parse(s),
                    e = Array.isArray(t.discount_codes) ? t.discount_codes : [];
                return {
                    data: t,
                    appliedCodes: e.filter((t => t.applicable)).map((t => t.code))
                }
            } catch (t) {
                throw console.error("Failed to parse cart update response:", s), new Error("Invalid JSON response from server.")
            }
        }
        async updateCartDiscounts(t, e = null) {
            this.disableCartButtons(), this.addLoadingClass(), this.discountError = !1, this.shippingDiscountError = !1;
            const i = this.createDiscountAbortController();
            try {
                const s = Array.from(document.querySelectorAll("[data-discount-body]")).map((t => {
                        var e;
                        return null == t || null === (e = t.dataset) || void 0 === e ? void 0 : e.discountCode
                    })).filter(Boolean),
                    {
                        data: o,
                        appliedCodes: n
                    } = await this.updateAndParse(t, i.signal);
                if (e) {
                    const t = (Array.isArray(o.discount_codes) ? o.discount_codes : []).find((t => t.code === e));
                    this.discountError = Boolean(t && !1 === t.applicable);
                    const i = Boolean(t && !0 === t.applicable),
                        a = n.some((t => String(t).toLowerCase() === String(e).toLowerCase()));
                    this.pendingDiscountCheck = {
                        attemptedCode: e,
                        attemptedApplicable: i,
                        codeIncluded: a,
                        visibleCodesBefore: s
                    }
                } else this.discountError = !1;
                this.existingDiscountCodes = n, this.getCart()
            } catch (t) {
                t && ("AbortError" === t.name || "string" == typeof t.message && t.message.toLowerCase().includes("abort")) || (console.log(t), this.getCart())
            } finally {
                this.activeDiscountFetch = null, this.removeLoadingClass(), this.enableCartButtons()
            }
        }
        disableCartButtons() {
            const t = this.cart.querySelectorAll("input"),
                e = this.cart.querySelectorAll("button, [data-item-remove]");
            t.length && t.forEach((t => {
                t.classList.add("is-disabled"), t.blur(), t.disabled = !0
            })), e.length && e.forEach((t => {
                t.setAttribute("disabled", !0)
            }))
        }
        enableCartButtons() {
            const t = this.cart.querySelectorAll("input"),
                e = this.cart.querySelectorAll("button, [data-item-remove]");
            t.length && t.forEach((t => {
                t.classList.remove("is-disabled"), t.disabled = !1
            })), e.length && e.forEach((t => {
                t.removeAttribute("disabled")
            }))
        }
        updateErrorText(t) {
            this.cartErrorHolder.querySelector("[data-error-message]").innerText = t
        }
        toggleErrorMessage() {
            if (this.cartErrorHolder) {
                if (this.cartErrorHolder.classList.toggle("is-expanded", this.cartUpdateFailed || this.showCannotAddMoreInCart), this.cartUpdateFailed) {
                    const t = this.cartErrorHolder.querySelector("[data-cart-error-close]");
                    this.focusOnErrorMessage(this.cartErrorHolder, t)
                }
                this.showCannotAddMoreInCart = !1, this.cartUpdateFailed = !1
            }
        }
        handleErrors(t) {
            return t.ok ? t : t.json().then((function(e) {
                throw new Ft({
                    status: t.statusText,
                    headers: t.headers,
                    json: e
                })
            }))
        }
        addToCartError(t) {
            const e = this.button.closest("[data-quickbuy-form]"),
                i = this.button.closest("[data-upsell-holder]"),
                s = !document.body.classList.contains("no-outline");
            let o = (this.button.closest("[data-product-form], [data-product-form-upsell]") ? this.button.closest("[data-product-form], [data-product-form-upsell]") : this.button.closest("[data-upsell-holder]")).querySelector("[data-cart-errors-container]");
            i && (o = i.querySelector("[data-cart-errors-container]")), this.cartDrawerEnabled && this.button && this.isCartDrawer && !this.cart.contains(this.button) && this.closeCartDrawer(), this.button.classList.remove("is-loading"), this.button.removeAttribute("disabled");
            const n = e ? "" : `\n      <button type="button" class="errors__button-close" data-close-error>\n        ${theme.icons.close}\n      </button>\n    `;
            let a = `${t.message}: ${t.description}`;
            if (t.message === t.description && (a = t.message), this.recipientErrors && t.description && "object" == typeof t.description && (a = Object.entries(t.description).map((([t, e]) => `${e}`)).join("<br>")), o.innerHTML = `\n      <div class="errors" data-error autofocus>\n        ${a}\n        ${n}\n      </div>\n    `, e) {
                const t = o.closest("[data-product-block]");
                if (!t) return;
                const e = t.querySelector("[data-product-media-container]");
                if (!e) return;
                e.classList.add("product-grid-item__image--error"), o.querySelector("[data-error]").addEventListener("animationend", (() => {
                    e.classList.remove("product-grid-item__image--error"), o.innerHTML = "", s || document.activeElement.blur()
                }))
            } else o.classList.add("is-visible"), o.addEventListener("transitionend", (() => {
                this.resizeSliders(o), o.scrollIntoView({
                    behavior: "smooth",
                    block: "end"
                })
            })), this.handleCloseErrorMessages(o)
        }
        handleCloseErrorMessages(t) {
            const e = t.querySelector("[data-close-error]");
            null == e || e.addEventListener("click", (e => {
                const i = e.target;
                (i.matches("[data-close-error]") || i.closest("[data-close-error]")) && (e.preventDefault(), t.classList.remove("is-visible"), t.querySelector("[data-error]").addEventListener("transitionend", (() => {
                    t.innerHTML = "", this.resizeSliders(i)
                })))
            })), this.focusOnErrorMessage(t, e)
        }
        focusOnErrorMessage(t, e) {
            !document.body.classList.contains("no-outline") && t.addEventListener("transitionend", (() => {
                requestAnimationFrame((() => null == e ? void 0 : e.focus({
                    focusVisible: !0
                })))
            }))
        }
        hideAddToCartErrorMessage() {
            const t = this.button.closest("[data-upsell-holder]") ? this.button.closest("[data-upsell-holder]") : this.button.closest("[data-product-form], [data-product-form-upsell]"),
                e = null == t ? void 0 : t.querySelector("[data-cart-errors-container]");
            null == e || e.classList.remove("is-visible")
        }
        resizeSliders(t) {
            const e = t.closest(".flickity-enabled");
            if (!e) return;
            const i = window.theme.Flickity.data(e);
            requestAnimationFrame((() => i.resize()))
        }
        renderCartDrawer(t = !0) {
            if (!this.isCartDrawer) return;
            const e = this.cart.querySelector("[data-cart-drawer-template]");
            e && (this.cart.innerHTML = e.innerHTML, this.assignArguments(), this.initCartUpdate(), this.cartEvents(), this.bindDiscountEventListeners(), this.cartDrawerToggle = this.cart.querySelector("[data-cart-drawer-toggle]"), this.cartDrawerToggle.addEventListener("click", this.cartDrawerToggleClickEvent), this.isCartDrawerLoaded = !0, this.renderPairProducts(), document.dispatchEvent(new CustomEvent("theme:cart:loaded", {
                bubbles: !0
            })), t && this.openCartDrawer())
        }
        openCartDrawer() {
            this.isCartDrawer && !this.isCartDrawerOpen && (this.isCartDrawerLoaded ? (window.theme.closeAllTooltips(), document.dispatchEvent(new CustomEvent("theme:cart:open", {
                bubbles: !0
            })), document.dispatchEvent(new CustomEvent("theme:scroll:lock", {
                bubbles: !0,
                detail: this.cart
            })), document.dispatchEvent(new CustomEvent("theme:scroll:lock", {
                bubbles: !0,
                detail: this.cartDrawerBody
            })), this.scrollToCartTop(), document.body.classList.add("js-drawer-open-cart"), this.cart.classList.add("is-open"), this.cart.classList.remove("cv-h"), requestAnimationFrame((() => this.animateCartItems("in"))), this.cartToggleButtons.forEach((t => {
                t.setAttribute("aria-expanded", !0)
            })), this.a11y.trapFocus({
                container: this.cart
            }), this.observeAdditionalCheckoutButtons(), this.isCartDrawerOpen = !0) : this.renderCartDrawer())
        }
        animateCartItems(t = "in") {
            const e = this.cart.querySelectorAll("[data-aos]");
            "in" === t && e.forEach((t => requestAnimationFrame((() => t.classList.add("aos-animate"))))), "out" === t && e.forEach((t => t.classList.remove("aos-animate")))
        }
        closeCartDrawer() {
            if (!this.isCartDrawer || !this.isCartDrawerOpen) return;
            document.dispatchEvent(new CustomEvent("theme:cart:close", {
                bubbles: !0
            })), this.cartErrorHolder.classList.remove("is-expanded"), this.a11y.removeTrapFocus(), this.cartToggleButtons.forEach((t => {
                t.setAttribute("aria-expanded", !1)
            })), document.body.classList.remove("js-drawer-open-cart"), this.cart.classList.remove("is-open"), this.itemsHolder.classList.remove("is-updated");
            const t = e => {
                e.target === this.cart && (this.animateCartItems("out"), this.cart.removeEventListener("transitionend", t))
            };
            this.cart.addEventListener("transitionend", t);
            !document.body.classList.contains("no-outline") || requestAnimationFrame((() => {
                document.activeElement.blur()
            }));
            document.dispatchEvent(new CustomEvent("theme:scroll:unlock", {
                bubbles: !0,
                detail: 400
            })), this.isCartDrawerOpen = !1
        }
        toggleCartDrawer() {
            this.isCartDrawer && (this.isCartDrawerOpen ? this.closeCartDrawer() : this.openCartDrawer())
        }
        cartDrawerToggleEvents() {
            this.isCartDrawer && (this.cart.addEventListener("keyup", (t => {
                t.code === theme.keyboardKeys.ESCAPE && this.closeCartDrawer()
            })), this.cartDrawerToggleClickEvent = t => {
                t.preventDefault();
                const e = t.target;
                "false" === e.getAttribute("aria-expanded") && (this.a11y.state.trigger = e), this.toggleCartDrawer()
            }, this.cartDrawerCloseEvent = t => {
                const e = t.target.matches("[data-cart-drawer-toggle]"),
                    i = this.cart.contains(t.target),
                    s = t.target.closest(".popup-quick-view");
                e || i || s || this.closeCartDrawer()
            }, this.cartToggleButtons.forEach((t => {
                t.addEventListener("click", this.cartDrawerToggleClickEvent)
            })), document.addEventListener("mousedown", this.cartDrawerCloseEvent))
        }
        toggleClassesOnContainers() {
            const t = this;
            this.isCartPage ? this.buttonHolder.classList.toggle("hidden", !t.hasItemsInCart()) : (this.pairProductsHolder.classList.toggle("hidden", !t.hasItemsInCart()), this.cartForm.classList.toggle("hidden", !t.hasItemsInCart()), this.emptyMessageBottom.classList.toggle("hidden", t.hasItemsInCart()), this.cartNoteHolder.classList.toggle("hidden", !t.hasItemsInCart())), this.emptyMessage.classList.toggle("hidden", t.hasItemsInCart()), this.itemsHolder.classList.toggle("hidden", !t.hasItemsInCart()), this.cartItemsQty.classList.toggle("hidden", !t.hasItemsInCart())
        }
        build(t) {
            const e = t.querySelector("[data-api-line-items]"),
                i = t.querySelector("[data-api-upsell-items]"),
                s = Boolean(null === e && null === i),
                o = t.querySelector("[data-api-cart-price]"),
                n = t.querySelector("[data-cart-total]");
            if (this.priceHolder && o && (this.priceHolder.innerHTML = o.innerHTML), this.animateCartItems("out"), s ? (this.itemsHolder.innerHTML = "", this.pairProductsHolder && (this.pairProductsHolder.innerHTML = "")) : (this.itemsHolder.innerHTML = e.innerHTML, this.pairProductsHolder && (this.pairProductsHolder.innerHTML = i.innerHTML), this.renderPairProducts()), this.newTotalItems = e && e.querySelectorAll("[data-cart-item]").length ? e.querySelectorAll("[data-cart-item]").length : 0, this.subtotal = n && n.hasAttribute("data-cart-total") ? parseInt(n.getAttribute("data-cart-total")) : 0, this.cartCount = this.getCartItemCount(), this.cartMessage.length > 0 && this.updateProgress(), this.cartToggleButtons.forEach((t => {
                    t.classList.remove("cart__toggle--has-items"), this.newTotalItems > 0 && t.classList.add("cart__toggle--has-items")
                })), this.toggleErrorMessage(), this.updateItemsQuantity(this.cartCount), this.cartTotalPrice.innerHTML = 0 === this.subtotal ? window.theme.strings.free : window.theme.formatMoney(this.subtotal, theme.moneyWithCurrencyFormat), this.totalItems !== this.newTotalItems && (this.totalItems = this.newTotalItems, this.toggleClassesOnContainers()), (this.isCartDrawerOpen || this.isCartPage) && this.itemsHolder.classList.add("is-updated"), this.cartEvents(), this.initCartUpdate(), this.bindDiscountEventListeners(), this.discountsField && (this.discountsField.value = this.existingDiscountCodes.join(",")), this.pendingDiscountCheck) {
                const t = Array.from(this.cart.querySelectorAll("[data-discount-body]")).map((t => {
                        var e;
                        return null == t || null === (e = t.dataset) || void 0 === e ? void 0 : e.discountCode
                    })).filter(Boolean).map((t => String(t).toLowerCase())),
                    e = new Set(this.pendingDiscountCheck.visibleCodesBefore.map((t => String(t).toLowerCase()))),
                    i = String(this.pendingDiscountCheck.attemptedCode).toLowerCase(),
                    s = t.includes(i) && !e.has(i);
                this.shippingDiscountError = Boolean(this.pendingDiscountCheck.attemptedApplicable && this.pendingDiscountCheck.codeIncluded && !s), this.pendingDiscountCheck = null
            }
            if (this.shippingDiscountError) this.discountErrorMessage && (this.discountErrorMessage.textContent = window.theme.strings.shipping_discounts_at_checkout, this.discountErrorMessage.classList.remove("hidden"));
            else if (this.discountError) this.discountErrorMessage && (this.discountErrorMessage.textContent = window.theme.strings.discount_not_applicable, this.discountErrorMessage.classList.remove("hidden"));
            else {
                var a;
                null === (a = this.discountErrorMessage) || void 0 === a || a.classList.add("hidden")
            }
            if (this.enableCartButtons(), this.resetButtonClasses(), this.removeLoadingClass(), document.dispatchEvent(new CustomEvent("theme:cart:added", {
                    bubbles: !0
                })), this.isCartDrawer) {
                this.openCartDrawer();
                const t = e => {
                    e.target === this.cart && (this.animateCartItems("in"), this.cart.removeEventListener("transitionend", t))
                };
                this.cart.addEventListener("transitionend", t)
            }
            requestAnimationFrame((() => this.animateCartItems("in")))
        }
        getCartItemCount() {
            return this.cart ? Array.from(this.cart.querySelectorAll("[data-quantity-field]")).reduce(((t, e) => t + parseInt(e.value)), 0) : 0
        }
        hasItemsInCart() {
            return this.totalItems > 0
        }
        freeShippingMessageHandle(t) {
            this.cartMessage.length > 0 && document.querySelectorAll("[data-cart-message]").forEach((e => {
                const i = e.hasAttribute("data-cart-message") && "true" === e.getAttribute("data-cart-message") && 0 !== t,
                    s = e.querySelector("[data-message-default]");
                e.classList.toggle("is-success", t >= this.cartFreeLimitShipping && i), e.classList.toggle("is-hidden", 0 === t), s && s.classList.toggle("is-hidden", t >= this.cartFreeLimitShipping)
            }))
        }
        updateProgress() {
            const t = this.subtotal / this.cartFreeLimitShipping * 100;
            let e = window.theme.formatMoney(this.cartFreeLimitShipping - this.subtotal, theme.moneyFormat);
            (e.endsWith(".00") || e.endsWith(",00")) && (e = e.slice(0, -3)), theme.settings.currency_code_enable && (e += ` ${theme.current_iso_code}`), this.cartMessage.length > 0 && document.querySelectorAll("[data-cart-message]").forEach((i => {
                const s = i.querySelectorAll("[data-cart-message-progress]"),
                    o = i.querySelector("[data-left-to-spend]");
                o && (o.innerHTML = e), s.length && s.forEach(((e, i) => {
                    e.classList.toggle("is-hidden", this.subtotal / this.cartFreeLimitShipping >= 1), e.style.setProperty("--progress-width", `${t}%`), 0 === i && e.setAttribute("value", t)
                })), this.freeShippingMessageHandle(this.subtotal)
            }))
        }
        renderPairProducts() {
            if (this.flktyUpsell = null, this.pairProductsHolder = document.querySelector("[data-pair-products-holder]"), this.pairProducts = document.querySelector("[data-pair-products]"), this.upsellHolders = document.querySelectorAll("[data-upsell-holder]"), null === this.pairProductsHolder || void 0 === this.pairProductsHolder) return;
            const t = this;
            if (this.upsellHolders.length > 1) {
                const e = new window.theme.Flickity(this.pairProducts, {
                    wrapAround: !0,
                    pageDots: !0,
                    adaptiveHeight: !0,
                    prevNextButtons: !1,
                    on: {
                        ready: function() {
                            this.reloadCells(), requestAnimationFrame((() => this.resize())), t.upsellHolders.forEach((t => {
                                if (!t.classList.contains("is-selected")) {
                                    const e = t.querySelectorAll("a, button");
                                    e.length && e.forEach((t => {
                                        t.setAttribute("tabindex", "-1")
                                    }))
                                }
                            }))
                        }
                    }
                });
                e.on("change", (t => {
                    e.cells.forEach(((e, i) => {
                        const s = e.element.querySelectorAll("a, button");
                        s.length && s.forEach((e => {
                            e.setAttribute("tabindex", i === t ? "0" : "-1")
                        }))
                    }))
                }))
            } else;
        }
        updateItemsQuantity(t) {
            let e = theme.strings.cart_items_one,
                i = theme.strings.cart_items_many;
            e = e.split("}}")[1], i = i.split("}}")[1], this.cartItemsQty && (this.cartItemsQty.textContent = 1 === t ? `${t} ${e}` : `${t} ${i}`)
        }
        observeAdditionalCheckoutButtons() {
            const t = this.cart.querySelector("[data-additional-checkout-button]");
            if (t) {
                const e = new MutationObserver((() => {
                    this.a11y.removeTrapFocus(), this.a11y.trapFocus({
                        container: this.cart
                    }), e.disconnect()
                }));
                e.observe(t, {
                    subtree: !0,
                    childList: !0
                })
            }
        }
        formSubmitHandler() {
            const t = document.querySelector("[data-cart-acceptance-checkbox]").checked,
                e = document.querySelector("[data-terms-error-message]");
            if (t) e.classList.remove("is-expanded"), this.cartCheckoutButton.removeAttribute("disabled");
            else {
                if (document.querySelector("[data-terms-error-message]").length > 0) return;
                e.innerText = theme.strings.cart_acceptance_error, this.cartCheckoutButton.setAttribute("disabled", !0), e.classList.add("is-expanded")
            }
            this.discountsField && (this.discountsField.value = this.existingDiscountCodes.join(","))
        }
        resetButtonClasses() {
            const t = document.querySelectorAll("[data-add-to-cart]");
            t && t.forEach((t => {
                t.classList.contains("is-loading") && (t.classList.remove("is-loading"), t.classList.add("is-success"), setTimeout((() => {
                    t.removeAttribute("disabled"), t.classList.remove("is-success")
                }), Vt.timers.addProductTimeout))
            }))
        }
        addLoadingClass() {
            this.isCartDrawer ? this.cart.classList.add("is-loading") : this.itemsWrapper && this.itemsWrapper.classList.add("is-loading")
        }
        removeLoadingClass() {
            this.isCartDrawer ? this.cart.classList.remove("is-loading") : this.itemsWrapper && this.itemsWrapper.classList.remove("is-loading")
        }
        scrollToCartTop() {
            var t;
            this.isCartDrawer ? this.cartDrawerBody.scrollTo({
                top: 0,
                left: 0,
                behavior: "instant"
            }) : window.scrollTo({
                top: (null === (t = this.outerSection) || void 0 === t ? void 0 : t.offsetTop) - this.headerInitialHeight - this.announcementBarHeight,
                left: 0,
                behavior: "smooth"
            })
        }
        disconnectedCallback() {
            document.removeEventListener("theme:cart:add", this.cartAddEvent), this.isCartDrawer && (this.cartDrawerToggle && this.cartDrawerToggle.removeEventListener("click", this.cartDrawerToggleClickEvent), this.cartToggleButtons.forEach((t => {
                t.removeEventListener("click", this.cartDrawerToggleClickEvent)
            })), document.removeEventListener("mousedown", this.cartDrawerCloseEvent), document.removeEventListener("theme:popup:open", this.closeCartDrawer), document.removeEventListener("theme:cart:refresh", this.getCart)), this.cartCloseErrorMessage && this.cartCloseErrorMessage.removeEventListener("click", this.closeCartError)
        }
        constructor() {
            super()
        }
    }), customElements.get("drawer-element") || customElements.define("drawer-element", class extends HTMLElement {
        connectedCallback() {
            this.initListeners(), this.initMutationObserver(), this.isMobileMenu && this.initMobileMenuBehavior(), this.checkScroll()
        }
        disconnectedCallback() {
            this.removeEventListener("theme:drawer:toggle", this.handleToggle), document.removeEventListener("theme:drawer:opening", this.handleDrawerOpening), document.removeEventListener("click", this.handleOutsideClick), this.removeEventListener("keyup", this.handleKeyPress), window.removeEventListener("resize", this.checkScroll), document.removeEventListener("theme:drawer:open", this.checkScroll), this.mutationObserver && this.mutationObserver.disconnect()
        }
        initListeners() {
            this.addEventListener("theme:drawer:toggle", this.handleToggle), document.addEventListener("theme:drawer:opening", this.handleDrawerOpening), document.addEventListener("click", this.handleOutsideClick), this.addEventListener("keyup", this.handleKeyPress), window.addEventListener("resize", this.checkScroll), document.addEventListener("theme:drawer:open", this.checkScroll)
        }
        handleDrawerOpening(t) {
            const e = t.detail.element;
            if (e && e.hasAttribute("data-mobile-menu-trigger") && this.isMobileMenu) {
                this.determineMobileMenuTarget() === this && this.open(t)
            }
        }
        determineMobileMenuTarget() {
            const t = document.querySelector("drawer-element[data-drawer-header]"),
                e = document.querySelector("drawer-element[data-drawer-section]");
            return "new" === theme.settings.mobileMenuType && e || t
        }
        handleToggle(t) {
            t.preventDefault();
            const e = t.detail.trigger;
            this.classList.contains("is-open") ? this.close() : this.open({
                detail: {
                    element: e
                },
                target: e
            })
        }
        handleKeyPress(t) {
            t.code === theme.keyboardKeys.ESCAPE && this.close(t)
        }
        handleOutsideClick(t) {
            var e;
            const i = document.querySelector("drawer-element.is-open");
            if (!i || i !== this) return;
            const s = (null === (e = t.target.closest("button")) || void 0 === e ? void 0 : e.querySelector("drawer-toggle")) || t.target.closest("drawer-toggle"),
                o = this.contains(t.target),
                n = this.closest("[data-quick-view-item]"),
                a = !!n && n.contains(t.target);
            s || o || a || this.close()
        }
        open(t) {
            var e;
            let i = (null == t || null === (e = t.detail) || void 0 === e ? void 0 : e.element) || (null == t ? void 0 : t.target);
            const s = this.querySelector("[data-scroll]") || this;
            window.theme.closeAllTooltips(), document.dispatchEvent(new CustomEvent("theme:scroll:lock", {
                bubbles: !0,
                detail: s
            })), document.dispatchEvent(new CustomEvent("theme:drawer:open", {
                bubbles: !0
            })), this.body.classList.add("js-drawer-open");
            const o = null == i ? void 0 : i.getAttribute("aria-controls");
            ((null == o ? void 0 : o.includes("size-chart")) || (null == o ? void 0 : o.includes("popup-text"))) && (this.body.classList.add("js-drawer-open--inner"), o.includes("quickview") && this.body.classList.add("js-drawer-open--inner-qv")), this.classList.add("is-open"), this.setAttribute("aria-hidden", !1), this.classList.remove("cv-h"), i && i.setAttribute("aria-expanded", !0);
            const n = t => {
                const e = "transform" === t.propertyName || "top" === t.propertyName;
                t.target === this && e && (this.a11y.state.trigger = i, this.a11y.trapFocus({
                    container: this
                }), this.removeEventListener("transitionend", n))
            };
            this.addEventListener("transitionend", n)
        }
        close(t = !1) {
            if (!this.body.classList.contains("js-drawer-open")) return;
            document.querySelectorAll("drawer-toggle").forEach((t => t.updateAriaExpanded(!1))), this.a11y.removeTrapFocus({
                container: this
            }), this.classList.remove("is-open");
            const e = t => {
                t.target === this && (requestAnimationFrame((() => {
                    this.classList.add("cv-h"), document.dispatchEvent(new CustomEvent("theme:drawer:close", {
                        bubbles: !0
                    })), document.dispatchEvent(new CustomEvent("theme:scroll:unlock", {
                        bubbles: !0
                    })), this.setAttribute("aria-hidden", !0)
                })), this.removeEventListener("transitionend", e))
            };
            if (this.addEventListener("transitionend", e), this.body.classList.remove("js-drawer-open"), this.body.classList.remove("js-drawer-open--inner"), this.body.classList.contains("js-drawer-open--inner-qv")) {
                if (this.body.classList.remove("js-drawer-open--inner-qv"), t && t.code === theme.keyboardKeys.ESCAPE) return this.a11y.state.trigger = this.a11y.state.mainTrigger, void this.a11y.state.trigger.focus();
                const e = this.a11y.state.trigger.closest("[data-quick-view-focus]");
                this.a11y.trapFocus({
                    container: e,
                    elementToFocus: this.a11y.state.trigger
                }), this.a11y.state.trigger = this.a11y.state.mainTrigger
            }
        }
        initMobileMenuBehavior() {
            const t = this.querySelectorAll("[data-nav-search-open]");
            if (null == t || t.forEach((t => {
                    t.addEventListener("click", (e => {
                        e.preventDefault();
                        const i = document.querySelector("[data-mobile-menu]"),
                            s = document.querySelector("[data-nav-items-compress]");
                        let o = matchMedia("(pointer:coarse)").matches;
                        window.innerWidth < theme.sizes.small && window.Shopify.designMode && (o = !0);
                        const n = o ? null == i ? void 0 : i.querySelector("[data-popdown-toggle]") : null == s ? void 0 : s.querySelector("[data-popdown-toggle]");
                        this.dispatchEvent(new CustomEvent("theme:drawer:toggle", {
                            detail: {
                                trigger: t
                            }
                        }));
                        const a = t => {
                            t.target === this && (requestAnimationFrame((() => null == n ? void 0 : n.dispatchEvent(new Event("click", {
                                bubbles: !0
                            })))), this.removeEventListener("transitionend", a))
                        };
                        this.addEventListener("transitionend", a)
                    }))
                })), "link" === theme.settings.mobileMenuBehaviour) return;
            const e = this.querySelectorAll("[data-nav-link-mobile]");
            e.length && e.forEach((t => {
                t.addEventListener("click", (e => {
                    const i = t.parentNode.querySelectorAll("[data-collapsible-trigger]").length,
                        s = t.nextElementSibling;
                    i && (e.preventDefault(), s.dispatchEvent(new Event("click"), {
                        bubbles: !0
                    }))
                }))
            }))
        }
        initMutationObserver() {
            const t = this.querySelector("[data-scrollable-menu-blocks]");
            t && (this.mutationObserver = new MutationObserver((t => {
                t.some((t => "childList" === t.type || "attributes" === t.type && ("style" === t.attributeName || "class" === t.attributeName))) && this.checkScroll()
            })), this.mutationObserver.observe(t, {
                childList: !0,
                subtree: !0,
                attributes: !0
            }))
        }
        checkScroll() {
            const t = this.querySelector("[data-scrollable-menu-blocks]");
            if (!t) return;
            const e = t.scrollHeight > t.clientHeight;
            t.classList.toggle("drawer__content-scroll--has-scroll", e)
        }
        constructor() {
            super(), this.body = document.body, this.a11y = window.theme.a11y, this.isMobileMenu = this.hasAttribute("data-drawer-header") || this.hasAttribute("data-drawer-section"), this.handleToggle = this.handleToggle.bind(this), this.handleKeyPress = this.handleKeyPress.bind(this), this.handleOutsideClick = this.handleOutsideClick.bind(this), this.checkScroll = this.checkScroll.bind(this), this.handleDrawerOpening = this.handleDrawerOpening.bind(this)
        }
    }), customElements.get("drawer-toggle") || customElements.define("drawer-toggle", class extends HTMLElement {
        connectedCallback() {
            this.button = this.closest("button"), this.button.setAttribute("aria-expanded", "false"), this.button.addEventListener("click", this.handleClick)
        }
        disconnectedCallback() {
            this.button && this.button.removeEventListener("click", this.handleClick)
        }
        handleClick(t) {
            t.preventDefault(), this.button.hasAttribute("data-mobile-menu-trigger") ? this.handleMobileMenuTrigger(t) : this.handleStandardToggle(t)
        }
        handleMobileMenuTrigger(t) {
            document.dispatchEvent(new CustomEvent("theme:drawer:opening", {
                bubbles: !0,
                detail: {
                    element: this.button
                }
            }))
        }
        handleStandardToggle(t) {
            const e = this.button.getAttribute("aria-controls");
            if (!e) return void console.warn("DrawerToggle: Missing aria-controls attribute on button");
            const i = document.getElementById(e);
            i ? i.dispatchEvent(new CustomEvent("theme:drawer:toggle", {
                detail: {
                    trigger: this.button
                }
            })) : console.warn(`DrawerToggle: Target drawer "${e}" not found`)
        }
        updateAriaExpanded(t) {
            this.button && this.button.setAttribute("aria-expanded", t.toString())
        }
        constructor() {
            super(), this.handleClick = this.handleClick.bind(this)
        }
    });
    const Bt = {};

    function $t(t = {}) {
        if (t.type || (t.type = "json"), t.url) return Bt[t.url] ? Bt[t.url] : function(t, e) {
            const i = new Promise(((i, s) => {
                "text" === e ? fetch(t).then((t => t.text())).then((t => {
                    i(t)
                })).catch((t => {
                    s(t)
                })) : function(t, e, i) {
                    let s = document.getElementsByTagName("head")[0],
                        o = !1,
                        n = document.createElement("script");
                    n.src = t, n.onload = n.onreadystatechange = function() {
                        o || this.readyState && "loaded" != this.readyState && "complete" != this.readyState ? i() : (o = !0, e())
                    }, s.appendChild(n)
                }(t, (function() {
                    i()
                }), (function() {
                    s()
                }))
            }));
            return Bt[t] = i, i
        }(t.url, t.type);
        if (t.json) return Bt[t.json] ? Promise.resolve(Bt[t.json]) : window.fetch(t.json).then((t => t.json())).then((e => (Bt[t.json] = e, e)));
        if (t.name) {
            const e = "".concat(t.name, t.version);
            return Bt[e] ? Bt[e] : function(t) {
                const e = "".concat(t.name, t.version),
                    i = new Promise(((e, i) => {
                        try {
                            window.Shopify.loadFeatures([{
                                name: t.name,
                                version: t.version,
                                onLoad: t => {
                                    ! function(t, e, i) {
                                        i ? e(i) : t()
                                    }(e, i, t)
                                }
                            }])
                        } catch (t) {
                            i(t)
                        }
                    }));
                return Bt[e] = i, i
            }(t)
        }
        return Promise.reject()
    }
    window.isYoutubeAPILoaded = !1, window.isVimeoAPILoaded = !1;
    const Wt = "html5",
        Rt = "youtube",
        zt = "vimeo",
        Nt = "[data-deferred-media-button]",
        Ut = "[data-product-single-media-wrapper]",
        jt = "[data-product-single-media-group]",
        Qt = "[data-media-id]",
        Kt = ".media--hidden",
        Yt = "media--hidden",
        Xt = "is-loading",
        Gt = "loaded",
        Jt = "data-autoplay-video",
        Zt = "data-media-id";
    let te = class extends HTMLElement {
        connectedCallback() {
            const t = this.querySelector(Nt);
            t && t.addEventListener("click", (() => {
                this.loadContent()
            })), this.autoplayVideo && this.loadContent()
        }
        loadContent() {
            if (this.getAttribute(Gt)) return;
            this.mediaContainer.classList.add(Xt);
            const t = document.createElement("div");
            switch (t.appendChild(this.querySelector("template").content.firstElementChild.cloneNode(!0)), this.element = t.querySelector("video, iframe, model-viewer"), this.appendChild(this.element), this.setAttribute("loaded", !0), this.host = this.hostFromVideoElement(this.element), this.element.addEventListener("load", (() => {
                this.mediaContainer.classList.remove(Xt)
            })), this.host) {
                case Wt:
                    this.createPlayer(this.mediaId);
                    break;
                case zt:
                    window.isVimeoAPILoaded ? this.createPlayer(this.mediaId) : $t({
                        url: "https://player.vimeo.com/api/player.js"
                    }).then((() => this.createPlayer(this.mediaId)));
                    break;
                case Rt:
                    window.isYoutubeAPILoaded ? this.createPlayer(this.mediaId) : $t({
                        url: "https://www.youtube.com/iframe_api"
                    }).then((() => this.createPlayer(this.mediaId)))
            }
        }
        hostFromVideoElement(t) {
            if ("VIDEO" === t.tagName) return Wt;
            if ("IFRAME" === t.tagName) {
                if (/^(https?:\/\/)?(www\.)?(youtube\.com|youtube-nocookie\.com|youtu\.?be)\/.+$/.test(t.src)) return Rt;
                if (t.src.includes("vimeo.com")) return zt
            }
            return null
        }
        createPlayer() {
            switch (this.host) {
                case Wt:
                    this.element.addEventListener("play", (() => {
                        this.mediaContainer.dispatchEvent(new CustomEvent("theme:media:play"), {
                            bubbles: !0
                        })
                    })), this.element.addEventListener("pause", (() => {
                        this.mediaContainer.dispatchEvent(new CustomEvent("theme:media:pause"), {
                            bubbles: !0
                        })
                    })), this.autoplayVideo && this.observeVideo();
                    break;
                case zt:
                    this.player = new Vimeo.Player(this.element), this.player.play(), this.mediaContainer.dispatchEvent(new CustomEvent("theme:media:play"), {
                        bubbles: !0
                    }), window.isVimeoAPILoaded = !0, this.player.on("play", (() => {
                        this.mediaContainer.dispatchEvent(new CustomEvent("theme:media:play"), {
                            bubbles: !0
                        })
                    })), this.player.on("pause", (() => {
                        this.mediaContainer.dispatchEvent(new CustomEvent("theme:media:pause"), {
                            bubbles: !0
                        })
                    })), this.autoplayVideo && this.observeVideo();
                    break;
                case Rt:
                    if (this.host == Rt && this.player) return;
                    YT.ready((() => {
                        const t = this.mediaContainer.dataset.videoId;
                        this.player = new YT.Player(this.element, {
                            videoId: t,
                            events: {
                                onReady: t => {
                                    t.target.playVideo(), this.mediaContainer.dispatchEvent(new CustomEvent("theme:media:play"), {
                                        bubbles: !0
                                    })
                                },
                                onStateChange: t => {
                                    1 == t.data && this.mediaContainer.dispatchEvent(new CustomEvent("theme:media:play"), {
                                        bubbles: !0
                                    }), 2 == t.data && this.mediaContainer.dispatchEvent(new CustomEvent("theme:media:pause"), {
                                        bubbles: !0
                                    }), 0 == t.data && this.mediaContainer.dispatchEvent(new CustomEvent("theme:media:pause"), {
                                        bubbles: !0
                                    })
                                }
                            }
                        }), window.isYoutubeAPILoaded = !0, this.autoplayVideo && this.observeVideo()
                    }))
            }
            this.mediaContainer.addEventListener("theme:media:visible", (t => this.onVisible(t))), this.mediaContainer.addEventListener("theme:media:hidden", (t => this.onHidden(t))), this.mediaContainer.addEventListener("xrLaunch", (t => this.onHidden(t)))
        }
        observeVideo() {
            new IntersectionObserver(((t, e) => {
                t.forEach((t => {
                    const e = 0 == t.intersectionRatio,
                        i = !this.element.closest(Kt);
                    e ? this.pauseVideo() : i && this.playVideo()
                }))
            }), {
                rootMargin: "200px",
                threshold: [0, .25, .75, 1]
            }).observe(this.element)
        }
        playVideo() {
            this.player && this.player.playVideo ? this.player.playVideo() : this.element && this.element.play ? this.element.play() : this.player && this.player.play && this.player.play(), this.mediaContainer.dispatchEvent(new CustomEvent("theme:media:play"), {
                bubbles: !0
            })
        }
        pauseVideo() {
            if (this.player && this.player.pauseVideo) "1" == this.player.playerInfo.playerState && this.player.pauseVideo();
            else if (this.player && this.player.pause) this.player.pause();
            else if (this.element && !this.element.paused) {
                var t;
                if ("function" == typeof this.element.pause) null === (t = this.element) || void 0 === t || t.pause()
            }
        }
        onHidden(t) {
            void 0 !== t.target.dataset.mediaId && this.pauseVideo()
        }
        onVisible(t) {
            void 0 !== t.target.dataset.mediaId && (setTimeout((() => {
                this.playVideo()
            }), 50), this.pauseContainerMedia())
        }
        pauseOtherMedia() {
            const t = `[${Zt}="${this.mediaId}"]`,
                e = this.closest(jt).querySelectorAll(`${Ut}:not(${t})`);
            e.length && e.forEach((t => {
                t.dispatchEvent(new CustomEvent("theme:media:hidden"), {
                    bubbles: !0
                }), t.classList.add(Yt)
            }))
        }
        constructor() {
            var t;
            super(), this.autoplayVideo = "true" === this.getAttribute(Jt), this.mediaContainer = this.closest(Qt), this.mediaId = null === (t = this.mediaContainer) || void 0 === t ? void 0 : t.dataset.mediaId, this.element = null, this.host = null, this.player = null, this.pauseContainerMedia = () => this.pauseOtherMedia()
        }
    };
    customElements.get("deferred-media") || customElements.define("deferred-media", te), window.theme.DeferredMedia = window.theme.DeferredMedia || te;
    const ee = "[data-collapsible]",
        ie = "toggle-ellipsis",
        se = "[data-content]",
        oe = "[data-actions]",
        ne = "[data-height]",
        ae = "[data-collapsible-content]",
        re = "[data-collapsible-container]",
        le = "[data-collapsible-single]",
        ce = "[data-collapsible-trigger]",
        de = "[data-collapsible-transition-override]",
        he = "is-expanded",
        ue = "is-open",
        pe = "aria-expanded",
        me = "aria-controls",
        ge = "data-collapsible-trigger-mobile",
        ve = "data-collapsible-single",
        be = 500;
    customElements.get("collapsible-elements") || customElements.define("collapsible-elements", class extends HTMLElement {
        connectedCallback() {
            window.addEventListener("theme:resize:width", this.onResizeEvent), this.triggers.forEach((t => {
                t.addEventListener("click", this.collapsibleToggleEvent), t.addEventListener("keyup", this.collapsibleToggleEvent)
            })), this.addEventListener("theme:ellipsis:toggle", (t => {
                this.handleEllipsisToggle(t)
            }))
        }
        disconnectedCallback() {
            window.removeEventListener("theme:resize:width", this.onResizeEvent)
        }
        handleEllipsisToggle(t) {
            const {
                dropdownHeight: e = 0,
                isExpanded: i = !1
            } = t.detail, s = t.target.closest(ee);
            if (!s) return;
            const o = s.querySelector(ce);
            if (!o) return;
            const n = o.getAttribute(me),
                a = document.getElementById(n);
            if (!a) return;
            const r = s.querySelector(ne),
                l = r && parseInt(r.dataset.height, 10) || 0;
            this.setDropdownHeight(a, i ? e : l)
        }
        collapsibleToggle(t) {
            t.preventDefault();
            const e = t.target.matches(ce) ? t.target : t.target.closest(ce),
                i = e.getAttribute(me),
                s = document.getElementById(i),
                o = e.hasAttribute(ge),
                n = e.classList.contains(he),
                a = t.code === theme.keyboardKeys.SPACE,
                r = t.code === theme.keyboardKeys.ESCAPE,
                l = window.innerWidth < theme.sizes.small;
            this.isTransitioning && !this.transitionOverride || (!t.code || a || r) && (!n && r || o && !l || (this.isTransitioning = !0, e.disabled = !0, this.single && this.closeOtherItems(e), requestAnimationFrame((() => {
                n ? this.closeItem(s, e) : this.openItem(s, e)
            }))))
        }
        closeOtherItems(t) {
            const e = t.closest(le);
            this.triggers.forEach((i => {
                if (t === i || !i.classList.contains(he)) return;
                const s = i.closest(le);
                if (e !== s) return;
                const o = document.getElementById(i.getAttribute(me));
                requestAnimationFrame((() => this.closeItem(o, i)))
            }))
        }
        openItem(t, e) {
            const i = t.querySelector(ae).offsetHeight;
            this.setDropdownHeight(t, i), this.handleTransitioning(t, !0), this.updateAttributes(e, t, !0), e.dispatchEvent(new CustomEvent("theme:form:sticky", {
                bubbles: !0,
                detail: {
                    element: "accordion"
                }
            }))
        }
        closeItem(t, e) {
            let i = t.querySelector(ae).offsetHeight;
            this.setDropdownHeight(t, i), this.handleTransitioning(t, !1), this.updateAttributes(e, t, !1), requestAnimationFrame((() => {
                i = 0, this.setDropdownHeight(t, 0)
            }))
        }
        setDropdownHeight(t, e) {
            t.style.height = `${e}px`
        }
        handleTransitioning(t, e = !1) {
            this.resetHeightTimer && clearTimeout(this.resetHeightTimer), e ? this.resetHeightTimer = setTimeout((() => {
                t.querySelector(ie) || (t.style.height = "auto"), this.isTransitioning = !1
            }), be) : (this.isTransitioning = !1, this.resetHeightTimer = setTimeout((() => {
                t.style.height = ""
            }), be))
        }
        updateAttributes(t, e, i) {
            e.classList.toggle(he, i), t.setAttribute(pe, i), t.classList.toggle(he, i), setTimeout((() => {
                t.disabled = !1
            }), be)
        }
        onResize() {
            if (!this.querySelector(`.${he}`)) return;
            const t = Array.from(document.querySelectorAll(`${ee}:has(.${he})`)),
                e = document.querySelectorAll(`${ee}:has(${ie}.${ue})`);
            t.forEach((t => {
                const e = t.querySelector(ie);
                (null == e ? void 0 : e.classList.contains(ue)) && this.updateDropdownHeight(t)
            })), e.forEach((e => {
                t.includes(e) || this.updateDropdownHeight(e, !0)
            }))
        }
        constructor() {
            super(),
                function(t, e, i) {
                    e in t ? Object.defineProperty(t, e, {
                        value: i,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : t[e] = i
                }(this, "updateDropdownHeight", ((t, e = !1) => {
                    const i = t.querySelector(re),
                        s = t.querySelector(ie),
                        o = s.querySelector(oe),
                        n = s.querySelector(se).offsetHeight + 2 * o.offsetHeight;
                    e || this.setDropdownHeight(i, n), s.style.setProperty("--height", `${n}px`)
                })), this.single = this.hasAttribute(ve), this.triggers = this.querySelectorAll(ce), this.resetHeightTimer = 0, this.isTransitioning = !1, this.transitionOverride = this.closest(de), this.collapsibleToggleEvent = t => window.theme.throttle(this.collapsibleToggle(t), 1250), this.onResizeEvent = () => this.onResize()
        }
    });
    const we = "[data-custom-scrollbar]",
        ye = "[data-custom-scrollbar-items]",
        fe = "[data-custom-scrollbar-thumb]",
        Ee = ".current";
    customElements.get("custom-scrollbar") || customElements.define("custom-scrollbar", class extends HTMLElement {
        connectedCallback() {
            this.scrollbar && this.scrollbarItems && (this.events(), this.calculateScrollbar(), this.scrollbarItems.children.length && this.calculateTrack(this.scrollbarItems.querySelector(Ee)))
        }
        calculateTrack(t) {
            if (!t) return this.scrollbar.style.setProperty("--thumb-scale", 0), void this.scrollbar.style.setProperty("--thumb-position", "0px");
            const e = t.clientWidth / this.scrollbarThumb.parentElement.clientWidth,
                i = t.offsetLeft / this.scrollbarThumb.parentElement.clientWidth;
            this.scrollbar.style.setProperty("--thumb-scale", e), this.scrollbar.style.setProperty("--thumb-position", this.trackWidth * i + "px")
        }
        calculateScrollbar() {
            if (this.scrollbarItems.children.length) {
                const t = [...this.scrollbarItems.children];
                this.trackWidth = 0, t.forEach((t => {
                    this.trackWidth += t.getBoundingClientRect().width + parseInt(window.getComputedStyle(t).marginRight)
                })), this.scrollbar.style.setProperty("--track-width", `${this.trackWidth}px`)
            }
        }
        onScrollbarChange(t) {
            var e;
            (null == t || null === (e = t.detail) || void 0 === e ? void 0 : e.element) && this.contains(t.detail.element) && this.calculateTrack(t.detail.element)
        }
        events() {
            document.addEventListener("theme:resize:width", this.calcScrollbarEvent), this.addEventListener("theme:custom-scrollbar:change", this.onScrollbarChangeEvent)
        }
        disconnectedCallback() {
            document.removeEventListener("theme:resize:width", this.calcScrollbarEvent), this.removeEventListener("theme:custom-scrollbar:change", this.onScrollbarChangeEvent)
        }
        constructor() {
            super(), this.scrollbarItems = this.querySelector(ye), this.scrollbar = this.querySelector(we), this.scrollbarThumb = this.querySelector(fe), this.trackWidth = 0, this.calcScrollbarEvent = () => this.calculateScrollbar(), this.onScrollbarChangeEvent = t => this.onScrollbarChange(t)
        }
    }), customElements.get("grid-slider") || customElements.define("grid-slider", class extends HTMLElement {
        get items() {
            return [...this.querySelectorAll("[data-slide]")]
        }
        connectedCallback() {
            this.listen(), this.handleLastSlideOverlayOnMobile(), this.listenForRecentlyViewedLoaded()
        }
        initSlider() {
            this.classList.remove("carousel--inactive"), this.flkty = new window.theme.Flickity.data(this), !this.flkty.isActive && this.items.length > 1 ? (this.flkty = new window.theme.Flickity(this, {
                pageDots: !1,
                cellSelector: "[data-slide]",
                cellAlign: "left",
                groupCells: !0,
                contain: !0,
                wrapAround: !1,
                adaptiveHeight: !1,
                on: {
                    ready: () => {
                        this.setSliderArrowsPosition(), setTimeout((() => {
                            this.changeTabIndex()
                        }), 0)
                    },
                    change: () => {
                        this.changeTabIndex()
                    }
                }
            }), this.handleLastSlideOverlayOnTablet()) : this.setSliderArrowsPosition()
        }
        destroySlider() {
            this.classList.contains("carousel") && this.classList.add("carousel--inactive"), null !== this.flkty && this.flkty.destroy()
        }
        resetSlider(t) {
            const e = t.target;
            null !== this.flkty ? this.flkty.select(0, !1, !0) : e.scrollTo({
                left: 0,
                behavior: "instant"
            })
        }
        resizeSlider() {
            null !== this.flkty && (this.flkty.resize(), requestAnimationFrame((() => this.setSliderArrowsPosition())))
        }
        checkSlidesSize() {
            const t = parseInt(this.dataset.columns),
                e = window.innerWidth >= theme.sizes.large,
                i = window.innerWidth >= theme.sizes.large && window.innerWidth < theme.sizes.widescreen,
                s = window.innerWidth >= theme.sizes.small && window.innerWidth < theme.sizes.large;
            let o = this.querySelectorAll("[data-slide]").length;
            const n = this.querySelectorAll("[data-promo]");
            n.length && e && n.forEach((e => {
                e.classList.contains("collection-promo--full") ? o += t - 1 : e.classList.contains("collection-promo--two-columns") && (o += 1)
            })), this.hasAttribute("data-slider-show-image") && (o += 1), e && o > t || i && o > 3 || s && o > 2 ? (this.initSlider(), this.getTallestProductGridItem(), requestAnimationFrame((() => {
                this.dispatchEvent(new CustomEvent("theme:slider:resize", {
                    bubbles: !0
                }))
            }))) : this.destroySlider()
        }
        changeTabIndex() {
            const t = this.flkty.selectedIndex;
            this.flkty.slides.forEach(((e, i) => {
                e.cells.forEach((e => {
                    e.element.querySelectorAll("a, button").forEach((e => {
                        e.setAttribute("tabindex", t === i ? "0" : "-1")
                    }))
                }))
            }))
        }
        setSliderArrowsPosition() {
            const t = this.querySelectorAll(".flickity-button"),
                e = this.querySelector("[data-product-media-container]");
            t.length && e && t.forEach((t => {
                t.style.top = e.offsetHeight / 2 + "px"
            }))
        }
        handleLastSlideOverlayOnTablet() {
            this.flkty.on("select", (() => {
                if (!(window.innerWidth >= theme.sizes.small && window.innerWidth < theme.sizes.large)) return;
                const t = this.flkty.selectedIndex,
                    e = this.flkty.slides.length - 1 === t;
                this.parentNode.classList.toggle("is-last-slide-visible", e)
            }))
        }
        getTallestProductGridItem() {
            if (this.querySelectorAll("[data-promo]").length) {
                const t = this.querySelectorAll("[data-product-block]"),
                    e = Math.max(...Array.from(t).map((t => t.offsetHeight)));
                this.style.setProperty("--carousel-promo-height", `${e}px`)
            }
        }
        handleLastSlideOverlayOnMobile() {
            this.addEventListener("scroll", (t => {
                if (!(window.innerWidth < theme.sizes.small)) return;
                const e = t.target.offsetWidth,
                    i = Array.from(this.children).pop().getBoundingClientRect().left + 80 < e;
                this.parentNode.classList.toggle("is-last-slide-visible", i)
            }))
        }
        listen() {
            this.checkSlidesSize(), document.addEventListener("theme:resize:width", this.checkSlidesSizeCallback), this.addEventListener("theme:tab:change", this.resetSliderEvent), this.addEventListener("theme:slider:resize", this.resizeSliderEvent)
        }
        listenForRecentlyViewedLoaded() {
            this.recentlyViewedParent = this.closest("recently-viewed"), this.recentlyViewedParent && this.recentlyViewedParent.addEventListener("theme:recently-viewed:loaded", this.checkSlidesSizeCallback)
        }
        disconnectedCallback() {
            this.destroySlider(), document.removeEventListener("theme:resize:width", this.checkSlidesSizeCallback), this.removeEventListener("theme:tab:change", this.resetSliderEvent), this.removeEventListener("theme:slider:resize", this.resizeSliderEvent), this.recentlyViewedParent && this.recentlyViewedParent.removeEventListener("theme:recently-viewed:loaded", this.checkSlidesSizeCallback)
        }
        constructor() {
            super(), this.flkty = null, this.recentlyViewedParent = null, this.checkSlidesSizeCallback = () => this.checkSlidesSize(), this.resetSliderEvent = t => this.resetSlider(t), this.resizeSliderEvent = () => this.resizeSlider()
        }
    });
    const Le = "is-visible",
        Se = document.querySelector("[data-scroll-top-button]");
    Se && (Se.addEventListener("click", (() => {
        window.scrollTo({
            top: 0,
            left: 0,
            behavior: "smooth"
        })
    })), document.addEventListener("scroll", window.theme.throttle((() => {
        Se.classList.toggle(Le, window.pageYOffset > window.innerHeight)
    }), 150)));
    const Ce = "details",
        ke = "[data-popdown-body]",
        Ae = "[data-popdown-close]",
        Te = "[data-popdown-toggle]",
        qe = "[data-search-form-inner]",
        He = "[data-popular-searches-link]",
        Ie = "[data-site-header]",
        Pe = "[data-nav]",
        De = "[data-nav-items-compress]",
        Me = "[data-nav-icons]",
        xe = "[data-mobile-menu]",
        Fe = "predictive-search",
        _e = "search-form",
        Oe = "data-popdown-in-header",
        Ve = "data-popdown-in-page",
        Be = "aria-activedescendant",
        $e = "aria-expanded",
        We = "open",
        Re = "role",
        ze = "search-opened",
        Ne = "site-header--menu-opened",
        Ue = "site-header--compress",
        je = "is-open";
    let Qe = class extends HTMLElement {
        connectedCallback() {
            var t;
            (this.isPopdownInHeader && (this.searchFormInner.addEventListener("transitionend", this.popdownTransitionCallbackEvent), this.details.addEventListener("keyup", (t => "ESCAPE" === t.code.toUpperCase() && this.close())), this.details.addEventListener("toggle", this.detailsToggleCallbackEvent), this.popdownClose.addEventListener("click", (t => this.close(t))), this.popdownToggle.addEventListener("click", (t => this.onPopdownToggleClick(t))), this.popdownToggle.setAttribute(Re, "button")), this.isPopdownInPage) && (this.popdownClose.addEventListener("click", (() => this.triggerPopdownClose())), this.searchFormWrapper.addEventListener("focusout", (() => this.onFocusOut())), null === (t = this.searchFormWrapper.input) || void 0 === t || t.addEventListener("click", (t => this.triggerPopdownOpen(t))));
            this.popularSearchesLink.forEach((t => {
                t.addEventListener("click", (t => {
                    t.preventDefault();
                    const e = t.target.textContent;
                    this.searchFormWrapper.input.value = e, this.searchFormWrapper.submit()
                }))
            }))
        }
        onPopdownToggleClick(t) {
            const e = navigator.userAgent.includes("Chrome"),
                i = /iPhone|iPad|iPod/i.test(navigator.userAgent);
            e && !i && t.target.closest(Ce).setAttribute(We, ""), t.target.closest(Ce).hasAttribute(We) && (t.preventDefault(), this.close())
        }
        detailsToggleCallback(t) {
            t.target.hasAttribute(We) && this.open()
        }
        popdownTransitionCallback(t) {
            t.target === this.searchFormInner && (this.details.classList.contains(je) ? "transform" === t.propertyName && this.a11y.trapFocus({
                container: this.searchFormInner
            }) : this.onClose())
        }
        onBodyClick(t) {
            var e;
            const i = this.contains(t.target);
            (null === (e = this.header) || void 0 === e ? void 0 : e.classList.contains(Ne)) || i || i || this.close()
        }
        onFocusOut() {
            this.predictiveSearch && requestAnimationFrame((() => {
                this.searchFormWrapper.contains(document.activeElement) || this.searchFormWrapper.close()
            }))
        }
        triggerPopdownOpen(t) {
            let e = matchMedia("(pointer:coarse)").matches;
            const i = window.innerWidth < theme.sizes.small,
                s = e || i;
            if (i && window.Shopify.designMode && (e = !0), this.nav && this.mobileMenu && s) {
                t.preventDefault();
                const i = this.header.classList.contains(Ue);
                let s = this.mobileMenu.querySelector(Te);
                e || (s = i ? this.nav.querySelector(`${De} ${Te}`) : this.nav.querySelector(`${Me} ${Te}`)), setTimeout((() => {
                    null == s || s.dispatchEvent(new Event("click", {
                        bubbles: !0
                    }))
                }), 300)
            }
        }
        open() {
            window.theme.closeAllTooltips(), this.onBodyClickEvent = t => this.onBodyClick(t), this.searchFormWrapper.input.setAttribute($e, !0), document.body.classList.add(ze), document.body.addEventListener("click", this.onBodyClickEvent), document.addEventListener("theme:resize", this.ensureClosingOnResizeEvent), document.dispatchEvent(new CustomEvent("theme:scroll:lock", {
                bubbles: !0
            })), requestAnimationFrame((() => {
                this.details.classList.add(je)
            }))
        }
        close(t) {
            const e = this.searchFormWrapper.input.getAttribute(Be);
            t && t.target === this.popdownClose && e && "" !== e || (this.a11y.removeTrapFocus(), this.details.classList.remove(je), this.predictiveSearch && this.searchFormWrapper.close(), this.searchFormWrapper.handleFocusableDescendants(!0))
        }
        triggerPopdownClose() {
            this.predictiveSearch && this.searchFormWrapper.close(), this.searchFormWrapper.popularSearches && requestAnimationFrame((() => document.activeElement.blur()))
        }
        onClose() {
            this.details.removeAttribute(We), document.dispatchEvent(new CustomEvent("theme:search:close", {
                bubbles: !0
            })), document.body.classList.remove(ze), document.body.removeEventListener("click", this.onBodyClickEvent), document.removeEventListener("theme:resize", this.ensureClosingOnResizeEvent), document.dispatchEvent(new CustomEvent("theme:scroll:unlock", {
                bubbles: !0
            }))
        }
        ensureClosingOnResize() {
            null === this.offsetParent && this.onClose()
        }
        constructor() {
            var t, e, i;
            super(), this.isPopdownInHeader = this.hasAttribute(Oe), this.isPopdownInPage = this.hasAttribute(Ve), this.popdownBody = this.querySelector(ke), this.popdownClose = this.querySelector(Ae), this.searchFormInner = this.querySelector(qe), this.popularSearchesLink = this.querySelectorAll(He), this.searchFormWrapper = this.querySelector(_e) ? this.querySelector(_e) : this.querySelector(Fe), this.predictiveSearch = this.searchFormWrapper.matches(Fe), this.header = document.querySelector(Ie), this.headerSection = null === (t = this.header) || void 0 === t ? void 0 : t.parentNode, this.nav = null === (e = this.header) || void 0 === e ? void 0 : e.querySelector(Pe), this.mobileMenu = null === (i = this.headerSection) || void 0 === i ? void 0 : i.querySelector(xe), this.a11y = window.theme.a11y, this.ensureClosingOnResizeEvent = () => this.ensureClosingOnResize(), this.popdownTransitionCallbackEvent = t => this.popdownTransitionCallback(t), this.detailsToggleCallbackEvent = t => this.detailsToggleCallback(t), this.isPopdownInHeader && (this.details = this.querySelector(Ce), this.popdownToggle = this.querySelector(Te))
        }
    };
    customElements.define("search-popdown", Qe), Shopify.Products = function() {
        const t = {
            howManyToShow: 4,
            howManyToStoreInMemory: 10,
            wrapperId: "recently-viewed-products",
            section: null,
            onComplete: null
        };
        let e = [],
            i = null,
            s = null;
        const o = new Date,
            n = new Date;
        n.setTime(o.getTime() + 7776e6);
        const a = {
                configuration: {
                    expires: n.toGMTString(),
                    path: "/",
                    domain: window.location.hostname,
                    sameSite: "none",
                    secure: !0
                },
                name: "shopify_recently_viewed",
                write: function(t) {
                    const e = encodeURIComponent(t.join(" "));
                    document.cookie = `${this.name}=${e}; expires=${this.configuration.expires}; path=${this.configuration.path}; domain=${this.configuration.domain}; sameSite=${this.configuration.sameSite}; secure=${this.configuration.secure}`
                },
                read: function() {
                    let t = [],
                        e = null;
                    return -1 !== document.cookie.indexOf("; ") && document.cookie.split("; ").find((t => t.startsWith(this.name))) && (e = document.cookie.split("; ").find((t => t.startsWith(this.name))).split("=")[1]), null !== e && (t = decodeURIComponent(e).split(" ")), t
                },
                destroy: function() {
                    document.cookie = `${this.name}=null; expires=${this.configuration.expires}; path=${this.configuration.path}; domain=${this.configuration.domain}`
                },
                remove: function(t) {
                    const e = this.read(),
                        i = e.indexOf(t); - 1 !== i && (e.splice(i, 1), this.write(e))
                }
            },
            r = (e, i, o, n) => {
                i.length && e < t.howManyToShow ? fetch(`${window.theme.routes.root}products/${i[0]}?section_id=api-product-grid-item`).then((t => t.text())).then((t => {
                    const s = 150 * e,
                        l = o.id ? `#${o.id}` : "",
                        c = document.createElement("div");
                    let d = t;
                    if (d.includes("data-unpublished")) return a.remove(i[0]), i.shift(), void r(e, i, o, n);
                    d = d.includes("||itemAosDelay||") ? d.replaceAll("||itemAosDelay||", s) : d, d = d.includes("||itemAosAnchor||") ? d.replaceAll("||itemAosAnchor||", l) : d, c.innerHTML = d;
                    const h = c.querySelector("[data-api-content]");
                    if (h)
                        for (; h.firstChild;) o.appendChild(h.firstChild);
                    i.shift(), e++, r(e, i, o, n)
                })).catch((() => {
                    a.remove(i[0]), i.shift(), r(e, i, o, n)
                })) : ((e, i) => {
                    e.classList.remove("hidden");
                    const o = a.read().length;
                    if (Shopify.recentlyViewed && s && o && o < s && e.children.length) {
                        let t = [],
                            i = [],
                            s = 0;
                        for (const e in Shopify.recentlyViewed) {
                            s += 1;
                            const o = Shopify.recentlyViewed[e].split(" "),
                                n = parseInt(e.split("_")[1]);
                            t = [...t, ...o], (a.read().length === n || s === Object.keys(Shopify.recentlyViewed).length && !i.length) && (i = [...i, ...o])
                        }
                        for (let s = 0; s < e.children.length; s++) {
                            const o = e.children[s];
                            t.length && o.classList.remove(...t), i.length && o.classList.add(...i)
                        }
                    }
                    if (t.onComplete) try {
                        t.onComplete(e, i)
                    } catch (t) {
                        console.log(t)
                    }
                })(o, n)
            };
        return {
            showRecentlyViewed: function(o) {
                const n = o || {};
                Object.assign(t, n), e = a.read(), -1 !== window.location.pathname.indexOf("/products/") && e.length > 0 && (e = e.slice(1)), i = document.getElementById(t.wrapperId), s = t.howManyToShow, t.howManyToShow = Math.min(e.length, t.howManyToShow), t.howManyToShow && i && r(0, e, i, t.section)
            },
            getConfig: function() {
                return t
            },
            clearList: function() {
                a.destroy()
            },
            recordRecentlyViewed: function(e) {
                const i = e || {};
                Object.assign(t, i);
                let s = a.read();
                if (-1 !== window.location.pathname.indexOf("/products/")) {
                    let e = decodeURIComponent(window.location.pathname).match(/\/products\/([a-z0-9\-]|[\u3000-\u303F]|[\u3040-\u309F]|[\u30A0-\u30FF]|[\uFF00-\uFFEF]|[\u4E00-\u9FAF]|[\u2605-\u2606]|[\u2190-\u2195]|[\u203B]|[\w\u0430-\u044f]|[\u0400-\u04FF]|[\u0900-\u097F]|[\u0590-\u05FF\u200f\u200e]|[\u0621-\u064A\u0660-\u0669 ])+/)[0].split("/products/")[1];
                    t.handle && (e = t.handle);
                    const i = s.indexOf(e); - 1 === i ? (s.unshift(e), s = s.splice(0, t.howManyToStoreInMemory)) : (s.splice(i, 1), s.unshift(e)), a.write(s)
                }
            },
            hasProducts: a.read().length > 0
        }
    }();
    const Ke = "[data-actions]",
        Ye = "[data-button]",
        Xe = "[data-content]",
        Ge = "[data-collapsible-container]",
        Je = "data-height",
        Ze = "aria-expanded",
        ti = "is-open",
        ei = "is-enabled";
    let ii = class extends HTMLElement {
        connectedCallback() {
            this.button.addEventListener("click", this.toggle), this.content.offsetHeight < this.initialHeight ? this.setHeight(this.content.offsetHeight) : this.setHeight(this.initialHeight), this.toggleActions(), document.addEventListener("theme:resize", this.toggleActionsEvent.bind(this))
        }
        toggle() {
            const t = !this.classList.contains(ti),
                e = this.content.offsetHeight + 2 * this.actions.offsetHeight;
            this.setHeight(t ? e : this.initialHeight), this.classList.toggle(ti, t), this.updateTabIndex(), this.dispatchEvent(new CustomEvent("theme:ellipsis:toggle", {
                bubbles: !0,
                detail: {
                    isExpanded: t,
                    dropdownHeight: e
                }
            }))
        }
        disconnectedCallback() {
            document.removeEventListener("theme:resize", this.toggleActions)
        }
        setHeight(t) {
            this.style.setProperty("--height", `${t}px`)
        }
        toggleActions() {
            this.classList.toggle(ei, this.content.offsetHeight + this.actions.offsetHeight > this.initialHeight), this.updateTabIndex()
        }
        toggleActionsEvent() {
            "true" === this.closest(Ge).getAttribute(Ze) && this.toggleActions()
        }
        updateTabIndex() {
            const t = this.content.querySelectorAll("a"),
                e = this.actions.offsetHeight;
            this.observer && this.observer.disconnect(), this.observer = new IntersectionObserver((t => {
                t.forEach((t => {
                    t.isIntersecting ? t.target.setAttribute("tabindex", "0") : t.target.setAttribute("tabindex", "-1")
                }))
            }), {
                root: this,
                threshold: 1,
                rootMargin: `0px 0px -${e}px 0px`
            }), t.forEach((t => {
                this.observer.observe(t)
            }))
        }
        constructor() {
            super(), this.initialHeight = this.getAttribute(Je), this.content = this.querySelector(Xe), this.actions = this.querySelector(Ke), this.button = this.querySelector(Ye), this.toggle = this.toggle.bind(this), this.toggleActions = this.toggleActions.bind(this)
        }
    };
    customElements.get("toggle-ellipsis") || customElements.define("toggle-ellipsis", ii);
    const si = {
            form: "form",
            selectorWrapper: "[data-selector-wrapper]",
            popoutList: "[data-popout-list]",
            popoutToggle: "[data-popout-toggle]",
            popoutInput: "[data-popout-input]",
            popoutOptions: "[data-popout-option]",
            popoutText: "[data-popout-text]",
            ariaCurrent: "[aria-current]",
            productGridImage: "[data-product-image]",
            productGrid: "[data-product-grid-item]",
            quickViewItem: "[data-quick-view-item]",
            quickViewFooter: "[data-quick-view-foot]",
            cartItem: "[data-cart-item]",
            popoutQuantity: "[data-quantity-field]",
            cartDrawer: "[data-cart-drawer]",
            cartDrawerMessage: "[data-cart-message]",
            cartDrawerErrors: "[data-cart-errors]",
            cartDrawerBody: "[data-cart-drawer-body]",
            cartDrawerItems: "[data-items-holder]"
        },
        oi = "selector-wrapper--open",
        ni = "select-popout__list--top",
        ai = "select-popout__list--visible",
        ri = "is-active",
        li = "--current",
        ci = "is-visible",
        di = "cart__item--open",
        hi = "aria-current",
        ui = "aria-expanded",
        pi = "data-value",
        mi = "data-popout-prevent",
        gi = "data-quantity-field",
        vi = "data-quick-view-inner",
        bi = "data-quick-view-focus",
        wi = "data-popout-initialized",
        yi = "data-quantity-holder";
    customElements.get("popout-select") || customElements.define("popout-select", class extends HTMLElement {
        connectedCallback() {
            this.popout = this, this.selectorWrapper = this.popout.closest(si.selectorWrapper), this.popoutList = this.popout.querySelector(si.popoutList), this.popoutToggle = this.popout.querySelector(si.popoutToggle), this.popoutText = this.querySelector(si.popoutToggleText), this.popoutText = this.popout.querySelector(si.popoutText), this.popoutInput = this.popout.querySelector(si.popoutInput), this.popoutOptions = this.popout.querySelectorAll(si.popoutOptions), this.popoutPrevent = "true" === this.popout.getAttribute(mi), this.cartItem = this.popoutList.closest(si.cartItem), this.popupToggleFocusoutEvent = t => this.popupToggleFocusout(t), this.popupListFocusoutEvent = t => this.popupListFocusout(t), this.popupToggleClickEvent = t => this.popupToggleClick(t), this.popoutKeyupEvent = t => this.popoutKeyup(t), this.popupOptionsClickEvent = t => this.popupOptionsClick(t), this._connectOptionsDispatchEvent = t => this._connectOptionsDispatch(t), this.bodyClick = this.bodyClick.bind(this), this.popoutTop = !1, this._connectOptions(), this._connectToggle(), this._onFocusOut(), this.popupListSetDimensions(), this.toggleListPosition()
        }
        popupToggleClick(t) {
            const e = "true" === t.currentTarget.getAttribute(ui);
            if (this.popoutList.closest(si.productGrid)) {
                const t = this.popoutList.closest(si.productGrid).querySelector(si.productGridImage);
                t && t.classList.toggle(ci, !e)
            }
            this.cartItem && this.cartItem.classList.toggle(di), t.currentTarget.setAttribute(ui, !e), this.popoutList.classList.toggle(ai), this.toggleListPosition(), this.popupListSetDimensions(), window.theme.closeAllTooltips()
        }
        popupToggleFocusout(t) {
            const e = "true" === this.popoutToggle.getAttribute(ui);
            if (!t.relatedTarget) return;
            const i = this.popout.contains(t.relatedTarget),
                s = t.relatedTarget.hasAttribute(vi) || t.relatedTarget.hasAttribute(bi);
            i || s || !e || this._hideList()
        }
        popupListFocusout(t) {
            const e = t.currentTarget.contains(t.relatedTarget);
            this.popoutList.classList.contains(ai) && !e && this._hideList()
        }
        calc(t = "shouldBeOnTop") {
            const {
                headerHeight: e,
                stickyHeaderHeight: i,
                announcementBarHeight: s
            } = window.theme.readHeights(), o = this.popout.closest(si.quickViewItem), n = this.popout.closest(si.cartDrawer);
            let a = Math.floor(this.popout.getBoundingClientRect().top),
                r = e || 0,
                l = 0;
            0 !== s && window.scrollY < s && (l = s), window.scrollY > l + e && (r = i);
            let c = window.innerHeight,
                d = r + l;
            if (o) {
                const t = o.querySelector(si.quickViewFooter),
                    e = (null == t ? void 0 : t.offsetHeight) || 0,
                    i = Math.floor(o.getBoundingClientRect().top);
                a -= i, c -= e, d = i, window.theme.isMobile() && (c = o.offsetHeight - e)
            }
            if (n) {
                const t = n.querySelector(si.cartDrawerMessage),
                    e = n.querySelector(si.cartDrawerErrors),
                    i = n.querySelector(si.cartDrawerBody),
                    s = n.querySelector(si.cartDrawerItems),
                    o = (null == t ? void 0 : t.offsetHeight) || 0,
                    r = (null == e ? void 0 : e.offsetHeight) || 0,
                    l = (null == i ? void 0 : i.scrollHeight) || 0;
                a -= Math.floor(null == s ? void 0 : s.getBoundingClientRect().top), c = l - o - r, d = 0
            }
            let h = c - d;
            if (o && window.theme.isMobile() && (h = c), "shouldBeOnTop" === t) return h / 2 < a;
            if ("availableHeightAbove" === t) {
                const t = Math.floor(this.popoutToggle.getBoundingClientRect().top - 1);
                return d += 10, `${parseInt(t-d)}px`
            }
            if ("availableHeightBelow" === t) {
                const t = Math.floor(this.popoutList.getBoundingClientRect().top - 1);
                return d = 10, `${parseInt(c-t-d)}px`
            }
        }
        toggleListPosition() {
            const t = "true" === this.popoutToggle.getAttribute(ui),
                e = this.calc("shouldBeOnTop");
            var i, s;
            t ? null === (i = this.selectorWrapper) || void 0 === i || i.classList.add(oi) : null === (s = this.selectorWrapper) || void 0 === s || s.classList.remove(oi);
            e ? (this.popoutList.classList.add(ni), this.popoutTop = !0) : (this.popoutList.classList.remove(ni), this.popoutTop = !1)
        }
        popupListSetDimensions() {
            this.popoutList.style.setProperty("--max-height", "100vh"), requestAnimationFrame((() => {
                this.popoutTop ? this.popoutList.style.setProperty("--max-height", this.calc("availableHeightAbove")) : this.popoutList.style.setProperty("--max-height", this.calc("availableHeightBelow"))
            }))
        }
        popupOptionsClick(t) {
            if ("#" === t.target.closest(si.popoutOptions).attributes.href.value) {
                t.preventDefault();
                const e = t.currentTarget.hasAttribute("data-value") ? t.currentTarget.getAttribute("data-value") : "";
                !this.popoutInput && this.popout.nextSibling.hasAttribute(yi) && (this.popoutInput = this.popout.nextSibling.querySelector(si.popoutQuantity)), this.popoutInput.value = e;
                const i = t.currentTarget.closest("li");
                if (i) {
                    const t = i.getAttribute("data-option-value-id"),
                        e = i.getAttribute("data-product-url");
                    t && this.popoutInput.setAttribute("data-option-value-id", t), e && this.popoutInput.setAttribute("data-product-url", e)
                }
                if (this.popoutInput.disabled && this.popoutInput.removeAttribute("disabled"), this.popoutPrevent) {
                    this.popoutInput.dispatchEvent(new Event("change", {
                        bubbles: !0
                    })), this.cartItem && this.popoutInput.dispatchEvent(new Event("input", {
                        bubbles: !0
                    })), this.switchQuantityInputBehavior(t.detail.preventTrigger);
                    const i = this.popoutList.querySelector(`[class*="${li}"]`);
                    let s = li;
                    if (i && i.classList.length)
                        for (const t of i.classList)
                            if (t.includes(li)) {
                                s = t;
                                break
                            }
                    const o = this.popoutList.querySelector(`.${s}`);
                    o && (o.classList.remove(`${s}`), t.currentTarget.parentElement.classList.add(`${s}`));
                    const n = this.popoutList.querySelector(si.ariaCurrent);
                    n && (n.removeAttribute(hi), t.currentTarget.setAttribute(hi, "true")), "" !== e && (this.popoutText.innerHTML = e, this.popoutText.hasAttribute("data-popout-text") && "" !== this.popoutText.getAttribute("data-popout-text") && this.popoutText.setAttribute("data-popout-text", e)), this.popupToggleFocusout(t), this.popupListFocusout(t)
                } else this._submitForm(e)
            }
        }
        switchQuantityInputBehavior(t = !0) {
            var e;
            if (t || !this.popoutInput.hasAttribute(gi)) return;
            const i = this.popoutList.querySelector(`[${pi}="${this.popoutInput.value}"]`);
            i && (i.parentElement.nextSibling || (this.popout.classList.add(ri), null === (e = this.selectorWrapper) || void 0 === e || e.classList.remove(oi)))
        }
        popoutKeyup(t) {
            t.code === theme.keyboardKeys.ESCAPE && (this._hideList(), this.popoutToggle.focus())
        }
        bodyClick(t) {
            const e = this.popout.contains(t.target);
            this.popoutList.classList.contains(ai) && !e && this._hideList()
        }
        _connectToggle() {
            this.popout.setAttribute(wi, ""), this.popoutToggle.addEventListener("click", this.popupToggleClickEvent)
        }
        _connectOptions() {
            this.popoutOptions.length && this.popoutOptions.forEach((t => {
                t.addEventListener("theme:popout:click", this.popupOptionsClickEvent), t.addEventListener("click", this._connectOptionsDispatchEvent)
            }))
        }
        _connectOptionsDispatch(t) {
            const e = new CustomEvent("theme:popout:click", {
                cancelable: !0,
                bubbles: !0,
                detail: {
                    preventTrigger: !1
                }
            });
            t.target.dispatchEvent(e) || t.preventDefault()
        }
        _onFocusOut() {
            this.popoutToggle.addEventListener("focusout", this.popupToggleFocusoutEvent), this.popoutList.addEventListener("focusout", this.popupListFocusoutEvent), this.popout.addEventListener("keyup", this.popoutKeyupEvent), document.body.addEventListener("click", this.bodyClick)
        }
        _submitForm() {
            const t = this.popout.closest(si.form);
            t && t.submit()
        }
        _hideList() {
            this.popoutList.classList.remove(ai), this.popoutToggle.setAttribute(ui, !1), this.toggleListPosition(), this.cartItem && this.cartItem.classList.remove(di)
        }
        disconnectedCallback() {
            this.popoutOptions.length && this.popoutOptions.forEach((t => {
                t.removeEventListener("theme:popout:click", this.popupOptionsClickEvent), t.removeEventListener("click", this._connectOptionsDispatchEvent)
            })), this.popoutToggle.removeEventListener("click", this.popupToggleClickEvent), this.popoutToggle.removeEventListener("focusout", this.popupToggleFocusoutEvent), this.popoutList.removeEventListener("focusout", this.popupListFocusoutEvent), this.popout.removeEventListener("keyup", this.popoutKeyupEvent), document.body.removeEventListener("click", this.bodyClick)
        }
        constructor() {
            super()
        }
    }), customElements.get("product-form") || customElements.define("product-form", class extends HTMLElement {
        connectedCallback() {
            this.form = this.querySelector("form"), this.variantIdInput.disabled = !1, this.form.addEventListener("submit", this.onSubmitHandler.bind(this)), this.cart = document.querySelector("cart-drawer"), this.submitButton = this.querySelector('[type="submit"]'), this.submitButtonText = this.submitButton.querySelector("[data-add-to-cart-text]"), this.buyItNow = this.querySelector("[data-buy-it-now]"), this.hideErrors = "true" === this.dataset.hideErrors, this.hasPaymentButton = null !== this.buyItNow, this.hasPaymentButton && (this.mutationObserver = null, this.observeContainer())
        }
        onSubmitHandler(t) {
            t.preventDefault(), document.dispatchEvent(new CustomEvent("theme:cart:add", {
                detail: {
                    button: this.submitButton
                },
                bubbles: !1
            }))
        }
        toggleSubmitButton(t = !0, e) {
            let i = this;
            var s, o;
            (this.hasAttribute("data-form-wrapper") || (i = this.querySelector("[data-form-wrapper]")), t) ? (this.submitButton.setAttribute("disabled", "disabled"), e && (this.submitButtonText.textContent = e), null === (s = this.buyItNow) || void 0 === s || s.classList.add("hidden"), i.classList.add("variant--unavailable"), i.classList.remove("variant--soldout")) : (this.submitButton.removeAttribute("disabled"), this.submitButtonText.textContent = window.variantStrings.addToCart, null === (o = this.buyItNow) || void 0 === o || o.classList.remove("hidden"), i.classList.remove("variant--unavailable"))
        }
        get variantIdInput() {
            var t;
            return null === (t = this.form) || void 0 === t ? void 0 : t.querySelector("[name=id]")
        }
        observeContainer() {
            let t = this.buyItNow.querySelector(".shopify-payment-button__button--unbranded");
            if (t) return t.classList.add(window.theme.settings.buynowButtonColor), t.classList.add(window.theme.settings.buynowButtonStyle), t.classList.add(window.theme.settings.buynowButtonSize), void this.insertHoverElement(t);
            this.mutationObserver = new MutationObserver((t => {
                for (const i of t)
                    if ("childList" === i.type) {
                        const t = i.target.querySelector(".shopify-payment-button__button--unbranded");
                        var e;
                        if (t) this.insertHoverElement(t), null === (e = this.mutationObserver) || void 0 === e || e.disconnect(), this.mutationObserver = null
                    }
            })), this.mutationObserver.observe(this.buyItNow, {
                childList: !0,
                subtree: !0
            })
        }
        insertHoverElement(t) {
            const e = t.innerHTML;
            t.innerHTML = `<hover-button>${e}</hover-button>`
        }
        saveSwatchesState(t) {
            var e, i;
            if (!t.selectorWrapper) return;
            const s = `${t.selectorWrapper.getAttribute("data-option-position")}-${null===(e=t.selectorWrapper.querySelector("[data-swatches-label]"))||void 0===e||null===(i=e.textContent)||void 0===i?void 0:i.trim()}`,
                o = {
                    isLarge: t.selectorWrapper.classList.contains("selector-wrapper--large"),
                    isVisible: t.selectorWrapper.classList.contains("selector-wrapper--visible"),
                    maxHeight: t.style.getPropertyValue("--swatches-max-height")
                };
            this.swatchesStates.set(s, o)
        }
        getSwatchesState(t) {
            var e, i;
            if (!t.selectorWrapper) return null;
            const s = `${t.selectorWrapper.getAttribute("data-option-position")}-${null===(e=t.selectorWrapper.querySelector("[data-swatches-label]"))||void 0===e||null===(i=e.textContent)||void 0===i?void 0:i.trim()}`;
            return this.swatchesStates.get(s)
        }
        disconnectedCallback() {
            this.mutationObserver && (this.mutationObserver.disconnect(), this.mutationObserver = null)
        }
        constructor() {
            super(), this.swatchesStates = new Map
        }
    });
    const fi = "[data-quantity-field]",
        Ei = "[data-quantity-button]",
        Li = "[data-quantity-minus]",
        Si = "[data-quantity-plus]",
        Ci = "[data-cart-item]",
        ki = "read-only",
        Ai = "is-disabled";
    customElements.get("quantity-counter") || customElements.define("quantity-counter", class extends HTMLElement {
        connectedCallback() {
            this.quantity = this, this.cartItem = this.quantity.closest(Ci), this.quantity && (this.field = this.quantity.querySelector(fi), this.buttons = this.quantity.querySelectorAll(Ei), this.increaseButton = this.quantity.querySelector(Si), this.quantityValue = Number(this.field.value || 0), this.cartItemID = this.field.getAttribute("data-id"), this.maxValue = Number(this.field.getAttribute("max")) > 0 ? Number(this.field.getAttribute("max")) : null, this.minValue = Number(this.field.getAttribute("min")) > 0 ? Number(this.field.getAttribute("min")) : 0, this.disableIncrease = this.disableIncrease.bind(this), this.emptyField = !1, this.updateQuantity = this.updateQuantity.bind(this), this.decrease = this.decrease.bind(this), this.increase = this.increase.bind(this), this.disableIncrease(), this.quantity.classList.contains(ki) || (this.changeValueOnClick(), this.changeValueOnInput()))
        }
        changeValueOnClick() {
            this.buttons.forEach((t => {
                t.addEventListener("click", (t => {
                    t.preventDefault(), this.quantityValue = Number(this.field.value || 0);
                    const e = t.target,
                        i = e.matches(Li) || e.closest(Li),
                        s = e.matches(Si) || e.closest(Si);
                    i && this.decrease(), s && this.increase(), this.updateQuantity()
                }))
            }))
        }
        changeValueOnInput() {
            this.field.addEventListener("input", (() => {
                this.quantityValue = this.field.value, this.updateQuantity()
            }))
        }
        updateQuantity() {
            this.maxValue < this.quantityValue && null !== this.maxValue && (this.quantityValue = this.maxValue), this.minValue > this.quantityValue && (this.quantityValue = this.minValue), this.field.value = this.quantityValue, this.disableIncrease(), this.cartItem ? (document.dispatchEvent(new CustomEvent("theme:cart:update")), this.updateCart()) : this.triggerInputChange()
        }
        decrease() {
            this.quantityValue > this.minValue ? this.quantityValue-- : this.quantityValue = 0
        }
        increase() {
            this.quantityValue++
        }
        disableIncrease() {
            this.increaseButton.classList.toggle(Ai, this.quantityValue >= this.maxValue && null !== this.maxValue)
        }
        updateCart() {
            if ("" === this.quantityValue) return;
            const t = new CustomEvent("theme:cart:update", {
                bubbles: !0,
                detail: {
                    id: this.cartItemID,
                    quantity: this.quantityValue
                }
            });
            this.cartItem && this.cartItem.dispatchEvent(t)
        }
        triggerInputChange() {
            this.field.dispatchEvent(new Event("change"))
        }
        constructor() {
            super()
        }
    }), window.theme.flickitySmoothScrolling = function(t) {
        const e = window.theme.Flickity.data(t);
        e && (e.on("dragStart", ((t, e) => {
            document.ontouchmove = function(t) {
                t.preventDefault()
            }
        })), e.on("dragEnd", ((t, e) => {
            document.ontouchmove = function(t) {
                return !0
            }
        })))
    }, customElements.get("tabs-component") || customElements.define("tabs-component", class extends HTMLElement {
        connectedCallback() {
            this.tabRef = this.querySelectorAll("[data-tab-ref]"), this.tabsLink = this.querySelectorAll("[data-tabs-link]"), this.tab = this.querySelectorAll("[data-tab]"), this.assignSearchPageArguments(), this.init(), this.inactiveTabsAnimationsCallback = window.theme.debounce((() => this.handleInactiveTabsAnimations()), 200), document.addEventListener("theme:scroll", this.inactiveTabsAnimationsCallback), this.addEventListener("mouseenter", (() => {
                this.handleInactiveTabsAnimations()
            }))
        }
        assignSearchPageArguments() {
            if (!this.isSearchPage) return;
            const t = this.closest("section");
            this.searchForm = t.querySelector("[data-search-form]"), this.searchFormData = new FormData(this.searchForm), this.searchTerm = encodeURIComponent(this.searchFormData.get("q")), this.currentType = t.getAttribute("data-current-type"), this.sectionId = t.dataset.sectionId, this.searchForAllTypes = "true" === t.getAttribute("data-all-types"), this.fetchURL = "", this.searchParams = "", this.cachedResults = {}, this.handleTabsHistory()
        }
        init() {
            this.querySelectorAll("[data-tabs-link]").forEach((t => {
                this.handleTabsNavListeners(t)
            }))
        }
        handleTabsHistory() {
            window.addEventListener("popstate", this.onHistoryChange.bind(this)), this.openTabFromHistoryEvent = t => this.openTabFromHistory(t), this.tabsLink.forEach((t => {
                t.addEventListener("theme:tab:open-from-history", this.openTabFromHistoryEvent)
            }))
        }
        handleTabsNavListeners(t) {
            const e = t.getAttribute("data-tabs-link"),
                i = this.querySelector(`[data-tab="${e}"]`);
            i && (t.addEventListener("click", (e => {
                this.isSearchPage && this.handleURLSearchParams(e, !0), this.tabChange(t, i)
            })), t.addEventListener("keyup", (e => {
                e.code !== theme.keyboardKeys.SPACE && e.code !== theme.keyboardKeys.ENTER && e.code !== theme.keyboardKeys.NUMPADENTER || (this.isSearchPage && this.handleURLSearchParams(e, !0), this.tabChange(t, i))
            })))
        }
        openTabFromHistory(t) {
            const e = t.target,
                i = this.querySelector(t.detail.element).getAttribute("data-tabs-link"),
                s = this.querySelector(`[data-tab="${i}"]`);
            s && (this.handleURLSearchParams(t, !1), this.tabChange(e, s))
        }
        handleURLSearchParams(t, e = !0) {
            const i = t.target.matches("[data-tabs-link]") ? t.target : t.target.closest("[data-tabs-link]"),
                s = i.getAttribute("data-type"),
                o = i.getAttribute("data-tabs-link"),
                n = this.querySelector(`[data-tab="${o}"]`).querySelector("[data-current-page]"),
                a = document.querySelector("[data-collection-filters-form]");
            let r = n ? `&page=${n.getAttribute("data-current-page")}` : "";
            if (this.searchParams = function(t, e, i = [], s = !1) {
                    const o = new FormData(t),
                        n = new URLSearchParams(o);
                    if (!e) return n.toString();
                    const a = new FormData(e),
                        r = new URLSearchParams(a),
                        l = [];
                    for (const t of o.entries()) "" === t[1] && l.push(t[0]);
                    for (const t of a.entries()) "" === t[1] && l.push(t[0]);
                    for (let t = 0; t < l.length; t++) {
                        const e = l[t];
                        n.has(e) && n.delete(e), r.has(e) && r.delete(e)
                    }
                    for (const t of n.keys()) r.has(t) && r.delete(t);
                    if (i.length > 0)
                        for (let t = 0; t < i.length; t++) {
                            const e = i[t];
                            n.has(e) && n.delete(e), r.has(e) && r.delete(e)
                        }
                    return s && (r.has("type") && r.delete("type"), n.set("type", s)), `${n.toString()}&${r.toString()}`
                }(this.searchForm, a, [], s), "product" === s) {
                const t = this.searchParams.replace("&type=product", "");
                this.searchParams = `${t}&type=product`
            } else this.searchParams = `q=${this.searchTerm}&type=${s}`;
            theme.settings.enableInfinityScroll || "" === r || (this.searchParams += r), this.fetchURL = `${theme.routes.searchUrl}?${this.searchParams}&section_id=${this.sectionId}`, e && history.pushState({
                searchParams: this.searchParams
            }, "", `${window.location.pathname}${this.searchParams&&"?".concat(this.searchParams)}`)
        }
        tabChangeFetchContent(t, e) {
            const i = t.getAttribute("data-type"),
                s = t.getAttribute("data-tabs-link"),
                o = this.querySelector(`[data-tab="${s}"]`),
                n = this.currentType === i,
                a = this.querySelector(".current[data-tab]"),
                r = null == a ? void 0 : a.querySelector("ajaxinate-items"),
                l = document.querySelector("[data-tooltip-container]");
            if (null == l || l.style.setProperty("--tooltip-top", "0px"), "function" == typeof(null == r ? void 0 : r.unload) && r.unload(), this.cachedResults[s] || n) {
                const i = e.querySelector("ajaxinate-items");
                return "function" == typeof(null == i ? void 0 : i.init) && i.init(), void requestAnimationFrame((() => {
                    this.handleActiveTabClasses(t, e), this.scrollToCurrentTabLink(t), this.triggerTabAnimations(e)
                }))
            }
            fetch(this.fetchURL).then((t => {
                if (!t.ok) {
                    throw new Error(t.status)
                }
                return t.text()
            })).then((i => {
                const n = (new DOMParser).parseFromString(i, "text/html").querySelector(`[data-tab="${s}"]`).innerHTML;
                var a;
                this.searchForAllTypes && (null === (a = this.querySelector("[data-all-types-container]")) || void 0 === a || a.remove());
                this.cachedResults[s] = n, o.innerHTML = n, requestAnimationFrame((() => {
                    this.handleActiveTabClasses(t, e), this.scrollToCurrentTabLink(t), this.triggerTabAnimations(e)
                }))
            })).catch((t => {
                throw t
            }))
        }
        onHistoryChange(t) {
            var e;
            const i = (null === (e = t.state) || void 0 === e ? void 0 : e.searchParams) || window.location.search,
                s = i.indexOf("type=product") > -1,
                o = i.indexOf("type=article") > -1,
                n = i.indexOf("type=page") > -1,
                a = Boolean(this.querySelector(".current[data-tabs-link]")),
                r = s || o || n,
                l = this.querySelector('[data-tabs-link][data-type="product"]'),
                c = this.querySelector('[data-tabs-link][data-type="article"]'),
                d = this.querySelector('[data-tabs-link][data-type="page"]');
            r ? a && (s && (null == l || l.dispatchEvent(new CustomEvent("theme:tab:open-from-history", {
                bubbles: !0,
                detail: {
                    element: '[data-type="product"]'
                }
            }))), o && (null == c || c.dispatchEvent(new CustomEvent("theme:tab:open-from-history", {
                bubbles: !0,
                detail: {
                    element: '[data-type="article"]'
                }
            }))), n && (null == d || d.dispatchEvent(new CustomEvent("theme:tab:open-from-history", {
                bubbles: !0,
                detail: {
                    element: '[data-type="page"]'
                }
            })))) : window.location = i
        }
        tabChange(t, e) {
            t.classList.contains("current") || (this.isSearchPage ? this.tabChangeFetchContent(t, e) : (this.handleActiveTabClasses(t, e), this.scrollToCurrentTabLink(t), this.triggerTabAnimations(e), this.handleTabSliders(e)))
        }
        handleActiveTabClasses(t, e) {
            var i;
            const s = this.querySelector(".current[data-tab]"),
                o = this.querySelector(".current[data-tabs-link]");
            null == s || s.classList.remove("current"), null == o || o.classList.remove("current"), t.classList.add("current"), e.classList.add("current"), t.classList.contains("hide") && e.classList.add("hide"), null === (i = this.tabRef) || void 0 === i || i.forEach((t => {
                const i = t.classList.contains("current"),
                    s = t.getAttribute("data-tab-ref") === e.getAttribute("data-tab");
                t.classList.toggle("current", !i && s)
            }))
        }
        scrollToCurrentTabLink(t) {
            const e = t.closest("[data-custom-scrollbar-holder]") ? t.closest("[data-custom-scrollbar-holder]") : t.parentElement,
                i = parseInt(window.getComputedStyle(e).getPropertyValue("padding-left"));
            e.scrollTo({
                top: 0,
                left: t.offsetLeft - e.offsetWidth / 2 + t.offsetWidth / 2 + i,
                behavior: "smooth"
            }), t.dispatchEvent(new CustomEvent("theme:custom-scrollbar:change", {
                bubbles: !0,
                detail: {
                    element: t
                }
            }))
        }
        triggerTabAnimations(t) {
            if ("false" == theme.settings.animationsEnabled) return;
            document.dispatchEvent(new CustomEvent("theme:scroll"));
            const e = this.tabsContents.querySelector('[data-tab="resultsProducts"]');
            if (e && e.classList.contains("current")) {
                Lt(this.tabsContents.querySelectorAll("[data-aos-anchor]"))
            } else this.tabsContents.querySelectorAll("[data-aos]").forEach((t => {
                t.classList.remove("aos-animate")
            })), this.animateElementsTimer && clearTimeout(this.animateElementsTimer), this.animateElementsTimer = setTimeout((() => {
                t.querySelectorAll("[data-aos]").forEach((t => {
                    t.classList.add("aos-animate")
                }))
            }), 150)
        }
        handleInactiveTabsAnimations() {
            this.tab.forEach((t => {
                t.classList.contains("current") || t.querySelectorAll("[data-aos]").forEach((t => {
                    requestAnimationFrame((() => t.classList.remove("aos-animate")))
                }))
            }))
        }
        handleTabSliders(t) {
            const e = t.querySelector("grid-slider");
            e && e.dispatchEvent(new CustomEvent("theme:tab:change", {
                bubbles: !1
            }))
        }
        disconnectedCallback() {
            document.removeEventListener("theme:scroll", this.inactiveTabsAnimationsCallback), this.openTabFromHistoryEvent && this.tabsLink.forEach((t => {
                t.removeEventListener("theme:tab:open-from-history", this.openTabFromHistoryEvent)
            })), window.removeEventListener("popstate", this.onHistoryChange.bind(this))
        }
        constructor() {
            super(), this.tabsContents = this.querySelector("[data-tabs-contents]"), this.animateElementsTimer = null, this.isSearchPage = null != this.closest('[data-search-performed="true"]')
        }
    });
    const Ti = "[data-aos]",
        qi = "[data-has-highlight]",
        Hi = "[data-highlight-holder]",
        Ii = "path",
        Pi = "sup",
        Di = ".flickity-enabled",
        Mi = "[data-slide].is-selected",
        xi = "[data-sticky-text]",
        Fi = "text-count-up",
        _i = ".text-reveal__cropper",
        Oi = "data-highlight-type",
        Vi = "data-is-active",
        Bi = "is-active",
        $i = "overflow-hidden",
        Wi = {
            "circle-hand-drawn": {
                keyframes: [{
                    strokeDashoffset: "1",
                    opacity: "0"
                }, {
                    opacity: "1",
                    offset: .01
                }, {
                    strokeDashoffset: "0",
                    opacity: "1"
                }],
                timing: {
                    duration: 1e3,
                    delay: 0,
                    iterations: 1,
                    fill: "forwards",
                    easing: "cubic-bezier(0.7, 0, 0.3, 1)"
                }
            },
            circle: {
                keyframes: [{
                    strokeDashoffset: "506",
                    opacity: "0"
                }, {
                    opacity: "1",
                    offset: .01
                }, {
                    strokeDashoffset: "0",
                    opacity: "1"
                }],
                timing: {
                    duration: 800,
                    delay: 0,
                    iterations: 1,
                    fill: "forwards",
                    easing: "cubic-bezier(0.6, 0, 0.4, 1)"
                }
            },
            highlight: {
                keyframes: [{
                    transform: "scaleX(0)"
                }, {
                    transform: "scaleX(1)"
                }],
                timing: {
                    duration: 600,
                    delay: 200,
                    iterations: 1,
                    fill: "forwards",
                    easing: "ease",
                    pseudoElement: "::before"
                },
                keyframesHover: [{
                    transform: "scaleY(0.1)"
                }, {
                    transform: "scaleY(1)"
                }]
            },
            "highlight-color": {
                keyframes: [{
                    backgroundSize: "200% 100%",
                    backgroundPosition: "100% 0"
                }, {
                    backgroundSize: "200% 100%",
                    backgroundPosition: "0 0",
                    offset: .2
                }, {
                    backgroundSize: "1100% 100%",
                    backgroundPosition: "0 0"
                }],
                timing: {
                    duration: 2e3,
                    delay: 200,
                    iterations: 1,
                    fill: "forwards",
                    easing: "cubic-bezier(0, 0, 0.9, 0.4)"
                }
            },
            "alternate-font": {
                keyframes: [{
                    opacity: "0"
                }, {
                    opacity: "1"
                }],
                timing: {
                    duration: 400,
                    delay: 0,
                    iterations: 1,
                    fill: "forwards",
                    easing: "ease-out"
                },
                keyframesHover: [{
                    opacity: "1"
                }, {
                    opacity: "0.7"
                }]
            },
            squiggle: {
                keyframes: [{
                    maskPosition: "100% 0"
                }, {
                    maskPosition: "0 0"
                }],
                timing: {
                    duration: 1200,
                    delay: 200,
                    iterations: 1,
                    fill: "forwards",
                    easing: "cubic-bezier(0.6, 0, 0.4, 1)"
                }
            },
            stroke: {
                keyframes: [{
                    backgroundPosition: "100% 0"
                }, {
                    backgroundPosition: "0 0"
                }],
                timing: {
                    duration: 1200,
                    delay: 0,
                    iterations: 1,
                    fill: "forwards",
                    easing: "cubic-bezier(0.25, 0.1, 0.9, 0.3)"
                }
            },
            underline: {
                keyframes: [{
                    transform: "scaleX(0)"
                }, {
                    transform: "scaleX(1)"
                }],
                timing: {
                    duration: 900,
                    delay: 200,
                    iterations: 1,
                    fill: "forwards",
                    easing: "ease",
                    pseudoElement: "::before"
                }
            },
            "underline-hand-drawn": {
                keyframes: [{
                    strokeDashoffset: "1",
                    opacity: "0"
                }, {
                    opacity: "1",
                    offset: .01
                }, {
                    strokeDashoffset: "0",
                    opacity: "1"
                }],
                timing: {
                    duration: 1e3,
                    delay: 0,
                    iterations: 1,
                    fill: "forwards",
                    easing: "cubic-bezier(0.7, 0, 0.3, 1)"
                }
            }
        };
    var Ri;
    customElements.get("text-highlight") || customElements.define("text-highlight", (function(t, e, i) {
        e in t ? Object.defineProperty(t, e, {
            value: i,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = i
    }(Ri = class extends HTMLElement {
        connectedCallback() {
            this.timeout = null, this.controller = new AbortController, this.type && this.target && (this.animation = this.target.animate(Wi[this.type].keyframes, Wi[this.type].timing), this.animation.pause(), this.bindAnimation("init"), this.bindAnimation("pause"), this.modifyDefaults("slider"), this.animation && (this.link && this.listen(), theme.settings.animationsEnabled || (this.animation.play(), this.bindAnimation("play"))))
        }
        disconnectedCallback() {
            this.controller.abort()
        }
        attributeChangedCallback(t, e, i) {
            const s = t === Vi,
                o = null === e && s,
                n = "true" === i;
            s && n && !("true" === e && "true" === i) && this.triggerAnimation(), o || n || this.reset()
        }
        triggerAnimation() {
            const t = this.closest(Ti);
            var e;
            t ? (null === (e = this.textRevealCropper) || void 0 === e || e.classList.add($i), this.textCountUp ? (clearTimeout(this.timeout), this.timeout = setTimeout((() => {
                var t;
                null === (t = this.textRevealCropper) || void 0 === t || t.classList.remove($i), this.setAnimationDelay(0), this.animate()
            }), 100)) : window.theme.waitForAnimationEnd(t).then((() => {
                var e;
                const i = 1e3 * (window.getComputedStyle(t).getPropertyValue("animation-delay") || 0).replace("s", ""),
                    s = Math.max(i - 250, 0);
                null === (e = this.textRevealCropper) || void 0 === e || e.classList.remove($i), this.setAnimationDelay(s), this.animate()
            }))) : this.animate()
        }
        listen() {
            this.link.addEventListener("mouseenter", (t => this.onMouseenter(t)), {
                signal: this.controller.signal
            }), this.link.addEventListener("mouseleave", (t => this.onMouseleave(t)), {
                signal: this.controller.signal
            })
        }
        animate() {
            this.animation && (this.animation.play(), this.bindAnimation("play"), this.animation.onfinish = () => this.onFinish())
        }
        shouldAnimate() {
            requestAnimationFrame((() => {
                let t = !0;
                Boolean(this.closest(Di)) && (t = Boolean(this.closest(Mi)));
                const e = this.closest(xi);
                e && (t = Boolean(e.classList.contains(Bi))), this.setTriggerAttribute(t)
            }))
        }
        setTriggerAttribute(t = !0) {
            this.setAttribute(Vi, t)
        }
        reset() {
            this.animation && (this.animation.cancel(), this.bindAnimation("cancel"), this.setAnimationDelay(Wi[this.type].timing.delay))
        }
        onMouseenter(t) {
            t.stopImmediatePropagation(), this.setAnimationDelay(0), this.modifyDefaults("mouseenter"), "alternate-font" !== this.type && this.animation.reverse(), this.bindAnimation("mouseenter")
        }
        onMouseleave(t) {
            t.stopImmediatePropagation(), this.modifyDefaults("mouseleave"), "alternate-font" !== this.type && this.animation.reverse(), this.bindAnimation("mouseleave")
        }
        onFinish() {
            if (this.hasAttribute(Vi)) {
                const t = "true" === this.getAttribute(Vi) ? 0 : Wi[this.type].timing.delay;
                this.setAnimationDelay(t)
            } else this.setAnimationDelay(0)
        }
        setAnimationDelay(t = 0) {
            this.animation.effect.getTiming().delay !== t && (this.animation.effect.updateTiming({
                delay: t
            }), this.bindAnimation("delay"))
        }
        modifyDefaults(t = "mouseenter", e) {
            if (e || (e = this.animation), "mouseenter" === t) return Wi[this.type].keyframesHover && e.effect.setKeyframes(Wi[this.type].keyframesHover), "highlight" === this.type && e.effect.updateTiming({
                duration: 350,
                fill: "both"
            }), "highlight-color" === this.type && e.effect.updateTiming({
                duration: 800
            }), void("underline" === this.type && e.effect.updateTiming({
                duration: 400
            }));
            if ("mouseleave" === t) return Wi[this.type].keyframesHover && e.effect.setKeyframes(Wi[this.type].keyframes), void("highlight" !== this.type && "highlight-color" !== this.type && "underline" !== this.type || e.effect.updateTiming({
                duration: Wi[this.type].timing.duration
            }));
            if ("slider" === t && (theme.settings.animationsEnabled || (Wi[this.type].timing.delay = 300, e.effect.updateTiming({
                    delay: Wi[this.type].timing.delay
                })), this.closest(Di))) {
                const t = Wi[this.type].timing.delay + 200;
                "highlight" === this.type && e.effect.updateTiming({
                    delay: t
                })
            }
        }
        bindAnimation(t = !1) {
            if (this.bind && t && ("init" === t && (this.boundAnimation = this.bind.animate(Wi[this.type].keyframes, Wi[this.type].timing)), "pause" === t && this.boundAnimation.pause(), "play" === t && this.boundAnimation.play(), "cancel" === t && this.boundAnimation.cancel(), "mouseenter" === t && (this.modifyDefaults("mouseenter", this.boundAnimation), this.boundAnimation.reverse()), "mouseleave" === t && (this.modifyDefaults("mouseleave", this.boundAnimation), this.boundAnimation.reverse()), "delay" === t)) {
                const t = this.animation.effect.getTiming().delay;
                this.boundAnimation.effect.getTiming().delay !== t && this.boundAnimation.effect.updateTiming({
                    delay: t
                })
            }
        }
        constructor() {
            super(), this.animation = null, this.bind = null, this.boundAnimation = null, this.link = this.closest(qi), this.type = this.getAttribute(Oi), this.highlightHolder = this.querySelector(Hi), this.textCountUp = this.closest(Fi), this.sup = this.querySelector(Pi), this.textRevealCropper = this.closest(_i), this.target = this.highlightHolder, "circle-hand-drawn" !== this.type && "circle" !== this.type && "underline-hand-drawn" !== this.type || (this.target = this.querySelector(Ii)), "highlight-color" !== this.type && "stroke" !== this.type && "alternate-font" !== this.type || this.sup && (this.bind = this.sup)
        }
    }, "observedAttributes", [Vi]), Ri));
    let zi = null;
    window.theme = window.theme || {}, window.theme.closeAllTooltips = function(t = !1) {
        const e = document.querySelector("[data-tooltip-container]");
        e && e.classList.contains("is-visible") && (t ? (e.classList.remove("is-visible"), e.classList.remove("is-hiding"), e.hideTransitionTimeout && clearTimeout(e.hideTransitionTimeout)) : (e.classList.add("is-hiding"), e.classList.remove("is-visible"), e.hideTransitionTimeout && clearTimeout(e.hideTransitionTimeout), e.hideTransitionTimeout = setTimeout((() => {
            e.classList.remove("is-hiding")
        }), 200)))
    }, window.theme.handleTooltipScroll = function() {
        zi || (zi = t => {
            const e = document.querySelector("[data-tooltip-container]");
            if (e && e.classList.contains("is-visible"))
                if ("scroll" === t.type) {
                    t.target.closest("[data-scroll-lock-scrollable]") && window.theme.closeAllTooltips()
                } else "theme:scroll" === t.type && window.theme.closeAllTooltips()
        }, document.addEventListener("scroll", zi, {
            passive: !0,
            capture: !0
        }), document.addEventListener("theme:scroll", zi, {
            passive: !0
        }))
    }, customElements.get("tooltip-component") || customElements.define("tooltip-component", class extends HTMLElement {
        connectedCallback() {
            if (!document.querySelector("[data-tooltip-container]")) {
                const t = `<div class="${this.rootClass}__arrow"></div><div class="${this.rootClass}__inner"><div class="${this.rootClass}__text label-typography"></div></div>`,
                    e = document.createElement("div");
                e.className = `${this.rootClass} ${this.isAnimatingClass}`, e.setAttribute("data-tooltip-container", ""), e.innerHTML = t, document.body.appendChild(e)
            }
            this.tooltip.addEventListener("mouseenter", this.addPinMouseEvent), this.tooltip.addEventListener("mouseleave", this.removePinMouseEvent), this.tooltip.addEventListener("theme:tooltip:init", this.addPinEvent);
            const t = document.querySelector("[data-tooltip-container]");
            theme.settings.animationsEnabled && this.animatedContainer && (this.handleAnimationEnd = () => {
                t.classList.remove("is-animating")
            }, this.handleTransitionEnd = e => {
                "transform" === e.propertyName && t.classList.remove("is-animating")
            }, "hero" === this.animatedContainer.getAttribute("data-aos") ? this.animatedContainer.addEventListener("animationend", this.handleAnimationEnd) : this.animatedContainer.addEventListener("transitionend", this.handleTransitionEnd))
        }
        addPin(t = !1) {
            const e = document.querySelector("[data-tooltip-container]");
            if (e && (t && !this.tooltip.hasAttribute("data-tooltip-stop-mouseenter") || !t)) {
                const t = e.querySelector(`.${this.rootClass}__arrow`),
                    i = e.querySelector(`.${this.rootClass}__inner`),
                    s = e.querySelector(`.${this.rootClass}__text`);
                this.label.includes("ß") && (this.label = this.label.replace(/ß/g, '<span style="text-transform: lowercase;">ß</span>')), s.innerHTML = this.label;
                const o = i.offsetWidth,
                    n = this.tooltip.getBoundingClientRect(),
                    a = n.top,
                    r = n.width,
                    l = a + n.height + window.scrollY;
                let c = n.left - o / 2 + r / 2;
                const d = 24,
                    h = c + o - window.theme.getWindowWidth() + d;
                h > 0 && (c -= h), c < 0 && (c = 0), t.style.left = `${n.left+r/2}px`, e.style.setProperty("--tooltip-top", `${l}px`), i.style.transform = `translateX(${c}px)`, e.classList.remove("is-hiding");
                const u = t => {
                    t.target === i && ("transform" !== t.propertyName && "opacity" !== t.propertyName || requestAnimationFrame((() => e.style.transform = "translate(0, -100%)")), e.removeEventListener("transitionend", u))
                };
                e.addEventListener("transitionend", u), e.classList.add("is-visible"), window.theme.handleTooltipScroll()
            }
        }
        removePin(t, e = !1, i = !1) {
            const s = document.querySelector("[data-tooltip-container]"),
                o = s.classList.contains("is-visible");
            s && (e && !this.tooltip.hasAttribute("data-tooltip-stop-mouseenter") || !e) && (o && (i || t.detail.hideTransition) && (s.classList.add("is-hiding"), this.hideTransitionTimeout && clearTimeout(this.hideTransitionTimeout), this.hideTransitionTimeout = setTimeout((() => {
                s.classList.remove("is-hiding")
            }), this.transitionSpeed)), s.classList.remove("is-visible"))
        }
        disconnectedCallback() {
            this.tooltip.removeEventListener("mouseenter", this.addPinMouseEvent), this.tooltip.removeEventListener("mouseleave", this.removePinMouseEvent), this.tooltip.removeEventListener("theme:tooltip:init", this.addPinEvent), this.animatedContainer && (this.animatedContainer.removeEventListener("animationend", this.handleAnimationEnd), this.animatedContainer.removeEventListener("transitionend", this.handleTransitionEnd))
        }
        constructor() {
            super(), this.tooltip = this, this.hasAttribute("data-tooltip") || (this.tooltip = this.querySelector("[data-tooltip]")), this.rootClass = "tooltip-default", this.isAnimatingClass = "is-animating", this.label = this.tooltip.getAttribute("data-tooltip"), this.transitionSpeed = 200, this.hideTransitionTimeout = 0, this.animatedContainer = this.tooltip.closest("[data-aos]"), this.addPinEvent = () => this.addPin(), this.addPinMouseEvent = () => this.addPin(!0), this.removePinMouseEvent = t => this.removePin(t, !0, !0)
        }
    });
    const Ni = [];
    const Ui = "[data-shopify-xr]",
        ji = "[data-product-single-media-group]",
        Qi = "data-shopify-model3d-id";
    let Ki = class extends window.theme.DeferredMedia {
        loadContent() {
            var t;
            super.loadContent(), this.modelId = this.element.dataset.modelId, this.xrButton = null === (t = this.mediaContainer.closest(ji)) || void 0 === t ? void 0 : t.parentElement.querySelector(Ui), Shopify.loadFeatures([{
                name: "model-viewer-ui",
                version: "1.0",
                onLoad: this.setupModelViewerUI.bind(this)
            }])
        }
        setupModelViewerUI(t) {
            t ? console.warn(t) : (this.modelViewerUI = new Shopify.ModelViewerUI(this.element), this.setupModelViewerListeners())
        }
        setupModelViewerListeners() {
            this.mediaContainer.addEventListener("theme:media:visible", (() => {
                this.xrButton.setAttribute(Qi, this.modelId), window.theme.touch || (this.modelViewerUI.play(), this.mediaContainer.dispatchEvent(new CustomEvent("theme:media:play"), {
                    bubbles: !0
                }))
            })), this.mediaContainer.addEventListener("theme:media:hidden", (() => {
                this.modelViewerUI.pause()
            })), this.mediaContainer.addEventListener("xrLaunch", (() => {
                this.modelViewerUI.pause()
            })), this.element.addEventListener("load", (() => {
                this.xrButton.setAttribute(Qi, this.modelId), this.mediaContainer.dispatchEvent(new CustomEvent("theme:media:play"), {
                    bubbles: !0
                })
            })), this.element.addEventListener("shopify_model_viewer_ui_toggle_play", (() => {
                this.pauseOtherMedia(), setTimeout((() => {
                    this.mediaContainer.dispatchEvent(new CustomEvent("theme:media:play"), {
                        bubbles: !0
                    })
                }), 50)
            })), this.element.addEventListener("shopify_model_viewer_ui_toggle_pause", (() => {
                this.mediaContainer.dispatchEvent(new CustomEvent("theme:media:pause"), {
                    bubbles: !0
                })
            })), this.pauseOtherMedia()
        }
        constructor() {
            super()
        }
    };
    window.ProductModel = {
        loadShopifyXR() {
            Shopify.loadFeatures([{
                name: "shopify-xr",
                version: "1.0",
                onLoad: this.setupShopifyXR.bind(this)
            }])
        },
        setupShopifyXR(t) {
            t ? console.warn(t) : window.ShopifyXR ? (document.querySelectorAll('[id^="ModelJson-"]').forEach((t => {
                window.ShopifyXR.addModels(JSON.parse(t.textContent)), t.remove()
            })), window.ShopifyXR.setupXRElements()) : document.addEventListener("shopify_xr_initialized", (() => this.setupShopifyXR()))
        }
    }, window.addEventListener("DOMContentLoaded", (() => {
        window.ProductModel && window.ProductModel.loadShopifyXR()
    }));
    customElements.get("product-model") || customElements.define("product-model", Ki);
    const Yi = 400,
        Xi = ".pswp",
        Gi = ".pswp__custom-close",
        Ji = "iframe, video",
        Zi = ".pswp__custom-iframe",
        ts = ".pswp__thumbs",
        es = ".pswp__button, .pswp__caption-close",
        is = "is-current",
        ss = "pswp--custom-loader",
        os = "pswp--custom-opening",
        ns = "pswp__loader",
        as = "pswp--open",
        rs = "pswp__button--close",
        ls = "pswp--notification",
        cs = "popup-quick-view",
        ds = "js-drawer-open-cart",
        hs = "popup-quick-view--animate-out",
        us = "data-pswp-option-classes",
        ps = "data-video-type",
        ms = `<div class="${ns}"><div class="loader loader--image"><div class="loader__image"></div></div></div>`;
    window.theme = window.theme || {}, window.theme.LoadPhotoswipe = class {
        init() {
            document.dispatchEvent(new CustomEvent("theme:scroll:lock", {
                bubbles: !0
            })), this.pswpElement.classList.add(os), this.initLoader(), $t({
                url: window.theme.assets.photoswipe
            }).then((() => this.loadPopup())).catch((t => console.error(t)))
        }
        initLoader() {
            if (this.pswpElement.classList.contains(ss) && "" !== this.options && this.options.mainClass) {
                this.pswpElement.setAttribute(us, this.options.mainClass);
                let t = document.createElement("div");
                t.innerHTML = ms, t = t.firstChild, this.pswpElement.appendChild(t)
            } else this.pswpElement.setAttribute(us, "")
        }
        loadPopup() {
            window.theme.closeAllTooltips();
            const t = window.themePhotoswipe.PhotoSwipe.default,
                e = window.themePhotoswipe.PhotoSwipeUI.default;
            this.pswpElement.classList.remove(os), this.popup = new t(this.pswpElement, e, this.items, this.options), this.popup.listen("afterInit", this.dispatchPopupInitEventCallback), this.popup.listen("imageLoadComplete", this.setCurrentThumbCallback), this.popup.listen("imageLoadComplete", this.loadingStateCallback), this.popup.listen("beforeChange", this.setCurrentThumbCallback), this.popup.listen("close", this.onCloseCallback), this.popup.init(), this.initPopupCallback()
        }
        loadingState(t) {
            t === this.options.index && this.pswpElement.classList.contains(ss) && this.pswpElement.classList.remove(ss)
        }
        initPopupCallback() {
            this.isVideo && this.hideUnusedButtons(), this.initVideo(), this.thumbsActions(), this.a11y.trapFocus({
                container: this.pswpElement
            }), this.pswpElement.classList.contains(cs) && new class {
                initEventListeners() {
                    this.popupCloseButtons.forEach((t => {
                        t.addEventListener("keyup", (t => {
                            t.code !== theme.keyboardKeys.ENTER && t.code !== theme.keyboardKeys.NUMPADENTER && t.code !== theme.keyboardKeys.SPACE || this.closePopup(t)
                        })), t.addEventListener("click", (t => {
                            this.closePopup(t)
                        }))
                    })), this.initShopTheLookListeners()
                }
                handleDraggable(t, e) {
                    t && (t.options.draggable = Boolean(e), t.updateDraggable())
                }
                initItems(t, e) {
                    this.initProductSlider(t, e), this.initShopifyXrLaunch(t), window.theme.wrapElements(t), Shopify.PaymentButton && Shopify.PaymentButton.init(), t.classList.remove("is-loading")
                }
                init() {
                    document.addEventListener("submit", this.prevent3dModelSubmitEvent), this.pswpElement.addEventListener("click", this.outerCloseEvent), document.dispatchEvent(new CustomEvent("theme:popup:open", {
                        bubbles: !0
                    })), this.popup.listen("preventDragEvent", ((t, e, i) => {
                        i.prevent = !1
                    })), this.pswpElement.addEventListener("mousedown", (() => {
                        this.popup.framework.unbind(window, "pointermove pointerup pointercancel", this.popup)
                    })), this.popup.listen("initialZoomInEnd", (() => {
                        document.body.classList.add("js-quick-view-visible");
                        const t = this.quickViewItemHolders.length > 0,
                            e = this.quickViewInner.querySelector("[data-quick-view-focus]"),
                            i = this.quickViewInner.querySelector("[data-quick-view-item-holder].is-active"),
                            s = t ? i.querySelector("[data-quick-view-focus]") : e;
                        this.a11y.trapFocus({
                            container: s
                        })
                    })), this.pswpElement.addEventListener("animationend", this.closeOnAnimationEndEvent), this.popup.listen("destroy", (() => {
                        this.flkty.length > 0 && requestAnimationFrame((() => {
                            this.flkty.forEach((t => t.pausePlayer()))
                        })), document.body.classList.remove("js-quick-view-visible"), document.removeEventListener("keyup", this.closeOnEscapeEvent), this.pswpElement.removeEventListener("click", this.outerCloseEvent), this.pswpElement.removeEventListener("animationend", this.closeOnAnimationEndEvent), document.removeEventListener("submit", this.prevent3dModelSubmitEvent), this.deferredMedias.forEach((t => {
                            t.removeAttribute("loaded");
                            const e = t.closest("[data-product-single-media-wrapper]");
                            e.dispatchEvent(new CustomEvent("theme:media:hidden"), {
                                bubbles: !0
                            }), e.classList.add("media--hidden")
                        }))
                    })), document.addEventListener("keyup", this.closeOnEscapeEvent), document.addEventListener("theme:cart:added", (() => {
                        this.pswpElement.classList.contains("popup-quick-view") && this.pswpElement.classList.add("popup-quick-view--animate-out")
                    })), this.animateInQuickview(), this.initEventListeners()
                }
                handleSiblingSwatchClick(t) {
                    const e = t.target.closest("[data-sibling-handle]");
                    if (!e) return;
                    t.preventDefault();
                    const i = e.dataset.siblingHandle;
                    if (!i) return;
                    let s = this.pswpElement.querySelector("[data-quick-view-item-holder].is-active"),
                        o = null,
                        n = null;
                    if (s) o = s.querySelector("[data-quick-view-item]"), n = s;
                    else {
                        const t = this.pswpElement.querySelector("[data-quick-view-inner]");
                        o = t ? t.querySelector("[data-quick-view-item]") : null, n = t
                    }
                    if (o && n) {
                        if (this.siblingCache[i]) {
                            const t = this.siblingCache[i].cloneNode(!0),
                                e = o.querySelector("[data-quick-view-nav]");
                            if (e) {
                                const i = t.querySelector("[data-quick-view-body]"),
                                    s = t.querySelector("[data-quick-view-body-inner]");
                                if (i && s) {
                                    const t = e.cloneNode(!0);
                                    i.insertBefore(t, s)
                                }
                            }
                            return "function" == typeof o.disconnectedCallback && o.disconnectedCallback(), n.replaceChild(t, o), this.updateNavigationThumb(t, s), void this.refreshPopup()
                        }
                        fetch(`${theme.routes.root}products/${i}?section_id=api-quickview`).then((t => t.text())).then((t => {
                            const e = document.createElement("div");
                            e.innerHTML = t;
                            const a = e.querySelector("[data-quick-view-item]");
                            if (a) {
                                this.siblingCache[i] = a.cloneNode(!0);
                                const t = o.querySelector("[data-quick-view-nav]");
                                if (t) {
                                    const e = a.querySelector("[data-quick-view-body]"),
                                        i = a.querySelector("[data-quick-view-body-inner]");
                                    if (e && i) {
                                        const s = t.cloneNode(!0);
                                        e.insertBefore(s, i)
                                    }
                                }
                                "function" == typeof o.disconnectedCallback && o.disconnectedCallback(), n.replaceChild(a, o), this.updateNavigationThumb(a, s)
                            }
                            this.refreshPopup()
                        })).catch((t => console.log("error: ", t)))
                    }
                }
                updateNavigationThumb(t, e) {
                    if (!e) return;
                    const i = e.getAttribute("data-hotspot");
                    if (!i) return;
                    const s = t.querySelector("[data-product-single-media-wrapper]:not(.media--hidden)");
                    if (!s) return;
                    const o = s.getAttribute("data-type"),
                        n = s.querySelector("img"),
                        a = "video" === o || "external_video" === o,
                        r = s.querySelector(".icon-media-video"),
                        l = s.querySelector(".placeholder-svg--overlayed, .placeholder-svg"),
                        c = this.pswpElement.querySelectorAll(`[data-shop-the-look-thumb][data-hotspot-ref="${i}"]`);
                    n ? (this.thumbImages[i] = {
                        src: n.src,
                        srcset: n.srcset || "",
                        alt: n.alt || "",
                        isVideo: a,
                        videoIconHTML: a && r ? r.outerHTML : "",
                        hasPlaceholder: !1
                    }, c.forEach((t => {
                        const e = t.querySelector(".product-single__thumbnail") || t.querySelector(".popup-quick-view__thumbnail");
                        let i = t.querySelector(".product-single__thumbnail-img");
                        if (!i && e) {
                            e.innerHTML = "";
                            const t = document.createElement("img");
                            t.className = "product-single__thumbnail-img", e.appendChild(t), i = t
                        }
                        if (i && (i.src = n.src, n.srcset && (i.srcset = n.srcset), n.alt && (i.alt = n.alt)), e) {
                            const t = e.querySelector(".icon-media-video");
                            t && t.remove(), a && r && e.insertAdjacentHTML("beforeend", r.outerHTML)
                        }
                    }))) : l && (this.thumbImages[i] = {
                        hasPlaceholder: !0,
                        placeholderHTML: l.outerHTML,
                        isVideo: !1,
                        videoIconHTML: ""
                    }, c.forEach((t => {
                        const e = t.querySelector(".product-single__thumbnail") || t.querySelector(".popup-quick-view__thumbnail");
                        if (!e) return;
                        const i = e.querySelector(".icon-media-video");
                        i && i.remove(), e.innerHTML = l.outerHTML
                    })))
                }
                refreshPopup() {
                    this.quickViewFoot = this.pswpElement.querySelector("[data-quick-view-foot-inner]"), this.quickViewInner = this.pswpElement.querySelector("[data-quick-view-inner]"), this.flkty = [], this.deferredMedias = this.pswpElement.querySelectorAll("[data-deferred-media]"), this.buttonsShopTheLookThumb = this.pswpElement.querySelectorAll("[data-shop-the-look-thumb]"), this.quickViewItemHolders = this.pswpElement.querySelectorAll("[data-quick-view-item-holder]"), this.popupCloseButtons = this.quickViewInner.querySelectorAll("[data-popup-close]");
                    const t = this.pswpElement.querySelector("[data-quick-view-item-holder].is-active"),
                        e = t ? t.querySelector("product-info") : this.pswpElement.querySelector("product-info");
                    this.initItems(e, 0), this.initEventListeners()
                }
                initShopTheLookListeners() {
                    var t;
                    null === (t = this.buttonsShopTheLookThumb) || void 0 === t || t.forEach((t => {
                        t.addEventListener("click", (t => {
                            t.preventDefault();
                            const e = t.target.matches("[data-shop-the-look-thumb]") ? t.target : t.target.closest("[data-shop-the-look-thumb]"),
                                i = this.pswpElement.querySelector(`[data-hotspot="${e.getAttribute("data-hotspot-ref")}"]`),
                                s = i.querySelector("[data-quick-view-focus]");
                            !e.classList.contains("is-active") && i && (this.flkty.length > 0 && requestAnimationFrame((() => {
                                this.flkty.forEach((t => {
                                    t.resize();
                                    const e = this.quickViewInner.querySelectorAll("[data-product-single-media-wrapper]");
                                    e.length && e.forEach((t => {
                                        t.dispatchEvent(new CustomEvent("theme:media:hidden"), {
                                            bubbles: !0
                                        }), t.classList.add("media--hidden")
                                    }))
                                }))
                            })), i.classList.add("is-active"), this.quickViewItemHolders.forEach((t => {
                                t !== i && t.classList.remove("is-active")
                            })), Object.keys(this.thumbImages).forEach((t => {
                                const e = this.thumbImages[t],
                                    s = i.querySelector(`[data-shop-the-look-thumb][data-hotspot-ref="${t}"]`);
                                if (!s) return;
                                const o = s.querySelector(".product-single__thumbnail") || s.querySelector(".popup-quick-view__thumbnail");
                                if (!o) return;
                                const n = o.querySelector(".icon-media-video");
                                n && n.remove(), e.hasPlaceholder && (o.innerHTML = "");
                                let a = o.querySelector(".product-single__thumbnail-img");
                                if (!a) {
                                    const t = document.createElement("img");
                                    t.className = "product-single__thumbnail-img", o.appendChild(t), a = t
                                }
                                a && (a.src = e.src, e.srcset && (a.srcset = e.srcset), e.alt && (a.alt = e.alt)), e.isVideo && e.videoIconHTML && o.insertAdjacentHTML("beforeend", e.videoIconHTML)
                            })), this.a11y.trapFocus({
                                container: s
                            }))
                        }))
                    }))
                }
                prevent3dModelSubmit(t) {
                    t.submitter.closest("[data-deferred-media]") && t.submitter.closest("[data-product-form]") && t.preventDefault()
                }
                closeQuickviewOnMobile() {
                    window.innerWidth < window.theme.sizes.large && document.body.classList.contains("js-quick-view-visible") && this.popup.close()
                }
                animateInQuickview() {
                    this.pswpElement.classList.add("popup-quick-view--animate-in"), this.quickViewFoot.addEventListener("animationend", (t => {
                        this.handleAnimatedState(t)
                    })), this.pswpElement.addEventListener("animationend", (t => {
                        this.handleAnimatedState(t, !0)
                    }))
                }
                handleAnimatedState(t, e = !1) {
                    if ("quickViewAnimateInUp" == t.animationName) {
                        if (e && window.innerWidth >= window.theme.sizes.small) return;
                        this.pswpElement.classList.add("popup-quick-view--animated"), this.pswpElement.classList.remove("popup-quick-view--animate-in"), document.body.classList.remove("js-quick-view-from-cart"), q(this.pswpElement)
                    }
                }
                closePopup(t) {
                    if (null == t || t.preventDefault(), document.body.classList.contains("js-drawer-open")) {
                        const t = document.querySelector("drawer-element.is-open");
                        "function" == typeof t.close && t.close()
                    }
                    this.pswpElement.classList.add("popup-quick-view--animate-out")
                }
                closeOnAnimationEnd(t) {
                    "quickViewAnimateOutRight" != t.animationName && "quickViewAnimateOutDown" != t.animationName || (this.popup.template.classList.remove("popup-quick-view--animate-out", "popup-quick-view--animated"), this.popup.close(), document.dispatchEvent(new CustomEvent("theme:quickview:closed")))
                }
                closeOnEscape(t) {
                    const e = document.body.classList.contains("js-quick-view-visible"),
                        i = document.body.classList.contains("notification-popup-visible");
                    t.code === theme.keyboardKeys.ESCAPE && e && !i && this.closePopup(t)
                }
                initProductSlider(t, e) {
                    const i = t.querySelector("[data-product-single-media-slider]"),
                        s = t.querySelectorAll("[data-product-single-media-wrapper]");
                    if (s.length > 1) {
                        const o = new window.theme.Flickity(i, {
                            wrapAround: !0,
                            cellAlign: "left",
                            pageDots: !1,
                            prevNextButtons: !0,
                            adaptiveHeight: !1,
                            pauseAutoPlayOnHover: !1,
                            selectedAttraction: .2,
                            friction: 1,
                            autoPlay: !1,
                            on: {
                                ready: () => {
                                    requestAnimationFrame((() => {
                                        o.resize()
                                    }))
                                },
                                settle: () => {
                                    const e = o.selectedElement.getAttribute("data-media-id");
                                    this.switchMedia(t, e)
                                }
                            }
                        });
                        this.flkty.push(o), s.length && s.forEach((t => {
                            t.addEventListener("theme:media:play", (() => {
                                this.handleDraggable(this.flkty[e], !1), t.closest("[data-product-single-media-slider]").classList.add("has-media-active")
                            })), t.addEventListener("theme:media:pause", (() => {
                                this.handleDraggable(this.flkty[e], !0), t.closest("[data-product-single-media-slider]").classList.remove("has-media-active")
                            }))
                        })), window.theme.flickitySmoothScrolling(i)
                    }
                }
                switchMedia(t, e) {
                    t && "function" == typeof t.switchMedia && t.switchMedia(e)
                }
                initShopifyXrLaunch(t) {
                    t && "function" == typeof t.initShopifyXrLaunch && t.initShopifyXrLaunch()
                }
                constructor(t, e) {
                    this.popup = t, this.pswpElement = e, this.quickViewFoot = this.pswpElement.querySelector("[data-quick-view-foot-inner]"), this.quickViewInner = this.pswpElement.querySelector("[data-quick-view-inner]"), this.product = this.pswpElement.querySelectorAll("product-info"), this.flkty = [], this.deferredMedias = this.pswpElement.querySelectorAll("[data-deferred-media]"), this.buttonsShopTheLookThumb = this.pswpElement.querySelectorAll("[data-shop-the-look-thumb]"), this.quickViewItemHolders = this.pswpElement.querySelectorAll("[data-quick-view-item-holder]"), this.popupCloseButtons = this.quickViewInner.querySelectorAll("[data-popup-close]"), this.a11y = window.theme.a11y, this.thumbImages = {}, this.siblingCache = {}, this.prevent3dModelSubmitEvent = t => this.prevent3dModelSubmit(t), this.closeOnAnimationEndEvent = t => this.closeOnAnimationEnd(t), this.closeOnEscapeEvent = t => this.closeOnEscape(t), this.outerCloseEvent = t => {
                        if (this.quickViewInner.contains(t.target) || t.target.closest("[data-sibling-handle]")) t.target.closest("[data-sibling-handle]") && this.handleSiblingSwatchClick(t);
                        else {
                            const e = this.quickViewInner.nextElementSibling;
                            if (e && e.contains(t.target)) return;
                            this.closePopup(t)
                        }
                    }, this.product.forEach(((t, e) => {
                        t.hasAttribute("data-quick-view-onboarding") || this.initItems(t, e)
                    })), this.init()
                }
            }(this.popup, this.pswpElement), this.pswpElement.classList.contains(ls) && new class {
                init() {
                    this.popup.listen("preventDragEvent", ((t, e, i) => {
                        i.prevent = !1
                    }));
                    const t = -1 !== window.location.search.indexOf("?contact_posted=true");
                    this.notificationForm = this.pswpElement.querySelector("[data-notification-form]");
                    const e = this.pswpElement.querySelector("[data-popup-close]");
                    document.body.classList.add("notification-popup-visible"), this.pswpElement.addEventListener("mousedown", (() => {
                        this.popup.framework.unbind(window, "pointermove pointerup pointercancel", this.popup)
                    })), t && this.pswpElement.classList.add("pswp--success"), this.notificationForm.addEventListener("submit", (t => this.notificationSubmitEvent(t))), this.pswpElement.addEventListener("click", this.outerCloseEvent), e.addEventListener("click", (() => {
                        this.popup.close()
                    })), this.popup.listen("destroy", (() => {
                        this.notificationRemoveStorage(), this.pswpElement.removeEventListener("click", this.outerCloseEvent), document.body.classList.remove("notification-popup-visible")
                    }))
                }
                notificationSubmitEvent(t) {
                    this.notificationStopSubmit && (t.preventDefault(), this.notificationRemoveStorage(), this.notificationWriteStorage(), this.notificationStopSubmit = !1, this.notificationForm.submit())
                }
                notificationWriteStorage() {
                    void 0 !== this.sessionStorage && this.sessionStorage.setItem("notification_form_id", this.notificationForm.id)
                }
                notificationRemoveStorage() {
                    this.sessionStorage.removeItem("notification_form_id")
                }
                constructor(t, e) {
                    this.popup = t, this.pswpElement = e, this.notificationForm = null, this.notificationStopSubmit = !0, this.sessionStorage = window.sessionStorage;
                    const i = this.pswpElement.querySelector("[data-notification]");
                    this.outerCloseEvent = t => {
                        i.contains(t.target) || this.popup.close()
                    }, this.init()
                }
            }(this.popup, this.pswpElement), this.closePopup = () => {
                this.pswpElement.classList.contains(cs) ? this.pswpElement.classList.add(hs) : this.popup.close()
            }, this.closeBtn && this.closeBtn.addEventListener("click", this.closePopup), document.addEventListener("theme:cart:added", this.closePopup)
        }
        dispatchPopupInitEvent() {
            this.triggerBtn && this.triggerBtn.dispatchEvent(new CustomEvent("theme:popup:init", {
                bubbles: !0
            }))
        }
        initVideo() {
            const t = this.pswpElement.querySelector(Zi);
            if (t) {
                const e = t.getAttribute(ps);
                this.isVideo = !0, "youtube" == e ? this.loadVideoYT = new class {
                    init() {
                        window.isYoutubeAPILoaded ? this.loadYoutubePlayer() : $t({
                            url: "https://www.youtube.com/iframe_api"
                        }).then((() => this.loadYoutubePlayer()))
                    }
                    loadYoutubePlayer() {
                        const t = {
                            height: "720",
                            width: "1280",
                            playerVars: this.videoOptionsVars,
                            events: {
                                onReady: t => {
                                    const e = t.target.getIframe().id;
                                    "true" === document.querySelector(`#${e}`).getAttribute("data-enable-sound") ? t.target.unMute() : t.target.mute(), t.target.playVideo(), this.checkPlayerVisibilityFlag && (this.checkPlayerVisibility(e), window.addEventListener("scroll", window.theme.throttle((() => {
                                        this.checkPlayerVisibility(e)
                                    }), 150)))
                                },
                                onStateChange: t => {
                                    0 == t.data && t.target.playVideo(), 1 == t.data && t.target.getIframe().parentElement.classList.add("loaded")
                                }
                            }
                        };
                        t.videoId = this.videoID, this.videoID.length && YT.ready((() => {
                            Ni[this.playerID] = new YT.Player(this.playerID, t)
                        })), window.isYoutubeAPILoaded = !0
                    }
                    checkPlayerVisibility(t) {
                        let e;
                        if ("string" == typeof t) e = t;
                        else {
                            if (null == t.data) return;
                            e = t.data.id
                        }
                        const i = document.getElementById(e + "-container");
                        if (!i) return;
                        const s = Ni[e],
                            o = i.getBoundingClientRect();
                        let n = visibilityHelper.isElementPartiallyVisible(i) || visibilityHelper.isElementTotallyVisible(i);
                        o.top < 0 && i.clientHeight + o.top >= 0 && (n = !0), n && s && "function" == typeof s.playVideo ? s.playVideo() : !n && s && "function" == typeof s.pauseVideo && s.pauseVideo()
                    }
                    unload() {
                        const t = "youtube-" + this.container.getAttribute("data-section-id");
                        Ni[t] && Ni[t].destroy()
                    }
                    constructor(t) {
                        this.container = t, this.player = this.container.querySelector("[data-video-id]"), this.player && (this.videoOptionsVars = {}, this.videoID = this.player.getAttribute("data-video-id"), this.videoType = this.player.getAttribute("data-video-type"), "youtube" == this.videoType && (this.checkPlayerVisibilityFlag = "true" === this.player.getAttribute("data-check-player-visibility"), this.playerID = this.player.querySelector("[data-youtube-wrapper]") ? this.player.querySelector("[data-youtube-wrapper]").id : this.player.id, this.player.hasAttribute("data-hide-options") && (this.videoOptionsVars = {
                            cc_load_policy: 0,
                            iv_load_policy: 3,
                            modestbranding: 1,
                            playsinline: 1,
                            autohide: 0,
                            controls: 0,
                            branding: 0,
                            showinfo: 0,
                            rel: 0,
                            fs: 0,
                            wmode: "opaque"
                        }), this.init(), this.container.addEventListener("touchstart", (function(t) {
                            if (t.target.matches(".video-wrapper") || t.target.closest(".video-wrapper")) {
                                const e = t.target.querySelector("[data-video-id]").id;
                                Ni[e].playVideo()
                            }
                        }), {
                            passive: !0
                        })))
                    }
                }(t.parentElement) : "vimeo" == e && new class {
                    init() {
                        this.loadVimeoPlayer()
                    }
                    loadVimeoPlayer() {
                        const t = "https://vimeo.com/" + this.videoID;
                        let e = "";
                        const i = this.player,
                            s = {
                                url: t,
                                background: this.enableBackground,
                                muted: this.disableSound,
                                autoplay: this.enableAutoplay,
                                loop: this.enableLoop
                            };
                        for (let t in s) e += encodeURIComponent(t) + "=" + encodeURIComponent(s[t]) + "&";
                        fetch(`https://vimeo.com/api/oembed.json?${e}`).then((t => t.json())).then((function(t) {
                            i.innerHTML = t.html, setTimeout((function() {
                                i.parentElement.classList.add("loaded")
                            }), 1e3)
                        })).catch((function() {
                            console.log("error")
                        }))
                    }
                    constructor(t) {
                        this.container = t, this.player = this.container.querySelector("[data-video-id]"), this.player && (this.videoID = this.player.getAttribute("data-video-id"), this.videoType = this.player.getAttribute("data-video-type"), this.enableBackground = "true" === this.player.getAttribute("data-enable-background"), this.disableSound = "false" === this.player.getAttribute("data-enable-sound"), this.enableAutoplay = "false" !== this.player.getAttribute("data-enable-autoplay"), this.enableLoop = "false" !== this.player.getAttribute("data-enable-loop"), "vimeo" == this.videoType && this.init())
                    }
                }(t.parentElement)
            }
        }
        thumbsActions() {
            this.popupThumbsContainer && this.popupThumbsContainer.firstChild && (this.popupThumbsContainer.addEventListener("wheel", (t => this.stopDisabledScroll(t))), this.popupThumbsContainer.addEventListener("mousewheel", (t => this.stopDisabledScroll(t))), this.popupThumbsContainer.addEventListener("DOMMouseScroll", (t => this.stopDisabledScroll(t))), this.popupThumbs = this.pswpElement.querySelectorAll(`${ts} > *`), this.popupThumbs.forEach(((t, e) => {
                t.addEventListener("click", (i => {
                    i.preventDefault(), t.parentElement.querySelector(`.${is}`).classList.remove(is), t.classList.add(is), this.popup.goTo(e)
                }))
            })))
        }
        hideUnusedButtons() {
            this.pswpElement.querySelectorAll(es).forEach((t => {
                t.classList.contains(rs) || (t.style.display = "none")
            }))
        }
        stopDisabledScroll(t) {
            t.stopPropagation()
        }
        onClose() {
            const t = this.pswpElement.querySelector(Ji);
            if (t && t.parentNode.removeChild(t), this.popupThumbsContainer && this.popupThumbsContainer.firstChild)
                for (; this.popupThumbsContainer.firstChild;) this.popupThumbsContainer.removeChild(this.popupThumbsContainer.firstChild);
            this.pswpElement.setAttribute(us, "");
            const e = this.pswpElement.querySelector(`.${ns}`);
            e && this.pswpElement.removeChild(e), document.body.classList.contains(ds) || this.a11y.removeTrapFocus(), this.loadVideoYT && this.loadVideoYT.unload(), document.removeEventListener("theme:cart:added", this.closePopup), setTimeout((() => {
                const t = this.recentlyOpenedPopupsCount(),
                    e = document.body.classList.contains(ds);
                0 !== t || e || document.dispatchEvent(new CustomEvent("theme:scroll:unlock", {
                    bubbles: !0
                }))
            }), Yi)
        }
        recentlyOpenedPopupsCount() {
            let t = 0;
            return this.pswpElements.forEach((e => {
                e.classList.contains(as) && (t += 1)
            })), t
        }
        setCurrentThumb() {
            if (this.popupThumbsContainer && this.popupThumbsContainer.firstChild) return;
            const t = this.pswpElement.querySelector(`${ts} > .${is}`);
            if (t && t.classList.remove(is), !this.popupThumbs) return;
            const e = this.popupThumbs[this.popup.getCurrentIndex()];
            e.classList.add(is), this.scrollThumbs(e)
        }
        scrollThumbs(t) {
            const e = this.popupThumbsContainer.scrollLeft + this.popupThumbsContainer.offsetWidth,
                i = t.offsetLeft;
            if (e <= i + t.offsetWidth || e > i) {
                const e = parseInt(window.getComputedStyle(t).marginLeft);
                this.popupThumbsContainer.scrollTo({
                    top: 0,
                    left: i - e,
                    behavior: "smooth"
                })
            }
        }
        constructor(t, e = "", i = 0, s = null) {
            this.items = t, this.triggerBtn = s, this.pswpElements = document.querySelectorAll(Xi), this.pswpElement = this.pswpElements[i], this.popup = null, this.popupThumbs = null, this.loadVideoYT = null, this.popupThumbsContainer = this.pswpElement.querySelector(ts), this.closeBtn = this.pswpElement.querySelector(Gi);
            this.options = "" !== e ? e : {
                history: !1,
                focus: !1,
                mainClass: ""
            }, this.onCloseCallback = () => this.onClose(), this.dispatchPopupInitEventCallback = () => this.dispatchPopupInitEvent(), this.setCurrentThumbCallback = () => this.setCurrentThumb(), this.loadingStateCallback = t => this.loadingState(t), this.a11y = window.theme.a11y, this.init()
        }
    };
    let gs = class extends HTMLElement {
        connectedCallback() {
            this.changeHandler = t => {
                const e = this.getInputForEventTarget(t.target);
                publish(theme.PUB_SUB_EVENTS.optionValueSelectionChange, {
                    data: {
                        event: t,
                        target: e,
                        selectedOptionValues: this.selectedOptionValues
                    }
                })
            }, this.addEventListener("change", this.changeHandler)
        }
        disconnectedCallback() {
            this.changeHandler && this.removeEventListener("change", this.changeHandler)
        }
        getInputForEventTarget(t) {
            return "SELECT" === t.tagName ? t.selectedOptions[0] : t
        }
        get selectedOptionValues() {
            return [...Array.from(this.querySelectorAll("fieldset input:checked")), ...Array.from(this.querySelectorAll("[data-popout-input]"))].map((({
                dataset: t
            }) => t.optionValueId)).filter((t => Boolean(t)))
        }
        constructor() {
            super(), this.changeHandler = null
        }
    };
    customElements.define("variant-selects", gs), customElements.get("swatches-component") || customElements.define("swatches-component", class extends HTMLElement {
        connectedCallback() {
            this.swatchesContainer = this.querySelector("fieldset"), this.selectorWrapper = this.closest("[data-option-position]"), this.selectorWrapper && (this.moreLink = this.selectorWrapper.querySelector("[data-swatches-more]"), this.setupVariantChangeListener(), this.restoreStateFromParent(), this.observeSwatch(), this.checkSwatchesHeight(), this.setupMoreLinkHandler(), document.addEventListener("theme:resize:width", this.handleSwatchResize))
        }
        disconnectedCallback() {
            this.observers.forEach((t => t.disconnect())), this.observers.clear(), document.removeEventListener("theme:resize:width", this.handleSwatchResize), this.variantChangeUnsubscriber && (this.variantChangeUnsubscriber(), this.variantChangeUnsubscriber = null)
        }
        setupVariantChangeListener() {
            var t, e;
            this.variantChangeHandler = t => {
                this.saveStateToParent()
            }, (null === (t = window.theme) || void 0 === t || null === (e = t.PUB_SUB_EVENTS) || void 0 === e ? void 0 : e.optionValueSelectionChange) && window.subscribe && (this.variantChangeUnsubscriber = window.subscribe(window.theme.PUB_SUB_EVENTS.optionValueSelectionChange, this.variantChangeHandler))
        }
        saveStateToParent() {
            const t = this.closest("product-form");
            t && "function" == typeof t.saveSwatchesState && t.saveSwatchesState(this)
        }
        restoreStateFromParent() {
            const t = this.closest("product-form");
            if (!t || "function" != typeof t.getSwatchesState) return;
            const e = t.getSwatchesState(this);
            e ? (e.isLarge && this.selectorWrapper.classList.add("selector-wrapper--large"), e.isVisible && this.selectorWrapper.classList.add("selector-wrapper--visible"), e.maxHeight && this.style.setProperty("--swatches-max-height", e.maxHeight), this.isRestoringState = !0, setTimeout((() => {
                this.isRestoringState = !1
            }), 100)) : this.checkSelectedSwatchVisibility()
        }
        checkSelectedSwatchVisibility() {
            const t = this.swatchesContainer.querySelector('input[type="radio"]:checked');
            if (!t) return;
            const e = t.getBoundingClientRect(),
                i = this.swatchesContainer.getBoundingClientRect();
            (e.bottom > i.bottom || e.top < i.top) && this.selectorWrapper.classList.add("selector-wrapper--visible")
        }
        setupMoreLinkHandler() {
            this.moreLink && this.moreLink.addEventListener("click", (t => {
                t.preventDefault(), this.selectorWrapper.classList.contains("selector-wrapper--large") && (this.selectorWrapper.classList.contains("selector-wrapper--visible") ? this.selectorWrapper.classList.remove("selector-wrapper--visible") : this.selectorWrapper.classList.add("selector-wrapper--visible"))
            }))
        }
        observeSwatch() {
            const t = this.swatchesContainer.querySelector('input[type="radio"]:checked');
            if (!t) return;
            const e = this.swatchesContainer.querySelector(`label[for="${t.id}"]`);
            if (!e) return;
            if (Array.from(this.observers).find((t => t.target === e))) return;
            this.isRestoringState || this.selectorWrapper.classList.remove("selector-wrapper--visible");
            const i = new IntersectionObserver((t => {
                t.forEach((t => {
                    0 !== t.intersectionRatio || this.isRestoringState || this.selectorWrapper.classList.add("selector-wrapper--visible")
                }))
            }), {
                root: this.swatchesContainer,
                threshold: [.95, 1]
            });
            i.target = e, i.observe(e), this.observers.add(i)
        }
        handleSwatchResize() {
            this.checkSwatchesHeight()
        }
        checkSwatchesHeight() {
            const t = this.swatchesContainer.querySelector("[data-swatches-label]"),
                e = Boolean(t.closest(".variant__labels--hide")),
                i = e ? 1 : t.offsetHeight,
                s = this.swatchesContainer.querySelector("[data-swatches-button]"),
                o = e ? 0 : parseInt(window.getComputedStyle(t).getPropertyValue("margin-bottom")),
                n = parseInt(window.getComputedStyle(s).getPropertyValue("margin-bottom")),
                a = i + o + 2 * s.offsetHeight + 2 * n,
                r = this.swatchesContainer.scrollHeight;
            this.selectorWrapper.classList.remove("selector-wrapper--large"), this.style.removeProperty("--swatches-max-height"), requestAnimationFrame((() => {
                r > a && (this.style.setProperty("--swatches-max-height", `${this.swatchesContainer.offsetHeight}px`), this.selectorWrapper.classList.add("selector-wrapper--large"))
            }))
        }
        constructor() {
            super(), this.handleSwatchResize = this.handleSwatchResize.bind(this), this.observers = new Set, this.isRestoringState = !1
        }
    }), customElements.get("quick-add-button") || customElements.define("quick-add-button", class extends HTMLElement {
        connectedCallback() {
            this.buttonATC = this.closest("[data-add-to-cart]"), this.dispatchAddToCartEventCallback = t => this.dispatchAddToCartEvent(t), this.buttonATC && this.buttonATC.addEventListener("click", this.dispatchAddToCartEventCallback)
        }
        dispatchAddToCartEvent(t) {
            t.preventDefault(), this.a11y.state.trigger = this.buttonATC, document.dispatchEvent(new CustomEvent("theme:cart:add", {
                detail: {
                    button: this.buttonATC
                }
            }))
        }
        disconnectedCallback() {
            this.buttonATC && this.buttonATC.removeEventListener("click", this.dispatchAddToCartEventCallback)
        }
        constructor() {
            super(), this.a11y = window.theme.a11y
        }
    });
    const vs = 0,
        bs = {
            history: !1,
            focus: !1,
            mainClass: "popup-quick-view pswp--not-close-btn",
            showHideOpacity: !1,
            closeOnVerticalDrag: !1,
            closeOnScroll: !1,
            modal: !1,
            escKey: !1
        };
    customElements.get("quick-view-button") || customElements.define("quick-view-button", class extends HTMLElement {
        connectedCallback() {
            requestAnimationFrame((() => {
                this.initializeButton()
            }))
        }
        initializeButton() {
            this.buttonQuickView = this.closest("[data-button-quick-view]"), this.container = this.closest("[data-section-type]"), this.buttonQuickView && !this.buttonQuickView.hasAttribute("data-initialized") && (this.buttonQuickView.addEventListener("click", (t => this.initPhotoswipe(t))), this.buttonQuickView.addEventListener("theme:popup:init", (() => {
                this.buttonQuickView.classList.remove("is-loading"), this.buttonQuickView.hasAttribute("data-shop-the-look-quick-view") && this.popupInit()
            })), this.buttonQuickView.setAttribute("data-initialized", ""))
        }
        popupInit() {
            var t, e;
            const i = this.buttonQuickView.getAttribute("data-hotspot"),
                s = this.loadPhotoswipe.pswpElement.querySelector(`[data-hotspot="${i}"]`),
                o = this.loadPhotoswipe.pswpElement.querySelectorAll("[data-quick-view-item-holder]");
            s.classList.add("is-active"), o.forEach((t => {
                t !== s && t.classList.remove("is-active")
            })), this.toggleQuickViewButtonsLoadingClasses(!0), this.toggleQuickViewThumbsLoadingClasses(!0);
            const n = t => {
                "quickViewAnimateInUp" === t.animationName && requestAnimationFrame((() => {
                    this.toggleQuickViewThumbsLoadingClasses(!1)
                })), "quickViewAnimateOutDown" === t.animationName && this.loadPhotoswipe.pswpElement.removeEventListener("animationend", n)
            };
            this.loadPhotoswipe.pswpElement.addEventListener("animationend", n), null === (t = this.loadPhotoswipe) || void 0 === t || null === (e = t.popup) || void 0 === e || e.listen("destroy", (() => {
                this.toggleQuickViewButtonsLoadingClasses(!1), this.toggleQuickViewThumbsLoadingClasses(!1)
            }))
        }
        toggleQuickViewButtonsLoadingClasses(t = !0) {
            t ? this.buttonQuickView.classList.add("is-loading") : this.buttonQuickView.classList.remove("is-loading")
        }
        toggleQuickViewThumbsLoadingClasses(t = !0) {
            var e, i, s;
            (this.buttonsShopTheLookThumb = null === (e = this.loadPhotoswipe) || void 0 === e ? void 0 : e.pswpElement.querySelectorAll("[data-shop-the-look-thumb]"), t) ? null === (s = this.buttonsShopTheLookThumb) || void 0 === s || s.forEach((t => {
                t.classList.add("is-loading")
            })): null === (i = this.buttonsShopTheLookThumb) || void 0 === i || i.forEach((t => {
                t.classList.remove("is-loading")
            }))
        }
        initPhotoswipe(t) {
            t.preventDefault();
            const e = t.target.matches("[data-button-quick-view]") ? t.target : t.target.closest("[data-button-quick-view]"),
                i = window.innerWidth < theme.sizes.small;
            let s = "",
                o = !1;
            if (e.hasAttribute("data-shop-the-look-quick-view")) {
                if (!i) return;
                o = !0
            }
            bs.mainClass = "popup-quick-view pswp--not-close-btn", e.classList.add("is-loading"), e.closest("[data-cart-drawer]") && document.body.classList.add("js-quick-view-from-cart"), this.a11y.state.trigger = e, this.a11y.state.mainTrigger = this.a11y.state.trigger, e.hasAttribute("data-variant-id") && (s = `&variant=${e.getAttribute("data-variant-id")}`);
            const n = `${theme.routes.root}products/${e.getAttribute("data-handle")}?section_id=api-quickview${s}`;
            if (o) {
                bs.mainClass = "popup-quick-view popup-quick-view--shop-the-look pswp--not-close-btn", this.buttonQuickView.classList.add("is-loading");
                const t = new XMLSerializer,
                    i = this.container.querySelector("[data-quick-view-items-template]").content.firstElementChild.cloneNode(!0),
                    s = t.serializeToString(i);
                this.loadPhotoswipeWithTemplate(s, e)
            } else this.loadPhotoswipeFromFetch(n, e)
        }
        loadPhotoswipeWithTemplate(t, e) {
            const i = [{
                html: t
            }];
            this.loadPhotoswipe = new window.theme.LoadPhotoswipe(i, bs, vs, e)
        }
        loadPhotoswipeFromFetch(t, e) {
            fetch(t).then((t => t.text())).then((t => {
                const i = [{
                    html: t
                }];
                this.loadPhotoswipe = new window.theme.LoadPhotoswipe(i, bs, vs, e)
            })).catch((t => console.log("error: ", t)))
        }
        disconnectedCallback() {
            var t, e;
            null === (t = this.loadPhotoswipe) || void 0 === t || null === (e = t.popup) || void 0 === e || e.close()
        }
        constructor() {
            super(), this.a11y = window.theme.a11y
        }
    });
    const ws = "no-outline",
        ys = "[data-skip-content]",
        fs = 'a[href="#"]';
    const Es = "[data-swatch]",
        Ls = "[data-product-block]",
        Ss = "[data-product-image-hover]",
        Cs = "[data-button-quick-view]",
        ks = "[data-grid-image]",
        As = "[data-grid-link]",
        Ts = "[data-swatches-more]",
        qs = "[data-section-type]",
        Hs = "[data-slider]",
        Is = "product__media--featured-visible",
        Ps = "product__media__hover-img--visible",
        Ds = "swatch__link--no-image",
        Ms = "no-outline",
        xs = "is-visible",
        Fs = "data-swatch-handle",
        _s = "data-swatch-label",
        Os = "data-swatch-image",
        Vs = "data-swatch-image-id",
        Bs = "data-swatch-variant",
        $s = "data-variant-id",
        Ws = "data-variant-secondary-id";
    let Rs = class extends HTMLElement {
        connectedCallback() {
            this.swatchElements = this.querySelectorAll(Es), this.swatchElements.forEach((t => {
                this.variant = t.getAttribute(Bs), this.imageId = t.getAttribute(Vs);
                const e = t.getAttribute(Os);
                if (this.variant && this.outer) {
                    const i = t.nextElementSibling;
                    this.handleClicks(i), !e && i && i.classList.add(Ds)
                }
            })), this.handleShowMore()
        }
        handleShowMore() {
            this.initialHeight = this.offsetHeight, this.expandedHeight = this.initialHeight;
            const t = this.closest(qs),
                e = this.querySelector(Ts);
            e && (null == e || e.addEventListener("click", (() => {
                this.classList.add(xs)
            })), null == t || t.addEventListener("touchstart", (t => {
                this.contains(t.target) || (this.classList.remove(xs), this.dispatchEvent(new Event("mouseleave", {
                    bubbles: !0
                })))
            })), this.addEventListener("mouseenter", (() => {
                const t = e => {
                    this.expandedHeight = this.offsetHeight;
                    const i = e.target.closest(Hs);
                    this.expandedHeight > this.initialHeight && i && requestAnimationFrame((() => i.dispatchEvent(new CustomEvent("theme:slider:resize", {
                        bubbles: !1
                    })))), this.removeEventListener("animationstart", t)
                };
                this.addEventListener("animationstart", t)
            })), this.addEventListener("mouseleave", (() => {
                const t = e => {
                    const i = e.target.closest(Hs);
                    this.expandedHeight > this.initialHeight && i && requestAnimationFrame((() => i.dispatchEvent(new CustomEvent("theme:slider:resize", {
                        bubbles: !1
                    })))), this.removeEventListener("animationstart", t)
                };
                this.addEventListener("animationstart", t)
            })))
        }
        handleClicks(t) {
            t.addEventListener("click", (e => {
                const i = !document.body.classList.contains(Ms),
                    s = t.getAttribute(Bs);
                i || (e.preventDefault(), this.updateImagesAndLinksOnEvent(s))
            })), t.addEventListener("keyup", (e => {
                const i = !document.body.classList.contains(Ms),
                    s = t.getAttribute(Bs);
                e.code !== theme.keyboardKeys.ENTER && e.code !== theme.keyboardKeys.NUMPADENTER || i || (e.preventDefault(), t.dispatchEvent(new Event("mouseenter", {
                    bubbles: !0
                })), this.updateImagesAndLinksOnEvent(s))
            }))
        }
        updateImagesAndLinksOnEvent(t) {
            this.updateLinks(t), this.replaceImages(t)
        }
        updateLinks(t) {
            this.linkElements = this.outer.querySelectorAll(As), this.quickView = this.outer.querySelector(Cs), this.linkElements.length && this.linkElements.forEach((e => {
                const i = this.getUrlWithVariant(e.getAttribute("href"), t);
                e.setAttribute("href", i)
            })), this.quickView && "quick_buy" === theme.settings.quickBuy && this.quickView.setAttribute($s, t)
        }
        replaceImages(t) {
            const e = this.outer.querySelector(`[${Ws}="${t}"]`),
                i = this.outer.querySelector(`[${$s}="${t}"]`),
                s = [...this.outer.querySelectorAll(ks)].find((t => t.classList.contains(Is)));
            if (i && this.imageId) {
                if (!e || !s) return;
                const t = () => {
                    requestAnimationFrame((() => {
                        s.classList.remove(Is), i.classList.add(Is), requestAnimationFrame((() => {
                            e.classList.remove(Is)
                        }))
                    })), e.removeEventListener("animationend", t)
                };
                requestAnimationFrame((() => {
                    e.classList.add(Is)
                })), e.addEventListener("animationend", t)
            }
            "image" === theme.settings.productGridHover && (this.hoverImages = this.outer.querySelectorAll(Ss)), this.hoverImages.length > 1 && this.hoverImages.forEach((e => {
                e.classList.remove(Ps), e.getAttribute($s) === t ? e.classList.add(Ps) : this.hoverImages[0].classList.add(Ps)
            }))
        }
        getUrlWithVariant(t, e) {
            return /variant=/.test(t) ? t.replace(/(variant=)[^&]+/, "$1" + e) : /\?/.test(t) ? t.concat("&variant=").concat(e) : t.concat("?variant=").concat(e)
        }
        constructor() {
            super(), this.handle = this.getAttribute(Fs), this.label = this.getAttribute(_s).trim().toLowerCase(), this.outer = this.closest(Ls), this.imageId = null, this.variant = null, this.hoverImages = []
        }
    };
    document.documentElement.style.setProperty("--scrollbar-width", `${(()=>{const t=document.createElement("div");t.style.visibility="hidden",t.style.overflow="scroll",t.style.msOverflowStyle="scrollbar",document.body.appendChild(t);const e=document.createElement("div");t.appendChild(e);const i=t.offsetWidth-e.offsetWidth;return t.parentNode.removeChild(t),i})()}px`), document.addEventListener("DOMContentLoaded", (function() {
        new class {
            init() {
                this.body = document.body, this.inPageLink = document.querySelector(ys), this.linkesWithOnlyHash = document.querySelectorAll(fs), this.isFocused = !1, this.focusHash(), this.bindInPageLinks(), this.clickEvents(), this.focusEvents(), this.focusEventsOff()
            }
            clickEvents() {
                this.inPageLink && this.inPageLink.addEventListener("click", (t => {
                    t.preventDefault()
                })), this.linkesWithOnlyHash && this.linkesWithOnlyHash.forEach((t => {
                    t.addEventListener("click", (t => {
                        t.preventDefault()
                    }))
                }))
            }
            focusEvents() {
                document.addEventListener("keyup", (t => {
                    t.code === theme.keyboardKeys.TAB && (this.body.classList.remove(ws), this.isFocused = !0)
                }))
            }
            focusEventsOff() {
                document.addEventListener("mousedown", (() => {
                    this.body.classList.add(ws), this.isFocused = !1
                }))
            }
            forceFocus(t, e) {
                e = e || {};
                var i = t.tabIndex;
                t.tabIndex = -1, t.dataset.tabIndex = i, t.focus(), void 0 !== e.className && t.classList.add(e.className), t.addEventListener("blur", (function s(o) {
                    o.target.removeEventListener(o.type, s), t.tabIndex = i, delete t.dataset.tabIndex, void 0 !== e.className && t.classList.remove(e.className)
                }))
            }
            focusHash(t) {
                t = t || {};
                let e = window.location.hash;
                void 0 !== theme.settings.newHash && (e = theme.settings.newHash, window.location.hash = `#${e}`);
                const i = document.getElementById(e.slice(1));
                if (i && t.ignore && i.matches(t.ignore)) return !1;
                e && i && this.forceFocus(i, t)
            }
            bindInPageLinks(t) {
                return t = t || {}, Array.prototype.slice.call(document.querySelectorAll('a[href^="#"]')).filter((e => {
                    if ("#" === e.hash || "" === e.hash) return !1;
                    if (t.ignore && e.matches(t.ignore)) return !1;
                    if (i = e.hash.substr(1), null === document.getElementById(i)) return !1;
                    var i, s = document.querySelector(e.hash);
                    return !!s && (e.addEventListener("click", (() => {
                        this.forceFocus(s, t)
                    })), !0)
                }))
            }
            constructor() {
                this.init()
            }
        }, customElements.get("product-grid-item-swatch") || "disabled" == window.theme.settings.colorSwatchesType || customElements.define("product-grid-item-swatch", Rs)
    }))
}(themeVendor.ScrollLock);