! function() {
    "use strict";
    customElements.get("mosaic-component") || customElements.define("mosaic-component", class extends HTMLElement {
        constructor() {
            super(), this.onResizeCallback = () => this.onResize()
        }
        connectedCallback() {
            this.hasSliderMobile = this.hasAttribute("data-slider-mobile"), this.carouselMobile = this.querySelector(".carousel--mobile"), this.items = this.querySelectorAll("[data-item]"), this.updateAOSAnchors(), document.addEventListener("theme:resize:width", this.onResizeCallback)
        }
        onResize() {
            this.updateAOSAnchors()
        }
        updateAOSAnchors() {
            if ("false" != theme.settings.animationsEnabled && window.theme.isMobile() && this.hasSliderMobile && this.carouselMobile && this.items.length > 1) {
                const e = this.items[0],
                    t = e.querySelector("[data-item-content-inner]"),
                    s = e.id,
                    i = t ? t.id : s;
                e.setAttribute("data-aos-trigger", `#${s}`), t ? .setAttribute("data-aos-trigger", `#${i}`), this.items.forEach((e => {
                    const t = e.querySelectorAll("[data-aos], [data-aos-anchor]"),
                        a = e.querySelector("[data-item-content-inner]");
                    e.setAttribute("data-aos-anchor", `#${s}`), a ? .setAttribute("data-aos-anchor", `#${i}`), t.forEach((e => e.setAttribute("data-aos-anchor", `#${i}`)))
                }))
            }
        }
        disconnectedCallback() {
            document.removeEventListener("theme:resize:width", this.onResizeCallback)
        }
    })
}();