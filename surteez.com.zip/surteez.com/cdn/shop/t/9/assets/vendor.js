var themeVendor = function(t) {
    "use strict";

    function e(t, e) {
        return e.forEach((function(e) {
            e && "string" != typeof e && !Array.isArray(e) && Object.keys(e).forEach((function(i) {
                if ("default" !== i && !(i in t)) {
                    var n = Object.getOwnPropertyDescriptor(e, i);
                    Object.defineProperty(t, i, n.get ? n : {
                        enumerable: !0,
                        get: function() {
                            return e[i]
                        }
                    })
                }
            }))
        })), Object.freeze(t)
    }
    var i = "query countries($locale: SupportedLocale!) {  countries(locale: $locale) {    name    code    labels {      address1      address2      city      company      country      firstName      lastName      phone      postalCode      zone    }    formatting {      edit    }    zones {      name      code    }  }}",
        n = "https://country-service.shopifycloud.com/graphql";
    var s = "EN",
        o = ["DA", "DE", "EN", "ES", "FR", "IT", "JA", "NL", "PT", "PT_BR"];

    function r(t) {
        var e = t.replace(/-/, "_").toUpperCase();
        return -1 !== o.indexOf(e) ? e : -1 !== o.indexOf(e.substring(0, 2)) ? e.substring(0, 2) : s
    }
    var a = /({\w+})/g,
        l = "_",
        c = {
            lastName: '[name="address[last_name]"]',
            firstName: '[name="address[first_name]"]',
            company: '[name="address[company]"]',
            address1: '[name="address[address1]"]',
            address2: '[name="address[address2]"]',
            country: '[name="address[country]"]',
            zone: '[name="address[province]"]',
            postalCode: '[name="address[zip]"]',
            city: '[name="address[city]"]',
            phone: '[name="address[phone]"]'
        };

    function h(t, e, i, n) {
        var s = function(t, e) {
            return t = t || "CA", e.filter((function(e) {
                return e.code === t
            }))[0]
        }(i, n);
        ! function(t, e) {
            Object.keys(t).forEach((function(i) {
                t[i].labels.forEach((function(t) {
                    t.textContent = e.labels[i]
                }))
            }))
        }(e, s),
        function(t, e, i) {
            var n = i.formatting.edit,
                s = e.country.wrapper,
                o = !1;
            (r = n, r.split(l).map((function(t) {
                var e = t.match(a);
                return e ? e.map((function(t) {
                    var e = t.replace(/[{}]/g, "");
                    switch (e) {
                        case "zip":
                            return "postalCode";
                        case "province":
                            return "zone";
                        default:
                            return e
                    }
                })) : []
            }))).forEach((function(i) {
                i.forEach((function(n) {
                    e[n].wrapper.dataset.lineCount = i.length, e[n].wrapper && ("country" !== n ? o ? t.append(e[n].wrapper) : t.insertBefore(e[n].wrapper, s) : o = !0)
                }))
            }));
            var r
        }(t, e, s),
        function(t, e) {
            var i = t.zone;
            if (!i) return;
            if (0 === e.zones.length) return i.wrapper.dataset.ariaHidden = "true", void(i.input.innerHTML = "");
            i.wrapper.dataset.ariaHidden = "false";
            var n = i.input,
                s = n.cloneNode(!0);
            s.innerHTML = "", e.zones.forEach((function(t) {
                var e = document.createElement("option");
                e.value = t.code, e.textContent = t.name, s.appendChild(e)
            })), n.innerHTML = s.innerHTML, n.dataset.default && (n.value = n.dataset.default)
        }(e, s)
    }
    var d = Object.freeze({
        __proto__: null,
        AddressForm: function(t, e, s) {
            e = e || "en";
            var o = function(t, e) {
                var i = {};
                return Object.keys(c).forEach((function(n) {
                    var s = t.querySelector(e[n]);
                    i[n] = s ? {
                        wrapper: s.parentElement,
                        input: s,
                        labels: document.querySelectorAll('[for="' + s.id + '"]')
                    } : {}
                })), i
            }(t, function() {
                for (var t = Object({}), e = 0; e < arguments.length; e++) {
                    var i = arguments[e];
                    if (i)
                        for (var n in i) Object.prototype.hasOwnProperty.call(i, n) && (t[n] = i[n])
                }
                return t
            }(c, (s = s || {
                inputSelectors: {}
            }).inputSelectors));
            return function(t) {
                    Object.keys(t).forEach((function(e) {
                        var i = t[e].input,
                            n = t[e].labels;
                        if (i) {
                            if ("object" != typeof i) throw new TypeError(t[e] + " is missing an input or select.");
                            if ("object" != typeof n) throw new TypeError(t[e] + " is missing a label.")
                        }
                    }))
                }(o),
                function(t) {
                    if (!t) return Promise.resolve(null);
                    return fetch(location.origin + "/meta.json").then((function(t) {
                        return t.json()
                    })).then((function(t) {
                        return -1 !== t.ships_to_countries.indexOf("*") ? null : t.ships_to_countries
                    })).catch((function() {
                        return null
                    }))
                }(s.shippingCountriesOnly).then((function(s) {
                    return function(t) {
                        return fetch(n, {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json",
                                "Access-Control-Allow-Origin": "*"
                            },
                            body: JSON.stringify({
                                query: i,
                                operationName: "countries",
                                variables: {
                                    locale: r(t)
                                }
                            })
                        }).then((function(t) {
                            return t.json()
                        })).then((function(t) {
                            return t.data.countries
                        }))
                    }(e).then((function(e) {
                        ! function(t, e, i) {
                            ! function(t, e) {
                                var i = t.country.input,
                                    n = i.cloneNode(!0);
                                e.forEach((function(t) {
                                    var e = document.createElement("option");
                                    e.value = t.code, e.textContent = t.name, n.appendChild(e)
                                })), i.innerHTML = n.innerHTML, i.dataset.default && (i.value = i.dataset.default)
                            }(e, i);
                            var n = e.country.input ? e.country.input.value : null;
                            (function(t, e, i) {
                                e.country.input.addEventListener("change", (function(n) {
                                    h(t, e, n.target.value, i)
                                }))
                            })(t, e, i), h(t, e, n, i)
                        }(t, o, function(t, e) {
                            if (!e) return t;
                            return t.filter((function(t) {
                                return -1 !== e.indexOf(t.code)
                            }))
                        }(e, s))
                    }))
                }))
        }
    });

    function u(t) {
        (new Image).src = t
    }

    function p(t, e) {
        if (null === e) return t;
        if ("master" === e) return f(t);
        const i = t.match(/\.(jpg|jpeg|gif|png|bmp|bitmap|tiff|tif)(\?v=\d+)?$/i);
        if (i) {
            const n = t.split(i[0]),
                s = i[0];
            return f(`${n[0]}_${e}${s}`)
        }
        return null
    }

    function f(t) {
        return t.replace(/http(s)?:/, "")
    }
    var g = Object.freeze({
        __proto__: null,
        preload: function(t, e) {
            "string" == typeof t && (t = [t]);
            for (let i = 0; i < t.length; i++) {
                u(p(t[i], e))
            }
        },
        loadImage: u,
        imageSize: function(t) {
            const e = t.match(/.+_((?:pico|icon|thumb|small|compact|medium|large|grande)|\d{1,4}x\d{0,4}|x\d{1,4})[_\.@]/);
            return e ? e[1] : null
        },
        getSizedImageUrl: p,
        removeProtocol: f
    });
    /* @preserve
     * https://github.com/Elkfox/Ajaxinate
     * Copyright (c) 2017 Elkfox Co Pty Ltd (elkfox.com)
     * MIT License (do not remove above copyright!)
     */
    function v(t) {
        const e = t || {};
        this.settings = Object.assign({
            method: "scroll",
            container: "#AjaxinateContainer",
            pagination: "#AjaxinatePagination",
            offset: 0,
            loadingText: "Loading",
            callback: null
        }, e), this.addScrollListeners = this.addScrollListeners.bind(this), this.addClickListener = this.addClickListener.bind(this), this.checkIfPaginationInView = this.checkIfPaginationInView.bind(this), this.preventMultipleClicks = this.preventMultipleClicks.bind(this), this.removeClickListener = this.removeClickListener.bind(this), this.removeScrollListener = this.removeScrollListener.bind(this), this.removePaginationElement = this.removePaginationElement.bind(this), this.destroy = this.destroy.bind(this), this.containerElement = document.querySelector(this.settings.container), this.paginationElement = document.querySelector(this.settings.pagination), this.initialize()
    }
    v.prototype.initialize = function() {
        if (!this.containerElement) return;
        ({
            click: this.addClickListener,
            scroll: this.addScrollListeners
        })[this.settings.method]()
    }, v.prototype.addScrollListeners = function() {
        this.paginationElement && (document.addEventListener("scroll", this.checkIfPaginationInView), window.addEventListener("resize", this.checkIfPaginationInView), window.addEventListener("orientationchange", this.checkIfPaginationInView))
    }, v.prototype.addClickListener = function() {
        this.paginationElement && (this.nextPageLinkElement = this.paginationElement.querySelector("a"), this.clickActive = !0, void 0 !== this.nextPageLinkElement && null !== this.nextPageLinkElement && this.nextPageLinkElement.addEventListener("click", this.preventMultipleClicks))
    }, v.prototype.preventMultipleClicks = function(t) {
        t.preventDefault(), this.clickActive && (this.nextPageLinkElement.innerText = this.settings.loadingText, this.nextPageUrl = this.nextPageLinkElement.href, this.clickActive = !1, this.loadMore())
    }, v.prototype.checkIfPaginationInView = function() {
        const t = this.paginationElement.getBoundingClientRect().top - this.settings.offset,
            e = this.paginationElement.getBoundingClientRect().bottom + this.settings.offset;
        t <= window.innerHeight && e >= 0 && (this.nextPageLinkElement = this.paginationElement.querySelector("a"), this.removeScrollListener(), this.nextPageLinkElement && (this.nextPageLinkElement.innerText = this.settings.loadingText, this.nextPageUrl = this.nextPageLinkElement.href, this.loadMore()))
    }, v.prototype.loadMore = function() {
        this.request = new XMLHttpRequest, this.request.onreadystatechange = function() {
            if (!this.request.responseXML) return;
            if (4 === !this.request.readyState || 200 === !this.request.status) return;
            const t = this.request.responseXML.querySelectorAll(this.settings.container)[0],
                e = this.request.responseXML.querySelectorAll(this.settings.pagination)[0];
            this.containerElement.insertAdjacentHTML("beforeend", t.innerHTML), void 0 === e ? this.removePaginationElement() : (this.paginationElement.innerHTML = e.innerHTML, this.settings.callback && "function" == typeof this.settings.callback && this.settings.callback(this.request.responseXML), this.initialize())
        }.bind(this), this.request.open("GET", this.nextPageUrl), this.request.responseType = "document", this.request.send()
    }, v.prototype.removeClickListener = function() {
        this.nextPageLinkElement.removeEventListener("click", this.preventMultipleClicks)
    }, v.prototype.removePaginationElement = function() {
        this.paginationElement.innerHTML = "", this.destroy()
    }, v.prototype.removeScrollListener = function() {
        document.removeEventListener("scroll", this.checkIfPaginationInView), window.removeEventListener("resize", this.checkIfPaginationInView), window.removeEventListener("orientationchange", this.checkIfPaginationInView)
    }, v.prototype.destroy = function() {
        return {
            click: this.removeClickListener,
            scroll: this.removeScrollListener
        }[this.settings.method](), this
    };
    var m = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};

    function y(t) {
        return t && t.__esModule && Object.prototype.hasOwnProperty.call(t, "default") ? t.default : t
    }
    var b, S = {
            exports: {}
        },
        x = {
            exports: {}
        },
        E = {
            exports: {}
        };
    b = E,
        function(t, e) {
            b.exports ? b.exports = e() : t.EvEmitter = e()
        }("undefined" != typeof window ? window : m, (function() {
            function t() {}
            var e = t.prototype;
            return e.on = function(t, e) {
                if (t && e) {
                    var i = this._events = this._events || {},
                        n = i[t] = i[t] || [];
                    return -1 == n.indexOf(e) && n.push(e), this
                }
            }, e.once = function(t, e) {
                if (t && e) {
                    this.on(t, e);
                    var i = this._onceEvents = this._onceEvents || {};
                    return (i[t] = i[t] || {})[e] = !0, this
                }
            }, e.off = function(t, e) {
                var i = this._events && this._events[t];
                if (i && i.length) {
                    var n = i.indexOf(e);
                    return -1 != n && i.splice(n, 1), this
                }
            }, e.emitEvent = function(t, e) {
                var i = this._events && this._events[t];
                if (i && i.length) {
                    i = i.slice(0), e = e || [];
                    for (var n = this._onceEvents && this._onceEvents[t], s = 0; s < i.length; s++) {
                        var o = i[s];
                        n && n[o] && (this.off(t, o), delete n[o]), o.apply(this, e)
                    }
                    return this
                }
            }, e.allOff = function() {
                delete this._events, delete this._onceEvents
            }, t
        }));
    var w = {
        exports: {}
    };
    /*!
     * getSize v2.0.3
     * measure size of elements
     * MIT license
     */
    ! function(t) {
        ! function(e, i) {
            t.exports ? t.exports = i() : e.getSize = i()
        }(window, (function() {
            function t(t) {
                var e = parseFloat(t);
                return -1 == t.indexOf("%") && !isNaN(e) && e
            }
            var e = "undefined" == typeof console ? function() {} : function(t) {
                    console.error(t)
                },
                i = ["paddingLeft", "paddingRight", "paddingTop", "paddingBottom", "marginLeft", "marginRight", "marginTop", "marginBottom", "borderLeftWidth", "borderRightWidth", "borderTopWidth", "borderBottomWidth"],
                n = i.length;

            function s(t) {
                var i = getComputedStyle(t);
                return i || e("Style returned " + i + ". Are you running this code in a hidden iframe on Firefox? See https://bit.ly/getsizebug1"), i
            }
            var o, r = !1;

            function a(e) {
                if (function() {
                        if (!r) {
                            r = !0;
                            var e = document.createElement("div");
                            e.style.width = "200px", e.style.padding = "1px 2px 3px 4px", e.style.borderStyle = "solid", e.style.borderWidth = "1px 2px 3px 4px", e.style.boxSizing = "border-box";
                            var i = document.body || document.documentElement;
                            i.appendChild(e);
                            var n = s(e);
                            o = 200 == Math.round(t(n.width)), a.isBoxSizeOuter = o, i.removeChild(e)
                        }
                    }(), "string" == typeof e && (e = document.querySelector(e)), e && "object" == typeof e && e.nodeType) {
                    var l = s(e);
                    if ("none" == l.display) return function() {
                        for (var t = {
                                width: 0,
                                height: 0,
                                innerWidth: 0,
                                innerHeight: 0,
                                outerWidth: 0,
                                outerHeight: 0
                            }, e = 0; e < n; e++) t[i[e]] = 0;
                        return t
                    }();
                    var c = {};
                    c.width = e.offsetWidth, c.height = e.offsetHeight;
                    for (var h = c.isBorderBox = "border-box" == l.boxSizing, d = 0; d < n; d++) {
                        var u = i[d],
                            p = l[u],
                            f = parseFloat(p);
                        c[u] = isNaN(f) ? 0 : f
                    }
                    var g = c.paddingLeft + c.paddingRight,
                        v = c.paddingTop + c.paddingBottom,
                        m = c.marginLeft + c.marginRight,
                        y = c.marginTop + c.marginBottom,
                        b = c.borderLeftWidth + c.borderRightWidth,
                        S = c.borderTopWidth + c.borderBottomWidth,
                        x = h && o,
                        E = t(l.width);
                    !1 !== E && (c.width = E + (x ? 0 : g + b));
                    var w = t(l.height);
                    return !1 !== w && (c.height = w + (x ? 0 : v + S)), c.innerWidth = c.width - (g + b), c.innerHeight = c.height - (v + S), c.outerWidth = c.width + m, c.outerHeight = c.height + y, c
                }
            }
            return a
        }))
    }(w);
    var C = {
            exports: {}
        },
        k = {
            exports: {}
        };
    ! function(t) {
        ! function(e, i) {
            t.exports ? t.exports = i() : e.matchesSelector = i()
        }(window, (function() {
            var t = function() {
                var t = window.Element.prototype;
                if (t.matches) return "matches";
                if (t.matchesSelector) return "matchesSelector";
                for (var e = ["webkit", "moz", "ms", "o"], i = 0; i < e.length; i++) {
                    var n = e[i] + "MatchesSelector";
                    if (t[n]) return n
                }
            }();
            return function(e, i) {
                return e[t](i)
            }
        }))
    }(k),
    function(t) {
        ! function(e, i) {
            t.exports ? t.exports = i(e, k.exports) : e.fizzyUIUtils = i(e, e.matchesSelector)
        }(window, (function(t, e) {
            var i = {
                    extend: function(t, e) {
                        for (var i in e) t[i] = e[i];
                        return t
                    },
                    modulo: function(t, e) {
                        return (t % e + e) % e
                    }
                },
                n = Array.prototype.slice;
            i.makeArray = function(t) {
                return Array.isArray(t) ? t : null == t ? [] : "object" == typeof t && "number" == typeof t.length ? n.call(t) : [t]
            }, i.removeFrom = function(t, e) {
                var i = t.indexOf(e); - 1 != i && t.splice(i, 1)
            }, i.getParent = function(t, i) {
                for (; t.parentNode && t != document.body;)
                    if (t = t.parentNode, e(t, i)) return t
            }, i.getQueryElement = function(t) {
                return "string" == typeof t ? document.querySelector(t) : t
            }, i.handleEvent = function(t) {
                var e = "on" + t.type;
                this[e] && this[e](t)
            }, i.filterFindElements = function(t, n) {
                t = i.makeArray(t);
                var s = [];
                return t.forEach((function(t) {
                    if (t instanceof HTMLElement)
                        if (n) {
                            e(t, n) && s.push(t);
                            for (var i = t.querySelectorAll(n), o = 0; o < i.length; o++) s.push(i[o])
                        } else s.push(t)
                })), s
            }, i.debounceMethod = function(t, e, i) {
                i = i || 100;
                var n = t.prototype[e],
                    s = e + "Timeout";
                t.prototype[e] = function() {
                    var t = this[s];
                    clearTimeout(t);
                    var e = arguments,
                        o = this;
                    this[s] = setTimeout((function() {
                        n.apply(o, e), delete o[s]
                    }), i)
                }
            }, i.docReady = function(t) {
                var e = document.readyState;
                "complete" == e || "interactive" == e ? setTimeout(t) : document.addEventListener("DOMContentLoaded", t)
            }, i.toDashed = function(t) {
                return t.replace(/(.)([A-Z])/g, (function(t, e, i) {
                    return e + "-" + i
                })).toLowerCase()
            };
            var s = t.console;
            return i.htmlInit = function(e, n) {
                i.docReady((function() {
                    var o = i.toDashed(n),
                        r = "data-" + o,
                        a = document.querySelectorAll("[" + r + "]"),
                        l = document.querySelectorAll(".js-" + o),
                        c = i.makeArray(a).concat(i.makeArray(l)),
                        h = r + "-options",
                        d = t.jQuery;
                    c.forEach((function(t) {
                        var i, o = t.getAttribute(r) || t.getAttribute(h);
                        try {
                            i = o && JSON.parse(o)
                        } catch (e) {
                            return void(s && s.error("Error parsing " + r + " on " + t.className + ": " + e))
                        }
                        var a = new e(t, i);
                        d && d.data(t, n, a)
                    }))
                }))
            }, i
        }))
    }(C);
    var L = {
        exports: {}
    };
    ! function(t) {
        ! function(e, i) {
            t.exports ? t.exports = i(e, w.exports) : (e.Flickity = e.Flickity || {}, e.Flickity.Cell = i(e, e.getSize))
        }(window, (function(t, e) {
            function i(t, e) {
                this.element = t, this.parent = e, this.create()
            }
            var n = i.prototype;
            return n.create = function() {
                this.element.style.position = "absolute", this.element.setAttribute("aria-hidden", "true"), this.x = 0, this.shift = 0, this.element.style[this.parent.originSide] = 0
            }, n.destroy = function() {
                this.unselect(), this.element.style.position = "";
                var t = this.parent.originSide;
                this.element.style[t] = "", this.element.style.transform = "", this.element.removeAttribute("aria-hidden")
            }, n.getSize = function() {
                this.size = e(this.element)
            }, n.setPosition = function(t) {
                this.x = t, this.updateTarget(), this.renderPosition(t)
            }, n.updateTarget = n.setDefaultTarget = function() {
                var t = "left" == this.parent.originSide ? "marginLeft" : "marginRight";
                this.target = this.x + this.size[t] + this.size.width * this.parent.cellAlign
            }, n.renderPosition = function(t) {
                var e = "left" === this.parent.originSide ? 1 : -1,
                    i = this.parent.options.percentPosition ? t * e * (this.parent.size.innerWidth / this.size.width) : t * e;
                this.element.style.transform = "translateX(" + this.parent.getPositionValue(i) + ")"
            }, n.select = function() {
                this.element.classList.add("is-selected"), this.element.removeAttribute("aria-hidden")
            }, n.unselect = function() {
                this.element.classList.remove("is-selected"), this.element.setAttribute("aria-hidden", "true")
            }, n.wrapShift = function(t) {
                this.shift = t, this.renderPosition(this.x + this.parent.slideableWidth * t)
            }, n.remove = function() {
                this.element.parentNode.removeChild(this.element)
            }, i
        }))
    }(L);
    var P = {
        exports: {}
    };
    ! function(t) {
        ! function(e, i) {
            t.exports ? t.exports = i() : (e.Flickity = e.Flickity || {}, e.Flickity.Slide = i())
        }(window, (function() {
            function t(t) {
                this.parent = t, this.isOriginLeft = "left" == t.originSide, this.cells = [], this.outerWidth = 0, this.height = 0
            }
            var e = t.prototype;
            return e.addCell = function(t) {
                if (this.cells.push(t), this.outerWidth += t.size.outerWidth, this.height = Math.max(t.size.outerHeight, this.height), 1 == this.cells.length) {
                    this.x = t.x;
                    var e = this.isOriginLeft ? "marginLeft" : "marginRight";
                    this.firstMargin = t.size[e]
                }
            }, e.updateTarget = function() {
                var t = this.isOriginLeft ? "marginRight" : "marginLeft",
                    e = this.getLastCell(),
                    i = e ? e.size[t] : 0,
                    n = this.outerWidth - (this.firstMargin + i);
                this.target = this.x + this.firstMargin + n * this.parent.cellAlign
            }, e.getLastCell = function() {
                return this.cells[this.cells.length - 1]
            }, e.select = function() {
                this.cells.forEach((function(t) {
                    t.select()
                }))
            }, e.unselect = function() {
                this.cells.forEach((function(t) {
                    t.unselect()
                }))
            }, e.getCellElements = function() {
                return this.cells.map((function(t) {
                    return t.element
                }))
            }, t
        }))
    }(P);
    var A = {
        exports: {}
    };
    ! function(t) {
        ! function(e, i) {
            t.exports ? t.exports = i(e, C.exports) : (e.Flickity = e.Flickity || {}, e.Flickity.animatePrototype = i(e, e.fizzyUIUtils))
        }(window, (function(t, e) {
            var i = {
                startAnimation: function() {
                    this.isAnimating || (this.isAnimating = !0, this.restingFrames = 0, this.animate())
                },
                animate: function() {
                    this.applyDragForce(), this.applySelectedAttraction();
                    var t = this.x;
                    if (this.integratePhysics(), this.positionSlider(), this.settle(t), this.isAnimating) {
                        var e = this;
                        requestAnimationFrame((function() {
                            e.animate()
                        }))
                    }
                },
                positionSlider: function() {
                    var t = this.x;
                    this.options.wrapAround && this.cells.length > 1 && (t = e.modulo(t, this.slideableWidth), t -= this.slideableWidth, this.shiftWrapCells(t)), this.setTranslateX(t, this.isAnimating), this.dispatchScrollEvent()
                },
                setTranslateX: function(t, e) {
                    t += this.cursorPosition, t = this.options.rightToLeft ? -t : t;
                    var i = this.getPositionValue(t);
                    this.slider.style.transform = e ? "translate3d(" + i + ",0,0)" : "translateX(" + i + ")"
                },
                dispatchScrollEvent: function() {
                    var t = this.slides[0];
                    if (t) {
                        var e = -this.x - t.target,
                            i = e / this.slidesWidth;
                        this.dispatchEvent("scroll", null, [i, e])
                    }
                },
                positionSliderAtSelected: function() {
                    this.cells.length && (this.x = -this.selectedSlide.target, this.velocity = 0, this.positionSlider())
                },
                getPositionValue: function(t) {
                    return this.options.percentPosition ? .01 * Math.round(t / this.size.innerWidth * 1e4) + "%" : Math.round(t) + "px"
                },
                settle: function(t) {
                    !this.isPointerDown && Math.round(100 * this.x) == Math.round(100 * t) && this.restingFrames++, this.restingFrames > 2 && (this.isAnimating = !1, delete this.isFreeScrolling, this.positionSlider(), this.dispatchEvent("settle", null, [this.selectedIndex]))
                },
                shiftWrapCells: function(t) {
                    var e = this.cursorPosition + t;
                    this._shiftCells(this.beforeShiftCells, e, -1);
                    var i = this.size.innerWidth - (t + this.slideableWidth + this.cursorPosition);
                    this._shiftCells(this.afterShiftCells, i, 1)
                },
                _shiftCells: function(t, e, i) {
                    for (var n = 0; n < t.length; n++) {
                        var s = t[n],
                            o = e > 0 ? i : 0;
                        s.wrapShift(o), e -= s.size.outerWidth
                    }
                },
                _unshiftCells: function(t) {
                    if (t && t.length)
                        for (var e = 0; e < t.length; e++) t[e].wrapShift(0)
                },
                integratePhysics: function() {
                    this.x += this.velocity, this.velocity *= this.getFrictionFactor()
                },
                applyForce: function(t) {
                    this.velocity += t
                },
                getFrictionFactor: function() {
                    return 1 - this.options[this.isFreeScrolling ? "freeScrollFriction" : "friction"]
                },
                getRestingPosition: function() {
                    return this.x + this.velocity / (1 - this.getFrictionFactor())
                },
                applyDragForce: function() {
                    if (this.isDraggable && this.isPointerDown) {
                        var t = this.dragX - this.x - this.velocity;
                        this.applyForce(t)
                    }
                },
                applySelectedAttraction: function() {
                    if (!(this.isDraggable && this.isPointerDown) && !this.isFreeScrolling && this.slides.length) {
                        var t = (-1 * this.selectedSlide.target - this.x) * this.options.selectedAttraction;
                        this.applyForce(t)
                    }
                }
            };
            return i
        }))
    }(A),
    function(t) {
        ! function(e, i) {
            if (t.exports) t.exports = i(e, E.exports, w.exports, C.exports, L.exports, P.exports, A.exports);
            else {
                var n = e.Flickity;
                e.Flickity = i(e, e.EvEmitter, e.getSize, e.fizzyUIUtils, n.Cell, n.Slide, n.animatePrototype)
            }
        }(window, (function(t, e, i, n, s, o, r) {
            var a = t.jQuery,
                l = t.getComputedStyle,
                c = t.console;

            function h(t, e) {
                for (t = n.makeArray(t); t.length;) e.appendChild(t.shift())
            }
            var d = 0,
                u = {};

            function p(t, e) {
                var i = n.getQueryElement(t);
                if (i) {
                    if (this.element = i, this.element.flickityGUID) {
                        var s = u[this.element.flickityGUID];
                        return s && s.option(e), s
                    }
                    a && (this.$element = a(this.element)), this.options = n.extend({}, this.constructor.defaults), this.option(e), this._create()
                } else c && c.error("Bad element for Flickity: " + (i || t))
            }
            p.defaults = {
                accessibility: !0,
                cellAlign: "center",
                freeScrollFriction: .075,
                friction: .28,
                namespaceJQueryEvents: !0,
                percentPosition: !0,
                resize: !0,
                selectedAttraction: .025,
                setGallerySize: !0
            }, p.createMethods = [];
            var f = p.prototype;
            n.extend(f, e.prototype), f._create = function() {
                var e = this.guid = ++d;
                for (var i in this.element.flickityGUID = e, u[e] = this, this.selectedIndex = 0, this.restingFrames = 0, this.x = 0, this.velocity = 0, this.originSide = this.options.rightToLeft ? "right" : "left", this.viewport = document.createElement("div"), this.viewport.className = "flickity-viewport", this._createSlider(), (this.options.resize || this.options.watchCSS) && t.addEventListener("resize", this), this.options.on) {
                    var n = this.options.on[i];
                    this.on(i, n)
                }
                p.createMethods.forEach((function(t) {
                    this[t]()
                }), this), this.options.watchCSS ? this.watchCSS() : this.activate()
            }, f.option = function(t) {
                n.extend(this.options, t)
            }, f.activate = function() {
                this.isActive || (this.isActive = !0, this.element.classList.add("flickity-enabled"), this.options.rightToLeft && this.element.classList.add("flickity-rtl"), this.getSize(), h(this._filterFindCellElements(this.element.children), this.slider), this.viewport.appendChild(this.slider), this.element.appendChild(this.viewport), this.reloadCells(), this.options.accessibility && (this.element.tabIndex = 0, this.element.addEventListener("keydown", this)), this.emitEvent("activate"), this.selectInitialIndex(), this.isInitActivated = !0, this.dispatchEvent("ready"))
            }, f._createSlider = function() {
                var t = document.createElement("div");
                t.className = "flickity-slider", t.style[this.originSide] = 0, this.slider = t
            }, f._filterFindCellElements = function(t) {
                return n.filterFindElements(t, this.options.cellSelector)
            }, f.reloadCells = function() {
                this.cells = this._makeCells(this.slider.children), this.positionCells(), this._getWrapShiftCells(), this.setGallerySize()
            }, f._makeCells = function(t) {
                return this._filterFindCellElements(t).map((function(t) {
                    return new s(t, this)
                }), this)
            }, f.getLastCell = function() {
                return this.cells[this.cells.length - 1]
            }, f.getLastSlide = function() {
                return this.slides[this.slides.length - 1]
            }, f.positionCells = function() {
                this._sizeCells(this.cells), this._positionCells(0)
            }, f._positionCells = function(t) {
                t = t || 0, this.maxCellHeight = t && this.maxCellHeight || 0;
                var e = 0;
                if (t > 0) {
                    var i = this.cells[t - 1];
                    e = i.x + i.size.outerWidth
                }
                for (var n = this.cells.length, s = t; s < n; s++) {
                    var o = this.cells[s];
                    o.setPosition(e), e += o.size.outerWidth, this.maxCellHeight = Math.max(o.size.outerHeight, this.maxCellHeight)
                }
                this.slideableWidth = e, this.updateSlides(), this._containSlides(), this.slidesWidth = n ? this.getLastSlide().target - this.slides[0].target : 0
            }, f._sizeCells = function(t) {
                t.forEach((function(t) {
                    t.getSize()
                }))
            }, f.updateSlides = function() {
                if (this.slides = [], this.cells.length) {
                    var t = new o(this);
                    this.slides.push(t);
                    var e = "left" == this.originSide ? "marginRight" : "marginLeft",
                        i = this._getCanCellFit();
                    this.cells.forEach((function(n, s) {
                        if (t.cells.length) {
                            var r = t.outerWidth - t.firstMargin + (n.size.outerWidth - n.size[e]);
                            i.call(this, s, r) || (t.updateTarget(), t = new o(this), this.slides.push(t)), t.addCell(n)
                        } else t.addCell(n)
                    }), this), t.updateTarget(), this.updateSelectedSlide()
                }
            }, f._getCanCellFit = function() {
                var t = this.options.groupCells;
                if (!t) return function() {
                    return !1
                };
                if ("number" == typeof t) {
                    var e = parseInt(t, 10);
                    return function(t) {
                        return t % e != 0
                    }
                }
                var i = "string" == typeof t && t.match(/^(\d+)%$/),
                    n = i ? parseInt(i[1], 10) / 100 : 1;
                return function(t, e) {
                    return e <= (this.size.innerWidth + 1) * n
                }
            }, f._init = f.reposition = function() {
                this.positionCells(), this.positionSliderAtSelected()
            }, f.getSize = function() {
                this.size = i(this.element), this.setCellAlign(), this.cursorPosition = this.size.innerWidth * this.cellAlign
            };
            var g = {
                center: {
                    left: .5,
                    right: .5
                },
                left: {
                    left: 0,
                    right: 1
                },
                right: {
                    right: 0,
                    left: 1
                }
            };
            return f.setCellAlign = function() {
                var t = g[this.options.cellAlign];
                this.cellAlign = t ? t[this.originSide] : this.options.cellAlign
            }, f.setGallerySize = function() {
                if (this.options.setGallerySize) {
                    var t = this.options.adaptiveHeight && this.selectedSlide ? this.selectedSlide.height : this.maxCellHeight;
                    this.viewport.style.height = t + "px"
                }
            }, f._getWrapShiftCells = function() {
                if (this.options.wrapAround) {
                    this._unshiftCells(this.beforeShiftCells), this._unshiftCells(this.afterShiftCells);
                    var t = this.cursorPosition,
                        e = this.cells.length - 1;
                    this.beforeShiftCells = this._getGapCells(t, e, -1), t = this.size.innerWidth - this.cursorPosition, this.afterShiftCells = this._getGapCells(t, 0, 1)
                }
            }, f._getGapCells = function(t, e, i) {
                for (var n = []; t > 0;) {
                    var s = this.cells[e];
                    if (!s) break;
                    n.push(s), e += i, t -= s.size.outerWidth
                }
                return n
            }, f._containSlides = function() {
                if (this.options.contain && !this.options.wrapAround && this.cells.length) {
                    var t = this.options.rightToLeft,
                        e = t ? "marginRight" : "marginLeft",
                        i = t ? "marginLeft" : "marginRight",
                        n = this.slideableWidth - this.getLastCell().size[i],
                        s = n < this.size.innerWidth,
                        o = this.cursorPosition + this.cells[0].size[e],
                        r = n - this.size.innerWidth * (1 - this.cellAlign);
                    this.slides.forEach((function(t) {
                        s ? t.target = n * this.cellAlign : (t.target = Math.max(t.target, o), t.target = Math.min(t.target, r))
                    }), this)
                }
            }, f.dispatchEvent = function(t, e, i) {
                var n = e ? [e].concat(i) : i;
                if (this.emitEvent(t, n), a && this.$element) {
                    var s = t += this.options.namespaceJQueryEvents ? ".flickity" : "";
                    if (e) {
                        var o = new a.Event(e);
                        o.type = t, s = o
                    }
                    this.$element.trigger(s, i)
                }
            }, f.select = function(t, e, i) {
                if (this.isActive && (t = parseInt(t, 10), this._wrapSelect(t), (this.options.wrapAround || e) && (t = n.modulo(t, this.slides.length)), this.slides[t])) {
                    var s = this.selectedIndex;
                    this.selectedIndex = t, this.updateSelectedSlide(), i ? this.positionSliderAtSelected() : this.startAnimation(), this.options.adaptiveHeight && this.setGallerySize(), this.dispatchEvent("select", null, [t]), t != s && this.dispatchEvent("change", null, [t]), this.dispatchEvent("cellSelect")
                }
            }, f._wrapSelect = function(t) {
                var e = this.slides.length;
                if (!(this.options.wrapAround && e > 1)) return t;
                var i = n.modulo(t, e),
                    s = Math.abs(i - this.selectedIndex),
                    o = Math.abs(i + e - this.selectedIndex),
                    r = Math.abs(i - e - this.selectedIndex);
                !this.isDragSelect && o < s ? t += e : !this.isDragSelect && r < s && (t -= e), t < 0 ? this.x -= this.slideableWidth : t >= e && (this.x += this.slideableWidth)
            }, f.previous = function(t, e) {
                this.select(this.selectedIndex - 1, t, e)
            }, f.next = function(t, e) {
                this.select(this.selectedIndex + 1, t, e)
            }, f.updateSelectedSlide = function() {
                var t = this.slides[this.selectedIndex];
                t && (this.unselectSelectedSlide(), this.selectedSlide = t, t.select(), this.selectedCells = t.cells, this.selectedElements = t.getCellElements(), this.selectedCell = t.cells[0], this.selectedElement = this.selectedElements[0])
            }, f.unselectSelectedSlide = function() {
                this.selectedSlide && this.selectedSlide.unselect()
            }, f.selectInitialIndex = function() {
                var t = this.options.initialIndex;
                if (this.isInitActivated) this.select(this.selectedIndex, !1, !0);
                else {
                    if (t && "string" == typeof t)
                        if (this.queryCell(t)) return void this.selectCell(t, !1, !0);
                    var e = 0;
                    t && this.slides[t] && (e = t), this.select(e, !1, !0)
                }
            }, f.selectCell = function(t, e, i) {
                var n = this.queryCell(t);
                if (n) {
                    var s = this.getCellSlideIndex(n);
                    this.select(s, e, i)
                }
            }, f.getCellSlideIndex = function(t) {
                for (var e = 0; e < this.slides.length; e++) {
                    if (-1 != this.slides[e].cells.indexOf(t)) return e
                }
            }, f.getCell = function(t) {
                for (var e = 0; e < this.cells.length; e++) {
                    var i = this.cells[e];
                    if (i.element == t) return i
                }
            }, f.getCells = function(t) {
                t = n.makeArray(t);
                var e = [];
                return t.forEach((function(t) {
                    var i = this.getCell(t);
                    i && e.push(i)
                }), this), e
            }, f.getCellElements = function() {
                return this.cells.map((function(t) {
                    return t.element
                }))
            }, f.getParentCell = function(t) {
                var e = this.getCell(t);
                return e || (t = n.getParent(t, ".flickity-slider > *"), this.getCell(t))
            }, f.getAdjacentCellElements = function(t, e) {
                if (!t) return this.selectedSlide.getCellElements();
                e = void 0 === e ? this.selectedIndex : e;
                var i = this.slides.length;
                if (1 + 2 * t >= i) return this.getCellElements();
                for (var s = [], o = e - t; o <= e + t; o++) {
                    var r = this.options.wrapAround ? n.modulo(o, i) : o,
                        a = this.slides[r];
                    a && (s = s.concat(a.getCellElements()))
                }
                return s
            }, f.queryCell = function(t) {
                if ("number" == typeof t) return this.cells[t];
                if ("string" == typeof t) {
                    if (t.match(/^[#.]?[\d/]/)) return;
                    t = this.element.querySelector(t)
                }
                return this.getCell(t)
            }, f.uiChange = function() {
                this.emitEvent("uiChange")
            }, f.childUIPointerDown = function(t) {
                "touchstart" != t.type && t.preventDefault(), this.focus()
            }, f.onresize = function() {
                this.watchCSS(), this.resize()
            }, n.debounceMethod(p, "onresize", 150), f.resize = function() {
                if (this.isActive && !this.isAnimating && !this.isDragging) {
                    this.getSize(), this.options.wrapAround && (this.x = n.modulo(this.x, this.slideableWidth)), this.positionCells(), this._getWrapShiftCells(), this.setGallerySize(), this.emitEvent("resize");
                    var t = this.selectedElements && this.selectedElements[0];
                    this.selectCell(t, !1, !0)
                }
            }, f.watchCSS = function() {
                this.options.watchCSS && (-1 != l(this.element, ":after").content.indexOf("flickity") ? this.activate() : this.deactivate())
            }, f.onkeydown = function(t) {
                var e = document.activeElement && document.activeElement != this.element;
                if (this.options.accessibility && !e) {
                    var i = p.keyboardHandlers[t.keyCode];
                    i && i.call(this)
                }
            }, p.keyboardHandlers = {
                37: function() {
                    var t = this.options.rightToLeft ? "next" : "previous";
                    this.uiChange(), this[t]()
                },
                39: function() {
                    var t = this.options.rightToLeft ? "previous" : "next";
                    this.uiChange(), this[t]()
                }
            }, f.focus = function() {
                var e = t.pageYOffset;
                this.element.focus({
                    preventScroll: !0
                }), t.pageYOffset != e && t.scrollTo(t.pageXOffset, e)
            }, f.deactivate = function() {
                this.isActive && (this.element.classList.remove("flickity-enabled"), this.element.classList.remove("flickity-rtl"), this.unselectSelectedSlide(), this.cells.forEach((function(t) {
                    t.destroy()
                })), this.element.removeChild(this.viewport), h(this.slider.children, this.element), this.options.accessibility && (this.element.removeAttribute("tabIndex"), this.element.removeEventListener("keydown", this)), this.isActive = !1, this.emitEvent("deactivate"))
            }, f.destroy = function() {
                this.deactivate(), t.removeEventListener("resize", this), this.allOff(), this.emitEvent("destroy"), a && this.$element && a.removeData(this.element, "flickity"), delete this.element.flickityGUID, delete u[this.guid]
            }, n.extend(f, r), p.data = function(t) {
                var e = (t = n.getQueryElement(t)) && t.flickityGUID;
                return e && u[e]
            }, n.htmlInit(p, "flickity"), a && a.bridget && a.bridget("flickity", p), p.setJQuery = function(t) {
                a = t
            }, p.Cell = s, p.Slide = o, p
        }))
    }(x);
    var D = {
            exports: {}
        },
        _ = {
            exports: {}
        },
        I = {
            exports: {}
        };
    /*!
     * Unipointer v2.4.0
     * base class for doing one thing with pointer event
     * MIT license
     */
    ! function(t) {
        ! function(e, i) {
            t.exports ? t.exports = i(e, E.exports) : e.Unipointer = i(e, e.EvEmitter)
        }(window, (function(t, e) {
            function i() {}
            var n = i.prototype = Object.create(e.prototype);
            n.bindStartEvent = function(t) {
                this._bindStartEvent(t, !0)
            }, n.unbindStartEvent = function(t) {
                this._bindStartEvent(t, !1)
            }, n._bindStartEvent = function(e, i) {
                var n = (i = void 0 === i || i) ? "addEventListener" : "removeEventListener",
                    s = "mousedown";
                "ontouchstart" in t ? s = "touchstart" : t.PointerEvent && (s = "pointerdown"), e[n](s, this)
            }, n.handleEvent = function(t) {
                var e = "on" + t.type;
                this[e] && this[e](t)
            }, n.getTouch = function(t) {
                for (var e = 0; e < t.length; e++) {
                    var i = t[e];
                    if (i.identifier == this.pointerIdentifier) return i
                }
            }, n.onmousedown = function(t) {
                var e = t.button;
                e && 0 !== e && 1 !== e || this._pointerDown(t, t)
            }, n.ontouchstart = function(t) {
                this._pointerDown(t, t.changedTouches[0])
            }, n.onpointerdown = function(t) {
                this._pointerDown(t, t)
            }, n._pointerDown = function(t, e) {
                t.button || this.isPointerDown || (this.isPointerDown = !0, this.pointerIdentifier = void 0 !== e.pointerId ? e.pointerId : e.identifier, this.pointerDown(t, e))
            }, n.pointerDown = function(t, e) {
                this._bindPostStartEvents(t), this.emitEvent("pointerDown", [t, e])
            };
            var s = {
                mousedown: ["mousemove", "mouseup"],
                touchstart: ["touchmove", "touchend", "touchcancel"],
                pointerdown: ["pointermove", "pointerup", "pointercancel"]
            };
            return n._bindPostStartEvents = function(e) {
                if (e) {
                    var i = s[e.type];
                    i.forEach((function(e) {
                        t.addEventListener(e, this)
                    }), this), this._boundPointerEvents = i
                }
            }, n._unbindPostStartEvents = function() {
                this._boundPointerEvents && (this._boundPointerEvents.forEach((function(e) {
                    t.removeEventListener(e, this)
                }), this), delete this._boundPointerEvents)
            }, n.onmousemove = function(t) {
                this._pointerMove(t, t)
            }, n.onpointermove = function(t) {
                t.pointerId == this.pointerIdentifier && this._pointerMove(t, t)
            }, n.ontouchmove = function(t) {
                var e = this.getTouch(t.changedTouches);
                e && this._pointerMove(t, e)
            }, n._pointerMove = function(t, e) {
                this.pointerMove(t, e)
            }, n.pointerMove = function(t, e) {
                this.emitEvent("pointerMove", [t, e])
            }, n.onmouseup = function(t) {
                this._pointerUp(t, t)
            }, n.onpointerup = function(t) {
                t.pointerId == this.pointerIdentifier && this._pointerUp(t, t)
            }, n.ontouchend = function(t) {
                var e = this.getTouch(t.changedTouches);
                e && this._pointerUp(t, e)
            }, n._pointerUp = function(t, e) {
                this._pointerDone(), this.pointerUp(t, e)
            }, n.pointerUp = function(t, e) {
                this.emitEvent("pointerUp", [t, e])
            }, n._pointerDone = function() {
                this._pointerReset(), this._unbindPostStartEvents(), this.pointerDone()
            }, n._pointerReset = function() {
                this.isPointerDown = !1, delete this.pointerIdentifier
            }, n.pointerDone = function() {}, n.onpointercancel = function(t) {
                t.pointerId == this.pointerIdentifier && this._pointerCancel(t, t)
            }, n.ontouchcancel = function(t) {
                var e = this.getTouch(t.changedTouches);
                e && this._pointerCancel(t, e)
            }, n._pointerCancel = function(t, e) {
                this._pointerDone(), this.pointerCancel(t, e)
            }, n.pointerCancel = function(t, e) {
                this.emitEvent("pointerCancel", [t, e])
            }, i.getPointerPoint = function(t) {
                return {
                    x: t.pageX,
                    y: t.pageY
                }
            }, i
        }))
    }(I),
    /*!
     * Unidragger v2.4.0
     * Draggable base class
     * MIT license
     */
    function(t) {
        ! function(e, i) {
            t.exports ? t.exports = i(e, I.exports) : e.Unidragger = i(e, e.Unipointer)
        }(window, (function(t, e) {
            function i() {}
            var n = i.prototype = Object.create(e.prototype);
            n.bindHandles = function() {
                this._bindHandles(!0)
            }, n.unbindHandles = function() {
                this._bindHandles(!1)
            }, n._bindHandles = function(e) {
                for (var i = (e = void 0 === e || e) ? "addEventListener" : "removeEventListener", n = e ? this._touchActionValue : "", s = 0; s < this.handles.length; s++) {
                    var o = this.handles[s];
                    this._bindStartEvent(o, e), o[i]("click", this), t.PointerEvent && (o.style.touchAction = n)
                }
            }, n._touchActionValue = "none", n.pointerDown = function(t, e) {
                this.okayPointerDown(t) && (this.pointerDownPointer = {
                    pageX: e.pageX,
                    pageY: e.pageY
                }, t.preventDefault(), this.pointerDownBlur(), this._bindPostStartEvents(t), this.emitEvent("pointerDown", [t, e]))
            };
            var s = {
                    TEXTAREA: !0,
                    INPUT: !0,
                    SELECT: !0,
                    OPTION: !0
                },
                o = {
                    radio: !0,
                    checkbox: !0,
                    button: !0,
                    submit: !0,
                    image: !0,
                    file: !0
                };
            return n.okayPointerDown = function(t) {
                var e = s[t.target.nodeName],
                    i = o[t.target.type],
                    n = !e || i;
                return n || this._pointerReset(), n
            }, n.pointerDownBlur = function() {
                var t = document.activeElement;
                t && t.blur && t != document.body && t.blur()
            }, n.pointerMove = function(t, e) {
                var i = this._dragPointerMove(t, e);
                this.emitEvent("pointerMove", [t, e, i]), this._dragMove(t, e, i)
            }, n._dragPointerMove = function(t, e) {
                var i = {
                    x: e.pageX - this.pointerDownPointer.pageX,
                    y: e.pageY - this.pointerDownPointer.pageY
                };
                return !this.isDragging && this.hasDragStarted(i) && this._dragStart(t, e), i
            }, n.hasDragStarted = function(t) {
                return Math.abs(t.x) > 3 || Math.abs(t.y) > 3
            }, n.pointerUp = function(t, e) {
                this.emitEvent("pointerUp", [t, e]), this._dragPointerUp(t, e)
            }, n._dragPointerUp = function(t, e) {
                this.isDragging ? this._dragEnd(t, e) : this._staticClick(t, e)
            }, n._dragStart = function(t, e) {
                this.isDragging = !0, this.isPreventingClicks = !0, this.dragStart(t, e)
            }, n.dragStart = function(t, e) {
                this.emitEvent("dragStart", [t, e])
            }, n._dragMove = function(t, e, i) {
                this.isDragging && this.dragMove(t, e, i)
            }, n.dragMove = function(t, e, i) {
                t.preventDefault(), this.emitEvent("dragMove", [t, e, i])
            }, n._dragEnd = function(t, e) {
                this.isDragging = !1, setTimeout(function() {
                    delete this.isPreventingClicks
                }.bind(this)), this.dragEnd(t, e)
            }, n.dragEnd = function(t, e) {
                this.emitEvent("dragEnd", [t, e])
            }, n.onclick = function(t) {
                this.isPreventingClicks && t.preventDefault()
            }, n._staticClick = function(t, e) {
                this.isIgnoringMouseUp && "mouseup" == t.type || (this.staticClick(t, e), "mouseup" != t.type && (this.isIgnoringMouseUp = !0, setTimeout(function() {
                    delete this.isIgnoringMouseUp
                }.bind(this), 400)))
            }, n.staticClick = function(t, e) {
                this.emitEvent("staticClick", [t, e])
            }, i.getPointerPoint = e.getPointerPoint, i
        }))
    }(_),
    function(t) {
        ! function(e, i) {
            t.exports ? t.exports = i(e, x.exports, _.exports, C.exports) : e.Flickity = i(e, e.Flickity, e.Unidragger, e.fizzyUIUtils)
        }(window, (function(t, e, i, n) {
            n.extend(e.defaults, {
                draggable: ">1",
                dragThreshold: 3
            }), e.createMethods.push("_createDrag");
            var s = e.prototype;
            n.extend(s, i.prototype), s._touchActionValue = "pan-y", s._createDrag = function() {
                this.on("activate", this.onActivateDrag), this.on("uiChange", this._uiChangeDrag), this.on("deactivate", this.onDeactivateDrag), this.on("cellChange", this.updateDraggable)
            }, s.onActivateDrag = function() {
                this.handles = [this.viewport], this.bindHandles(), this.updateDraggable()
            }, s.onDeactivateDrag = function() {
                this.unbindHandles(), this.element.classList.remove("is-draggable")
            }, s.updateDraggable = function() {
                ">1" == this.options.draggable ? this.isDraggable = this.slides.length > 1 : this.isDraggable = this.options.draggable, this.isDraggable ? this.element.classList.add("is-draggable") : this.element.classList.remove("is-draggable")
            }, s.bindDrag = function() {
                this.options.draggable = !0, this.updateDraggable()
            }, s.unbindDrag = function() {
                this.options.draggable = !1, this.updateDraggable()
            }, s._uiChangeDrag = function() {
                delete this.isFreeScrolling
            }, s.pointerDown = function(e, i) {
                this.isDraggable ? this.okayPointerDown(e) && (this._pointerDownPreventDefault(e), this.pointerDownFocus(e), document.activeElement != this.element && this.pointerDownBlur(), this.dragX = this.x, this.viewport.classList.add("is-pointer-down"), this.pointerDownScroll = r(), t.addEventListener("scroll", this), this._pointerDownDefault(e, i)) : this._pointerDownDefault(e, i)
            }, s._pointerDownDefault = function(t, e) {
                this.pointerDownPointer = {
                    pageX: e.pageX,
                    pageY: e.pageY
                }, this._bindPostStartEvents(t), this.dispatchEvent("pointerDown", t, [e])
            };
            var o = {
                INPUT: !0,
                TEXTAREA: !0,
                SELECT: !0
            };

            function r() {
                return {
                    x: t.pageXOffset,
                    y: t.pageYOffset
                }
            }
            return s.pointerDownFocus = function(t) {
                o[t.target.nodeName] || this.focus()
            }, s._pointerDownPreventDefault = function(t) {
                var e = "touchstart" == t.type,
                    i = "touch" == t.pointerType,
                    n = o[t.target.nodeName];
                e || i || n || t.preventDefault()
            }, s.hasDragStarted = function(t) {
                return Math.abs(t.x) > this.options.dragThreshold
            }, s.pointerUp = function(t, e) {
                delete this.isTouchScrolling, this.viewport.classList.remove("is-pointer-down"), this.dispatchEvent("pointerUp", t, [e]), this._dragPointerUp(t, e)
            }, s.pointerDone = function() {
                t.removeEventListener("scroll", this), delete this.pointerDownScroll
            }, s.dragStart = function(e, i) {
                this.isDraggable && (this.dragStartPosition = this.x, this.startAnimation(), t.removeEventListener("scroll", this), this.dispatchEvent("dragStart", e, [i]))
            }, s.pointerMove = function(t, e) {
                var i = this._dragPointerMove(t, e);
                this.dispatchEvent("pointerMove", t, [e, i]), this._dragMove(t, e, i)
            }, s.dragMove = function(t, e, i) {
                if (this.isDraggable) {
                    t.preventDefault(), this.previousDragX = this.dragX;
                    var n = this.options.rightToLeft ? -1 : 1;
                    this.options.wrapAround && (i.x %= this.slideableWidth);
                    var s = this.dragStartPosition + i.x * n;
                    if (!this.options.wrapAround && this.slides.length) {
                        var o = Math.max(-this.slides[0].target, this.dragStartPosition);
                        s = s > o ? .5 * (s + o) : s;
                        var r = Math.min(-this.getLastSlide().target, this.dragStartPosition);
                        s = s < r ? .5 * (s + r) : s
                    }
                    this.dragX = s, this.dragMoveTime = new Date, this.dispatchEvent("dragMove", t, [e, i])
                }
            }, s.dragEnd = function(t, e) {
                if (this.isDraggable) {
                    this.options.freeScroll && (this.isFreeScrolling = !0);
                    var i = this.dragEndRestingSelect();
                    if (this.options.freeScroll && !this.options.wrapAround) {
                        var n = this.getRestingPosition();
                        this.isFreeScrolling = -n > this.slides[0].target && -n < this.getLastSlide().target
                    } else this.options.freeScroll || i != this.selectedIndex || (i += this.dragEndBoostSelect());
                    delete this.previousDragX, this.isDragSelect = this.options.wrapAround, this.select(i), delete this.isDragSelect, this.dispatchEvent("dragEnd", t, [e])
                }
            }, s.dragEndRestingSelect = function() {
                var t = this.getRestingPosition(),
                    e = Math.abs(this.getSlideDistance(-t, this.selectedIndex)),
                    i = this._getClosestResting(t, e, 1),
                    n = this._getClosestResting(t, e, -1);
                return i.distance < n.distance ? i.index : n.index
            }, s._getClosestResting = function(t, e, i) {
                for (var n = this.selectedIndex, s = 1 / 0, o = this.options.contain && !this.options.wrapAround ? function(t, e) {
                        return t <= e
                    } : function(t, e) {
                        return t < e
                    }; o(e, s) && (n += i, s = e, null !== (e = this.getSlideDistance(-t, n)));) e = Math.abs(e);
                return {
                    distance: s,
                    index: n - i
                }
            }, s.getSlideDistance = function(t, e) {
                var i = this.slides.length,
                    s = this.options.wrapAround && i > 1,
                    o = s ? n.modulo(e, i) : e,
                    r = this.slides[o];
                if (!r) return null;
                var a = s ? this.slideableWidth * Math.floor(e / i) : 0;
                return t - (r.target + a)
            }, s.dragEndBoostSelect = function() {
                if (void 0 === this.previousDragX || !this.dragMoveTime || new Date - this.dragMoveTime > 100) return 0;
                var t = this.getSlideDistance(-this.dragX, this.selectedIndex),
                    e = this.previousDragX - this.dragX;
                return t > 0 && e > 0 ? 1 : t < 0 && e < 0 ? -1 : 0
            }, s.staticClick = function(t, e) {
                var i = this.getParentCell(t.target),
                    n = i && i.element,
                    s = i && this.cells.indexOf(i);
                this.dispatchEvent("staticClick", t, [e, n, s])
            }, s.onscroll = function() {
                var t = r(),
                    e = this.pointerDownScroll.x - t.x,
                    i = this.pointerDownScroll.y - t.y;
                (Math.abs(e) > 3 || Math.abs(i) > 3) && this._pointerDone()
            }, e
        }))
    }(D);
    var z = {
        exports: {}
    };
    ! function(t) {
        ! function(e, i) {
            t.exports ? t.exports = i(e, x.exports, I.exports, C.exports) : i(e, e.Flickity, e.Unipointer, e.fizzyUIUtils)
        }(window, (function(t, e, i, n) {
            var s = "http://www.w3.org/2000/svg";

            function o(t, e) {
                this.direction = t, this.parent = e, this._create()
            }
            o.prototype = Object.create(i.prototype), o.prototype._create = function() {
                this.isEnabled = !0, this.isPrevious = -1 == this.direction;
                var t = this.parent.options.rightToLeft ? 1 : -1;
                this.isLeft = this.direction == t;
                var e = this.element = document.createElement("button");
                e.className = "flickity-button flickity-prev-next-button", e.className += this.isPrevious ? " previous" : " next", e.setAttribute("type", "button"), this.disable(), e.setAttribute("aria-label", this.isPrevious ? "Previous" : "Next");
                var i = this.createSVG();
                e.appendChild(i), this.parent.on("select", this.update.bind(this)), this.on("pointerDown", this.parent.childUIPointerDown.bind(this.parent))
            }, o.prototype.activate = function() {
                this.bindStartEvent(this.element), this.element.addEventListener("click", this), this.parent.element.appendChild(this.element)
            }, o.prototype.deactivate = function() {
                this.parent.element.removeChild(this.element), this.unbindStartEvent(this.element), this.element.removeEventListener("click", this)
            }, o.prototype.createSVG = function() {
                var t = document.createElementNS(s, "svg");
                t.setAttribute("class", "flickity-button-icon"), t.setAttribute("viewBox", "0 0 100 100");
                var e = document.createElementNS(s, "path"),
                    i = function(t) {
                        if ("string" == typeof t) return t;
                        return "M " + t.x0 + ",50 L " + t.x1 + "," + (t.y1 + 50) + " L " + t.x2 + "," + (t.y2 + 50) + " L " + t.x3 + ",50  L " + t.x2 + "," + (50 - t.y2) + " L " + t.x1 + "," + (50 - t.y1) + " Z"
                    }(this.parent.options.arrowShape);
                return e.setAttribute("d", i), e.setAttribute("class", "arrow"), this.isLeft || e.setAttribute("transform", "translate(100, 100) rotate(180) "), t.appendChild(e), t
            }, o.prototype.handleEvent = n.handleEvent, o.prototype.onclick = function() {
                if (this.isEnabled) {
                    this.parent.uiChange();
                    var t = this.isPrevious ? "previous" : "next";
                    this.parent[t]()
                }
            }, o.prototype.enable = function() {
                this.isEnabled || (this.element.disabled = !1, this.isEnabled = !0)
            }, o.prototype.disable = function() {
                this.isEnabled && (this.element.disabled = !0, this.isEnabled = !1)
            }, o.prototype.update = function() {
                var t = this.parent.slides;
                if (this.parent.options.wrapAround && t.length > 1) this.enable();
                else {
                    var e = t.length ? t.length - 1 : 0,
                        i = this.isPrevious ? 0 : e;
                    this[this.parent.selectedIndex == i ? "disable" : "enable"]()
                }
            }, o.prototype.destroy = function() {
                this.deactivate(), this.allOff()
            }, n.extend(e.defaults, {
                prevNextButtons: !0,
                arrowShape: {
                    x0: 10,
                    x1: 60,
                    y1: 50,
                    x2: 70,
                    y2: 40,
                    x3: 30
                }
            }), e.createMethods.push("_createPrevNextButtons");
            var r = e.prototype;
            return r._createPrevNextButtons = function() {
                this.options.prevNextButtons && (this.prevButton = new o(-1, this), this.nextButton = new o(1, this), this.on("activate", this.activatePrevNextButtons))
            }, r.activatePrevNextButtons = function() {
                this.prevButton.activate(), this.nextButton.activate(), this.on("deactivate", this.deactivatePrevNextButtons)
            }, r.deactivatePrevNextButtons = function() {
                this.prevButton.deactivate(), this.nextButton.deactivate(), this.off("deactivate", this.deactivatePrevNextButtons)
            }, e.PrevNextButton = o, e
        }))
    }(z);
    var T = {
        exports: {}
    };
    ! function(t) {
        ! function(e, i) {
            t.exports ? t.exports = i(e, x.exports, I.exports, C.exports) : i(e, e.Flickity, e.Unipointer, e.fizzyUIUtils)
        }(window, (function(t, e, i, n) {
            function s(t) {
                this.parent = t, this._create()
            }
            s.prototype = Object.create(i.prototype), s.prototype._create = function() {
                this.holder = document.createElement("ol"), this.holder.className = "flickity-page-dots", this.dots = [], this.handleClick = this.onClick.bind(this), this.on("pointerDown", this.parent.childUIPointerDown.bind(this.parent))
            }, s.prototype.activate = function() {
                this.setDots(), this.holder.addEventListener("click", this.handleClick), this.bindStartEvent(this.holder), this.parent.element.appendChild(this.holder)
            }, s.prototype.deactivate = function() {
                this.holder.removeEventListener("click", this.handleClick), this.unbindStartEvent(this.holder), this.parent.element.removeChild(this.holder)
            }, s.prototype.setDots = function() {
                var t = this.parent.slides.length - this.dots.length;
                t > 0 ? this.addDots(t) : t < 0 && this.removeDots(-t)
            }, s.prototype.addDots = function(t) {
                for (var e = document.createDocumentFragment(), i = [], n = this.dots.length, s = n + t, o = n; o < s; o++) {
                    var r = document.createElement("li");
                    r.className = "dot", r.setAttribute("aria-label", "Page dot " + (o + 1)), e.appendChild(r), i.push(r)
                }
                this.holder.appendChild(e), this.dots = this.dots.concat(i)
            }, s.prototype.removeDots = function(t) {
                this.dots.splice(this.dots.length - t, t).forEach((function(t) {
                    this.holder.removeChild(t)
                }), this)
            }, s.prototype.updateSelected = function() {
                this.selectedDot && (this.selectedDot.className = "dot", this.selectedDot.removeAttribute("aria-current")), this.dots.length && (this.selectedDot = this.dots[this.parent.selectedIndex], this.selectedDot.className = "dot is-selected", this.selectedDot.setAttribute("aria-current", "step"))
            }, s.prototype.onTap = s.prototype.onClick = function(t) {
                var e = t.target;
                if ("LI" == e.nodeName) {
                    this.parent.uiChange();
                    var i = this.dots.indexOf(e);
                    this.parent.select(i)
                }
            }, s.prototype.destroy = function() {
                this.deactivate(), this.allOff()
            }, e.PageDots = s, n.extend(e.defaults, {
                pageDots: !0
            }), e.createMethods.push("_createPageDots");
            var o = e.prototype;
            return o._createPageDots = function() {
                this.options.pageDots && (this.pageDots = new s(this), this.on("activate", this.activatePageDots), this.on("select", this.updateSelectedPageDots), this.on("cellChange", this.updatePageDots), this.on("resize", this.updatePageDots), this.on("deactivate", this.deactivatePageDots))
            }, o.activatePageDots = function() {
                this.pageDots.activate()
            }, o.updateSelectedPageDots = function() {
                this.pageDots.updateSelected()
            }, o.updatePageDots = function() {
                this.pageDots.setDots()
            }, o.deactivatePageDots = function() {
                this.pageDots.deactivate()
            }, e.PageDots = s, e
        }))
    }(T);
    var M = {
        exports: {}
    };
    ! function(t) {
        ! function(e, i) {
            t.exports ? t.exports = i(E.exports, C.exports, x.exports) : i(e.EvEmitter, e.fizzyUIUtils, e.Flickity)
        }(window, (function(t, e, i) {
            function n(t) {
                this.parent = t, this.state = "stopped", this.onVisibilityChange = this.visibilityChange.bind(this), this.onVisibilityPlay = this.visibilityPlay.bind(this)
            }
            n.prototype = Object.create(t.prototype), n.prototype.play = function() {
                "playing" != this.state && (document.hidden ? document.addEventListener("visibilitychange", this.onVisibilityPlay) : (this.state = "playing", document.addEventListener("visibilitychange", this.onVisibilityChange), this.tick()))
            }, n.prototype.tick = function() {
                if ("playing" == this.state) {
                    var t = this.parent.options.autoPlay;
                    t = "number" == typeof t ? t : 3e3;
                    var e = this;
                    this.clear(), this.timeout = setTimeout((function() {
                        e.parent.next(!0), e.tick()
                    }), t)
                }
            }, n.prototype.stop = function() {
                this.state = "stopped", this.clear(), document.removeEventListener("visibilitychange", this.onVisibilityChange)
            }, n.prototype.clear = function() {
                clearTimeout(this.timeout)
            }, n.prototype.pause = function() {
                "playing" == this.state && (this.state = "paused", this.clear())
            }, n.prototype.unpause = function() {
                "paused" == this.state && this.play()
            }, n.prototype.visibilityChange = function() {
                this[document.hidden ? "pause" : "unpause"]()
            }, n.prototype.visibilityPlay = function() {
                this.play(), document.removeEventListener("visibilitychange", this.onVisibilityPlay)
            }, e.extend(i.defaults, {
                pauseAutoPlayOnHover: !0
            }), i.createMethods.push("_createPlayer");
            var s = i.prototype;
            return s._createPlayer = function() {
                this.player = new n(this), this.on("activate", this.activatePlayer), this.on("uiChange", this.stopPlayer), this.on("pointerDown", this.stopPlayer), this.on("deactivate", this.deactivatePlayer)
            }, s.activatePlayer = function() {
                this.options.autoPlay && (this.player.play(), this.element.addEventListener("mouseenter", this))
            }, s.playPlayer = function() {
                this.player.play()
            }, s.stopPlayer = function() {
                this.player.stop()
            }, s.pausePlayer = function() {
                this.player.pause()
            }, s.unpausePlayer = function() {
                this.player.unpause()
            }, s.deactivatePlayer = function() {
                this.player.stop(), this.element.removeEventListener("mouseenter", this)
            }, s.onmouseenter = function() {
                this.options.pauseAutoPlayOnHover && (this.player.pause(), this.element.addEventListener("mouseleave", this))
            }, s.onmouseleave = function() {
                this.player.unpause(), this.element.removeEventListener("mouseleave", this)
            }, i.Player = n, i
        }))
    }(M);
    var F = {
        exports: {}
    };
    ! function(t) {
        ! function(e, i) {
            t.exports ? t.exports = i(e, x.exports, C.exports) : i(e, e.Flickity, e.fizzyUIUtils)
        }(window, (function(t, e, i) {
            var n = e.prototype;
            return n.insert = function(t, e) {
                var i = this._makeCells(t);
                if (i && i.length) {
                    var n = this.cells.length;
                    e = void 0 === e ? n : e;
                    var s = function(t) {
                            var e = document.createDocumentFragment();
                            return t.forEach((function(t) {
                                e.appendChild(t.element)
                            })), e
                        }(i),
                        o = e == n;
                    if (o) this.slider.appendChild(s);
                    else {
                        var r = this.cells[e].element;
                        this.slider.insertBefore(s, r)
                    }
                    if (0 === e) this.cells = i.concat(this.cells);
                    else if (o) this.cells = this.cells.concat(i);
                    else {
                        var a = this.cells.splice(e, n - e);
                        this.cells = this.cells.concat(i).concat(a)
                    }
                    this._sizeCells(i), this.cellChange(e, !0)
                }
            }, n.append = function(t) {
                this.insert(t, this.cells.length)
            }, n.prepend = function(t) {
                this.insert(t, 0)
            }, n.remove = function(t) {
                var e = this.getCells(t);
                if (e && e.length) {
                    var n = this.cells.length - 1;
                    e.forEach((function(t) {
                        t.remove();
                        var e = this.cells.indexOf(t);
                        n = Math.min(e, n), i.removeFrom(this.cells, t)
                    }), this), this.cellChange(n, !0)
                }
            }, n.cellSizeChange = function(t) {
                var e = this.getCell(t);
                if (e) {
                    e.getSize();
                    var i = this.cells.indexOf(e);
                    this.cellChange(i)
                }
            }, n.cellChange = function(t, e) {
                var i = this.selectedElement;
                this._positionCells(t), this._getWrapShiftCells(), this.setGallerySize();
                var n = this.getCell(i);
                n && (this.selectedIndex = this.getCellSlideIndex(n)), this.selectedIndex = Math.min(this.slides.length - 1, this.selectedIndex), this.emitEvent("cellChange", [t]), this.select(this.selectedIndex), e && this.positionSliderAtSelected()
            }, e
        }))
    }(F);
    var O = {
        exports: {}
    };
    ! function(t) {
        ! function(e, i) {
            t.exports ? t.exports = i(e, x.exports, C.exports) : i(e, e.Flickity, e.fizzyUIUtils)
        }(window, (function(t, e, i) {
            e.createMethods.push("_createLazyload");
            var n = e.prototype;

            function s(t, e) {
                this.img = t, this.flickity = e, this.load()
            }
            return n._createLazyload = function() {
                this.on("select", this.lazyLoad)
            }, n.lazyLoad = function() {
                var t = this.options.lazyLoad;
                if (t) {
                    var e = "number" == typeof t ? t : 0,
                        n = this.getAdjacentCellElements(e),
                        o = [];
                    n.forEach((function(t) {
                        var e = function(t) {
                            if ("IMG" == t.nodeName) {
                                var e = t.getAttribute("data-flickity-lazyload"),
                                    n = t.getAttribute("data-flickity-lazyload-src"),
                                    s = t.getAttribute("data-flickity-lazyload-srcset");
                                if (e || n || s) return [t]
                            }
                            var o = "img[data-flickity-lazyload], img[data-flickity-lazyload-src], img[data-flickity-lazyload-srcset]",
                                r = t.querySelectorAll(o);
                            return i.makeArray(r)
                        }(t);
                        o = o.concat(e)
                    })), o.forEach((function(t) {
                        new s(t, this)
                    }), this)
                }
            }, s.prototype.handleEvent = i.handleEvent, s.prototype.load = function() {
                this.img.addEventListener("load", this), this.img.addEventListener("error", this);
                var t = this.img.getAttribute("data-flickity-lazyload") || this.img.getAttribute("data-flickity-lazyload-src"),
                    e = this.img.getAttribute("data-flickity-lazyload-srcset");
                this.img.src = t, e && this.img.setAttribute("srcset", e), this.img.removeAttribute("data-flickity-lazyload"), this.img.removeAttribute("data-flickity-lazyload-src"), this.img.removeAttribute("data-flickity-lazyload-srcset")
            }, s.prototype.onload = function(t) {
                this.complete(t, "flickity-lazyloaded")
            }, s.prototype.onerror = function(t) {
                this.complete(t, "flickity-lazyerror")
            }, s.prototype.complete = function(t, e) {
                this.img.removeEventListener("load", this), this.img.removeEventListener("error", this);
                var i = this.flickity.getParentCell(this.img),
                    n = i && i.element;
                this.flickity.cellSizeChange(n), this.img.classList.add(e), this.flickity.dispatchEvent("lazyLoad", t, n)
            }, e.LazyLoader = s, e
        }))
    }(O),
    /*!
     * Flickity v2.3.0
     * Touch, responsive, flickable carousels
     *
     * Licensed GPLv3 for open source use
     * or Flickity Commercial License for commercial use
     *
     * https://flickity.metafizzy.co
     * Copyright 2015-2021 Metafizzy
     */
    function(t) {
        window,
        t.exports && (t.exports = x.exports)
    }(S);
    var W = S.exports,
        N = {
            exports: {}
        };
    /*!
     * imagesLoaded v4.1.4
     * JavaScript is all like "You images are done yet or what?"
     * MIT License
     */
    ! function(t) {
        ! function(e, i) {
            t.exports ? t.exports = i(e, E.exports) : e.imagesLoaded = i(e, e.EvEmitter)
        }("undefined" != typeof window ? window : m, (function(t, e) {
            var i = t.jQuery,
                n = t.console;

            function s(t, e) {
                for (var i in e) t[i] = e[i];
                return t
            }
            var o = Array.prototype.slice;

            function r(t, e, a) {
                if (!(this instanceof r)) return new r(t, e, a);
                var l, c = t;
                ("string" == typeof t && (c = document.querySelectorAll(t)), c) ? (this.elements = (l = c, Array.isArray(l) ? l : "object" == typeof l && "number" == typeof l.length ? o.call(l) : [l]), this.options = s({}, this.options), "function" == typeof e ? a = e : s(this.options, e), a && this.on("always", a), this.getImages(), i && (this.jqDeferred = new i.Deferred), setTimeout(this.check.bind(this))) : n.error("Bad element for imagesLoaded " + (c || t))
            }
            r.prototype = Object.create(e.prototype), r.prototype.options = {}, r.prototype.getImages = function() {
                this.images = [], this.elements.forEach(this.addElementImages, this)
            }, r.prototype.addElementImages = function(t) {
                "IMG" == t.nodeName && this.addImage(t), !0 === this.options.background && this.addElementBackgroundImages(t);
                var e = t.nodeType;
                if (e && a[e]) {
                    for (var i = t.querySelectorAll("img"), n = 0; n < i.length; n++) {
                        var s = i[n];
                        this.addImage(s)
                    }
                    if ("string" == typeof this.options.background) {
                        var o = t.querySelectorAll(this.options.background);
                        for (n = 0; n < o.length; n++) {
                            var r = o[n];
                            this.addElementBackgroundImages(r)
                        }
                    }
                }
            };
            var a = {
                1: !0,
                9: !0,
                11: !0
            };

            function l(t) {
                this.img = t
            }

            function c(t, e) {
                this.url = t, this.element = e, this.img = new Image
            }
            return r.prototype.addElementBackgroundImages = function(t) {
                var e = getComputedStyle(t);
                if (e)
                    for (var i = /url\((['"])?(.*?)\1\)/gi, n = i.exec(e.backgroundImage); null !== n;) {
                        var s = n && n[2];
                        s && this.addBackground(s, t), n = i.exec(e.backgroundImage)
                    }
            }, r.prototype.addImage = function(t) {
                var e = new l(t);
                this.images.push(e)
            }, r.prototype.addBackground = function(t, e) {
                var i = new c(t, e);
                this.images.push(i)
            }, r.prototype.check = function() {
                var t = this;

                function e(e, i, n) {
                    setTimeout((function() {
                        t.progress(e, i, n)
                    }))
                }
                this.progressedCount = 0, this.hasAnyBroken = !1, this.images.length ? this.images.forEach((function(t) {
                    t.once("progress", e), t.check()
                })) : this.complete()
            }, r.prototype.progress = function(t, e, i) {
                this.progressedCount++, this.hasAnyBroken = this.hasAnyBroken || !t.isLoaded, this.emitEvent("progress", [this, t, e]), this.jqDeferred && this.jqDeferred.notify && this.jqDeferred.notify(this, t), this.progressedCount == this.images.length && this.complete(), this.options.debug && n && n.log("progress: " + i, t, e)
            }, r.prototype.complete = function() {
                var t = this.hasAnyBroken ? "fail" : "done";
                if (this.isComplete = !0, this.emitEvent(t, [this]), this.emitEvent("always", [this]), this.jqDeferred) {
                    var e = this.hasAnyBroken ? "reject" : "resolve";
                    this.jqDeferred[e](this)
                }
            }, l.prototype = Object.create(e.prototype), l.prototype.check = function() {
                this.getIsImageComplete() ? this.confirm(0 !== this.img.naturalWidth, "naturalWidth") : (this.proxyImage = new Image, this.proxyImage.addEventListener("load", this), this.proxyImage.addEventListener("error", this), this.img.addEventListener("load", this), this.img.addEventListener("error", this), this.proxyImage.src = this.img.src)
            }, l.prototype.getIsImageComplete = function() {
                return this.img.complete && this.img.naturalWidth
            }, l.prototype.confirm = function(t, e) {
                this.isLoaded = t, this.emitEvent("progress", [this, this.img, e])
            }, l.prototype.handleEvent = function(t) {
                var e = "on" + t.type;
                this[e] && this[e](t)
            }, l.prototype.onload = function() {
                this.confirm(!0, "onload"), this.unbindEvents()
            }, l.prototype.onerror = function() {
                this.confirm(!1, "onerror"), this.unbindEvents()
            }, l.prototype.unbindEvents = function() {
                this.proxyImage.removeEventListener("load", this), this.proxyImage.removeEventListener("error", this), this.img.removeEventListener("load", this), this.img.removeEventListener("error", this)
            }, c.prototype = Object.create(l.prototype), c.prototype.check = function() {
                this.img.addEventListener("load", this), this.img.addEventListener("error", this), this.img.src = this.url, this.getIsImageComplete() && (this.confirm(0 !== this.img.naturalWidth, "naturalWidth"), this.unbindEvents())
            }, c.prototype.unbindEvents = function() {
                this.img.removeEventListener("load", this), this.img.removeEventListener("error", this)
            }, c.prototype.confirm = function(t, e) {
                this.isLoaded = t, this.emitEvent("progress", [this, this.element, e])
            }, r.makeJQueryPlugin = function(e) {
                (e = e || t.jQuery) && ((i = e).fn.imagesLoaded = function(t, e) {
                    return new r(this, t, e).jqDeferred.promise(i(this))
                })
            }, r.makeJQueryPlugin(), r
        }))
    }(N),
    /*!
     * Flickity imagesLoaded v2.0.0
     * enables imagesLoaded option for Flickity
     */
    function(t) {
        ! function(e, i) {
            t.exports ? t.exports = i(e, S.exports, N.exports) : e.Flickity = i(e, e.Flickity, e.imagesLoaded)
        }(window, (function(t, e, i) {
            e.createMethods.push("_createImagesLoaded");
            var n = e.prototype;
            return n._createImagesLoaded = function() {
                this.on("activate", this.imagesLoaded)
            }, n.imagesLoaded = function() {
                if (this.options.imagesLoaded) {
                    var t = this;
                    i(this.slider).on("progress", (function(e, i) {
                        var n = t.getParentCell(i.img);
                        t.cellSizeChange(n && n.element), t.options.freeScroll || t.positionSliderAtSelected()
                    }))
                }
            }, e
        }))
    }({
        exports: {}
    });
    /*!
     * Flickity asNavFor v2.0.1
     * enable asNavFor for Flickity
     */
    ! function(t) {
        ! function(e, i) {
            t.exports ? t.exports = i(S.exports, C.exports) : e.Flickity = i(e.Flickity, e.fizzyUIUtils)
        }(window, (function(t, e) {
            t.createMethods.push("_createAsNavFor");
            var i = t.prototype;
            return i._createAsNavFor = function() {
                this.on("activate", this.activateAsNavFor), this.on("deactivate", this.deactivateAsNavFor), this.on("destroy", this.destroyAsNavFor);
                var t = this.options.asNavFor;
                if (t) {
                    var e = this;
                    setTimeout((function() {
                        e.setNavCompanion(t)
                    }))
                }
            }, i.setNavCompanion = function(i) {
                i = e.getQueryElement(i);
                var n = t.data(i);
                if (n && n != this) {
                    this.navCompanion = n;
                    var s = this;
                    this.onNavCompanionSelect = function() {
                        s.navCompanionSelect()
                    }, n.on("select", this.onNavCompanionSelect), this.on("staticClick", this.onNavStaticClick), this.navCompanionSelect(!0)
                }
            }, i.navCompanionSelect = function(t) {
                if (this.navCompanion) {
                    var e, i, n, s = this.navCompanion.selectedCells[0],
                        o = this.navCompanion.cells.indexOf(s),
                        r = o + this.navCompanion.selectedCells.length - 1,
                        a = Math.floor((e = o, i = r, n = this.navCompanion.cellAlign, (i - e) * n + e));
                    if (this.selectCell(a, !1, t), this.removeNavSelectedElements(), !(a >= this.cells.length)) {
                        var l = this.cells.slice(o, r + 1);
                        this.navSelectedElements = l.map((function(t) {
                            return t.element
                        })), this.changeNavSelectedClass("add")
                    }
                }
            }, i.changeNavSelectedClass = function(t) {
                this.navSelectedElements.forEach((function(e) {
                    e.classList[t]("is-nav-selected")
                }))
            }, i.activateAsNavFor = function() {
                this.navCompanionSelect(!0)
            }, i.removeNavSelectedElements = function() {
                this.navSelectedElements && (this.changeNavSelectedClass("remove"), delete this.navSelectedElements)
            }, i.onNavStaticClick = function(t, e, i, n) {
                "number" == typeof n && this.navCompanion.selectCell(n)
            }, i.deactivateAsNavFor = function() {
                this.removeNavSelectedElements()
            }, i.destroyAsNavFor = function() {
                this.navCompanion && (this.navCompanion.off("select", this.onNavCompanionSelect), this.off("staticClick", this.onNavStaticClick), delete this.navCompanion)
            }, t
        }))
    }({
        exports: {}
    });
    ! function(t) {
        ! function(e, i) {
            t.exports ? t.exports = i(S.exports, C.exports) : i(e.Flickity, e.fizzyUIUtils)
        }(m, (function(t, e) {
            var i = t.Slide,
                n = i.prototype.updateTarget;
            i.prototype.updateTarget = function() {
                if (n.apply(this, arguments), this.parent.options.fade) {
                    var t = this.target - this.x,
                        e = this.cells[0].x;
                    this.cells.forEach((function(i) {
                        var n = i.x - e - t;
                        i.renderPosition(n)
                    }))
                }
            }, i.prototype.setOpacity = function(t) {
                this.cells.forEach((function(e) {
                    e.element.style.opacity = t
                }))
            };
            var s = t.prototype;
            t.createMethods.push("_createFade"), s._createFade = function() {
                this.fadeIndex = this.selectedIndex, this.prevSelectedIndex = this.selectedIndex, this.on("select", this.onSelectFade), this.on("dragEnd", this.onDragEndFade), this.on("settle", this.onSettleFade), this.on("activate", this.onActivateFade), this.on("deactivate", this.onDeactivateFade)
            };
            var o = s.updateSlides;
            s.updateSlides = function() {
                o.apply(this, arguments), this.options.fade && this.slides.forEach((function(t, e) {
                    var i = e == this.selectedIndex ? 1 : 0;
                    t.setOpacity(i)
                }), this)
            }, s.onSelectFade = function() {
                this.fadeIndex = Math.min(this.prevSelectedIndex, this.slides.length - 1), this.prevSelectedIndex = this.selectedIndex
            }, s.onSettleFade = function() {
                (delete this.didDragEnd, this.options.fade) && (this.selectedSlide.setOpacity(1), this.slides[this.fadeIndex] && this.fadeIndex != this.selectedIndex && this.slides[this.fadeIndex].setOpacity(0))
            }, s.onDragEndFade = function() {
                this.didDragEnd = !0
            }, s.onActivateFade = function() {
                this.options.fade && this.element.classList.add("is-fade")
            }, s.onDeactivateFade = function() {
                this.options.fade && (this.element.classList.remove("is-fade"), this.slides.forEach((function(t) {
                    t.setOpacity("")
                })))
            };
            var r = s.positionSlider;
            s.positionSlider = function() {
                this.options.fade ? (this.fadeSlides(), this.dispatchScrollEvent()) : r.apply(this, arguments)
            };
            var a = s.positionSliderAtSelected;
            s.positionSliderAtSelected = function() {
                this.options.fade && this.setTranslateX(0), a.apply(this, arguments)
            }, s.fadeSlides = function() {
                if (!(this.slides.length < 2)) {
                    var t = this.getFadeIndexes(),
                        e = this.slides[t.a],
                        i = this.slides[t.b],
                        n = this.wrapDifference(e.target, i.target),
                        s = this.wrapDifference(e.target, -this.x);
                    s /= n, e.setOpacity(1 - s), i.setOpacity(s);
                    var o = t.a;
                    this.isDragging && (o = s > .5 ? t.a : t.b), null != this.fadeHideIndex && this.fadeHideIndex != o && this.fadeHideIndex != t.a && this.fadeHideIndex != t.b && this.slides[this.fadeHideIndex].setOpacity(0), this.fadeHideIndex = o
                }
            }, s.getFadeIndexes = function() {
                return this.isDragging || this.didDragEnd ? this.options.wrapAround ? this.getFadeDragWrapIndexes() : this.getFadeDragLimitIndexes() : {
                    a: this.fadeIndex,
                    b: this.selectedIndex
                }
            }, s.getFadeDragWrapIndexes = function() {
                var t = this.slides.map((function(t, e) {
                        return this.getSlideDistance(-this.x, e)
                    }), this),
                    i = t.map((function(t) {
                        return Math.abs(t)
                    })),
                    n = Math.min.apply(Math, i),
                    s = i.indexOf(n),
                    o = t[s],
                    r = this.slides.length,
                    a = o >= 0 ? 1 : -1;
                return {
                    a: s,
                    b: e.modulo(s + a, r)
                }
            }, s.getFadeDragLimitIndexes = function() {
                for (var t = 0, e = 0; e < this.slides.length - 1; e++) {
                    var i = this.slides[e];
                    if (-this.x < i.target) break;
                    t = e
                }
                return {
                    a: t,
                    b: t + 1
                }
            }, s.wrapDifference = function(t, e) {
                var i = e - t;
                if (!this.options.wrapAround) return i;
                var n = i + this.slideableWidth,
                    s = i - this.slideableWidth;
                return Math.abs(n) < Math.abs(i) && (i = n), Math.abs(s) < Math.abs(i) && (i = s), i
            };
            var l = s._getWrapShiftCells;
            s._getWrapShiftCells = function() {
                this.options.fade || l.apply(this, arguments)
            };
            var c = s.shiftWrapCells;
            return s.shiftWrapCells = function() {
                this.options.fade || c.apply(this, arguments)
            }, t
        }))
    }({
        exports: {}
    });
    var U = {
        exports: {}
    };
    ! function(t, e) {
        var i;
        i = function() {
            return function(t) {
                var e = {};

                function i(n) {
                    if (e[n]) return e[n].exports;
                    var s = e[n] = {
                        i: n,
                        l: !1,
                        exports: {}
                    };
                    return t[n].call(s.exports, s, s.exports, i), s.l = !0, s.exports
                }
                return i.m = t, i.c = e, i.d = function(t, e, n) {
                    i.o(t, e) || Object.defineProperty(t, e, {
                        enumerable: !0,
                        get: n
                    })
                }, i.r = function(t) {
                    "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
                        value: "Module"
                    }), Object.defineProperty(t, "__esModule", {
                        value: !0
                    })
                }, i.t = function(t, e) {
                    if (1 & e && (t = i(t)), 8 & e) return t;
                    if (4 & e && "object" == typeof t && t && t.__esModule) return t;
                    var n = Object.create(null);
                    if (i.r(n), Object.defineProperty(n, "default", {
                            enumerable: !0,
                            value: t
                        }), 2 & e && "string" != typeof t)
                        for (var s in t) i.d(n, s, function(e) {
                            return t[e]
                        }.bind(null, s));
                    return n
                }, i.n = function(t) {
                    var e = t && t.__esModule ? function() {
                        return t.default
                    } : function() {
                        return t
                    };
                    return i.d(e, "a", e), e
                }, i.o = function(t, e) {
                    return Object.prototype.hasOwnProperty.call(t, e)
                }, i.p = "", i(i.s = 0)
            }([function(t, e, i) {
                i.r(e);
                var n = function(t) {
                        return Array.isArray(t) ? t : [t]
                    },
                    s = function(t) {
                        return t instanceof Node
                    },
                    o = function(t, e) {
                        if (t && e) {
                            t = function(t) {
                                return t instanceof NodeList
                            }(t) ? t : [t];
                            for (var i = 0; i < t.length && !0 !== e(t[i], i, t.length); i++);
                        }
                    },
                    r = function(t) {
                        return console.error("[scroll-lock] ".concat(t))
                    },
                    a = function(t) {
                        if (Array.isArray(t)) return t.join(", ")
                    },
                    l = function(t) {
                        var e = [];
                        return o(t, (function(t) {
                            return e.push(t)
                        })), e
                    },
                    c = function(t, e) {
                        var i = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : document;
                        if ((!(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2]) && -1 !== l(i.querySelectorAll(e)).indexOf(t)) return t;
                        for (;
                            (t = t.parentElement) && -1 === l(i.querySelectorAll(e)).indexOf(t););
                        return t
                    },
                    h = function(t, e) {
                        var i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : document;
                        return -1 !== l(i.querySelectorAll(e)).indexOf(t)
                    },
                    d = function(t) {
                        if (t) return "hidden" === getComputedStyle(t).overflow
                    },
                    u = function(t) {
                        if (t) return !!d(t) || t.scrollTop <= 0
                    },
                    p = function(t) {
                        if (t) {
                            if (d(t)) return !0;
                            var e = t.scrollTop,
                                i = t.scrollHeight;
                            return e + t.offsetHeight >= i
                        }
                    },
                    f = function(t) {
                        if (t) return !!d(t) || t.scrollLeft <= 0
                    },
                    g = function(t) {
                        if (t) {
                            if (d(t)) return !0;
                            var e = t.scrollLeft,
                                i = t.scrollWidth;
                            return e + t.offsetWidth >= i
                        }
                    },
                    v = function(t) {
                        return h(t, 'textarea, [contenteditable="true"]')
                    },
                    m = function(t) {
                        return h(t, 'input[type="range"]')
                    };

                function y(t, e, i) {
                    return e in t ? Object.defineProperty(t, e, {
                        value: i,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : t[e] = i, t
                }
                i.d(e, "disablePageScroll", (function() {
                    return x
                })), i.d(e, "enablePageScroll", (function() {
                    return E
                })), i.d(e, "getScrollState", (function() {
                    return w
                })), i.d(e, "clearQueueScrollLocks", (function() {
                    return C
                })), i.d(e, "getTargetScrollBarWidth", (function() {
                    return k
                })), i.d(e, "getCurrentTargetScrollBarWidth", (function() {
                    return L
                })), i.d(e, "getPageScrollBarWidth", (function() {
                    return P
                })), i.d(e, "getCurrentPageScrollBarWidth", (function() {
                    return A
                })), i.d(e, "addScrollableTarget", (function() {
                    return D
                })), i.d(e, "removeScrollableTarget", (function() {
                    return _
                })), i.d(e, "addScrollableSelector", (function() {
                    return I
                })), i.d(e, "removeScrollableSelector", (function() {
                    return z
                })), i.d(e, "addLockableTarget", (function() {
                    return T
                })), i.d(e, "addLockableSelector", (function() {
                    return M
                })), i.d(e, "setFillGapMethod", (function() {
                    return F
                })), i.d(e, "addFillGapTarget", (function() {
                    return O
                })), i.d(e, "removeFillGapTarget", (function() {
                    return W
                })), i.d(e, "addFillGapSelector", (function() {
                    return N
                })), i.d(e, "removeFillGapSelector", (function() {
                    return U
                })), i.d(e, "refillGaps", (function() {
                    return j
                }));
                var b = ["padding", "margin", "width", "max-width", "none"],
                    S = {
                        scroll: !0,
                        queue: 0,
                        scrollableSelectors: ["[data-scroll-lock-scrollable]"],
                        lockableSelectors: ["body", "[data-scroll-lock-lockable]"],
                        fillGapSelectors: ["body", "[data-scroll-lock-fill-gap]", "[data-scroll-lock-lockable]"],
                        fillGapMethod: b[0],
                        startTouchY: 0,
                        startTouchX: 0
                    },
                    x = function(t) {
                        S.queue <= 0 && (S.scroll = !1, q(), Y()), D(t), S.queue++
                    },
                    E = function(t) {
                        S.queue > 0 && S.queue--, S.queue <= 0 && (S.scroll = !0, B(), V()), _(t)
                    },
                    w = function() {
                        return S.scroll
                    },
                    C = function() {
                        S.queue = 0
                    },
                    k = function(t) {
                        var e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                        if (s(t)) {
                            var i = t.style.overflowY;
                            e ? w() || (t.style.overflowY = t.getAttribute("data-scroll-lock-saved-overflow-y-property")) : t.style.overflowY = "scroll";
                            var n = L(t);
                            return t.style.overflowY = i, n
                        }
                        return 0
                    },
                    L = function(t) {
                        if (s(t)) {
                            if (t === document.body) {
                                var e = document.documentElement.clientWidth;
                                return window.innerWidth - e
                            }
                            var i = t.style.borderLeftWidth,
                                n = t.style.borderRightWidth;
                            t.style.borderLeftWidth = "0px", t.style.borderRightWidth = "0px";
                            var o = t.offsetWidth - t.clientWidth;
                            return t.style.borderLeftWidth = i, t.style.borderRightWidth = n, o
                        }
                        return 0
                    },
                    P = function() {
                        var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                        return k(document.body, t)
                    },
                    A = function() {
                        return L(document.body)
                    },
                    D = function(t) {
                        t && n(t).map((function(t) {
                            o(t, (function(t) {
                                s(t) ? t.setAttribute("data-scroll-lock-scrollable", "") : r('"'.concat(t, '" is not a Element.'))
                            }))
                        }))
                    },
                    _ = function(t) {
                        t && n(t).map((function(t) {
                            o(t, (function(t) {
                                s(t) ? t.removeAttribute("data-scroll-lock-scrollable") : r('"'.concat(t, '" is not a Element.'))
                            }))
                        }))
                    },
                    I = function(t) {
                        t && n(t).map((function(t) {
                            S.scrollableSelectors.push(t)
                        }))
                    },
                    z = function(t) {
                        t && n(t).map((function(t) {
                            S.scrollableSelectors = S.scrollableSelectors.filter((function(e) {
                                return e !== t
                            }))
                        }))
                    },
                    T = function(t) {
                        t && (n(t).map((function(t) {
                            o(t, (function(t) {
                                s(t) ? t.setAttribute("data-scroll-lock-lockable", "") : r('"'.concat(t, '" is not a Element.'))
                            }))
                        })), w() || q())
                    },
                    M = function(t) {
                        t && (n(t).map((function(t) {
                            S.lockableSelectors.push(t)
                        })), w() || q(), N(t))
                    },
                    F = function(t) {
                        if (t)
                            if (-1 !== b.indexOf(t)) S.fillGapMethod = t, j();
                            else {
                                var e = b.join(", ");
                                r('"'.concat(t, '" method is not available!\nAvailable fill gap methods: ').concat(e, "."))
                            }
                    },
                    O = function(t) {
                        t && n(t).map((function(t) {
                            o(t, (function(t) {
                                s(t) ? (t.setAttribute("data-scroll-lock-fill-gap", ""), S.scroll || $(t)) : r('"'.concat(t, '" is not a Element.'))
                            }))
                        }))
                    },
                    W = function(t) {
                        t && n(t).map((function(t) {
                            o(t, (function(t) {
                                s(t) ? (t.removeAttribute("data-scroll-lock-fill-gap"), S.scroll || J(t)) : r('"'.concat(t, '" is not a Element.'))
                            }))
                        }))
                    },
                    N = function(t) {
                        t && n(t).map((function(t) {
                            -1 === S.fillGapSelectors.indexOf(t) && (S.fillGapSelectors.push(t), S.scroll || Q(t))
                        }))
                    },
                    U = function(t) {
                        t && n(t).map((function(t) {
                            S.fillGapSelectors = S.fillGapSelectors.filter((function(e) {
                                return e !== t
                            })), S.scroll || K(t)
                        }))
                    },
                    j = function() {
                        S.scroll || Y()
                    },
                    q = function() {
                        var t = a(S.lockableSelectors);
                        G(t)
                    },
                    B = function() {
                        var t = a(S.lockableSelectors);
                        H(t)
                    },
                    G = function(t) {
                        var e = document.querySelectorAll(t);
                        o(e, (function(t) {
                            R(t)
                        }))
                    },
                    H = function(t) {
                        var e = document.querySelectorAll(t);
                        o(e, (function(t) {
                            X(t)
                        }))
                    },
                    R = function(t) {
                        if (s(t) && "true" !== t.getAttribute("data-scroll-lock-locked")) {
                            var e = window.getComputedStyle(t);
                            t.setAttribute("data-scroll-lock-saved-overflow-y-property", e.overflowY), t.setAttribute("data-scroll-lock-saved-inline-overflow-property", t.style.overflow), t.setAttribute("data-scroll-lock-saved-inline-overflow-y-property", t.style.overflowY), t.style.overflow = "hidden", t.setAttribute("data-scroll-lock-locked", "true")
                        }
                    },
                    X = function(t) {
                        s(t) && "true" === t.getAttribute("data-scroll-lock-locked") && (t.style.overflow = t.getAttribute("data-scroll-lock-saved-inline-overflow-property"), t.style.overflowY = t.getAttribute("data-scroll-lock-saved-inline-overflow-y-property"), t.removeAttribute("data-scroll-lock-saved-overflow-property"), t.removeAttribute("data-scroll-lock-saved-inline-overflow-property"), t.removeAttribute("data-scroll-lock-saved-inline-overflow-y-property"), t.removeAttribute("data-scroll-lock-locked"))
                    },
                    Y = function() {
                        S.fillGapSelectors.map((function(t) {
                            Q(t)
                        }))
                    },
                    V = function() {
                        S.fillGapSelectors.map((function(t) {
                            K(t)
                        }))
                    },
                    Q = function(t) {
                        var e = document.querySelectorAll(t),
                            i = -1 !== S.lockableSelectors.indexOf(t);
                        o(e, (function(t) {
                            $(t, i)
                        }))
                    },
                    $ = function(t) {
                        var e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                        if (s(t)) {
                            var i;
                            if ("" === t.getAttribute("data-scroll-lock-lockable") || e) i = k(t, !0);
                            else {
                                var n = c(t, a(S.lockableSelectors));
                                i = k(n, !0)
                            }
                            "true" === t.getAttribute("data-scroll-lock-filled-gap") && J(t);
                            var o = window.getComputedStyle(t);
                            if (t.setAttribute("data-scroll-lock-filled-gap", "true"), t.setAttribute("data-scroll-lock-current-fill-gap-method", S.fillGapMethod), "margin" === S.fillGapMethod) {
                                var r = parseFloat(o.marginRight);
                                t.style.marginRight = "".concat(r + i, "px")
                            } else if ("width" === S.fillGapMethod) t.style.width = "calc(100% - ".concat(i, "px)");
                            else if ("max-width" === S.fillGapMethod) t.style.maxWidth = "calc(100% - ".concat(i, "px)");
                            else if ("padding" === S.fillGapMethod) {
                                var l = parseFloat(o.paddingRight);
                                t.style.paddingRight = "".concat(l + i, "px")
                            }
                        }
                    },
                    K = function(t) {
                        var e = document.querySelectorAll(t);
                        o(e, (function(t) {
                            J(t)
                        }))
                    },
                    J = function(t) {
                        if (s(t) && "true" === t.getAttribute("data-scroll-lock-filled-gap")) {
                            var e = t.getAttribute("data-scroll-lock-current-fill-gap-method");
                            t.removeAttribute("data-scroll-lock-filled-gap"), t.removeAttribute("data-scroll-lock-current-fill-gap-method"), "margin" === e ? t.style.marginRight = "" : "width" === e ? t.style.width = "" : "max-width" === e ? t.style.maxWidth = "" : "padding" === e && (t.style.paddingRight = "")
                        }
                    };
                "undefined" != typeof window && window.addEventListener("resize", (function(t) {
                    j()
                })), "undefined" != typeof document && (document.addEventListener("touchstart", (function(t) {
                    S.scroll || (S.startTouchY = t.touches[0].clientY, S.startTouchX = t.touches[0].clientX)
                })), document.addEventListener("touchmove", (function(t) {
                    if (!S.scroll) {
                        var e = S.startTouchY,
                            i = S.startTouchX,
                            n = t.touches[0].clientY,
                            s = t.touches[0].clientX;
                        if (t.touches.length < 2) {
                            var o = a(S.scrollableSelectors),
                                r = {
                                    up: e < n,
                                    down: e > n,
                                    left: i < s,
                                    right: i > s
                                },
                                l = {
                                    up: e + 3 < n,
                                    down: e - 3 > n,
                                    left: i + 3 < s,
                                    right: i - 3 > s
                                };
                            ! function e(i) {
                                var n = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                                if (i) {
                                    var s = c(i, o, !1);
                                    if (m(i)) return !1;
                                    if (n || v(i) && c(i, o) || h(i, o)) {
                                        var a = !1;
                                        f(i) && g(i) ? (r.up && u(i) || r.down && p(i)) && (a = !0) : u(i) && p(i) ? (r.left && f(i) || r.right && g(i)) && (a = !0) : (l.up && u(i) || l.down && p(i) || l.left && f(i) || l.right && g(i)) && (a = !0), a && (s ? e(s, !0) : t.cancelable && t.preventDefault())
                                    } else e(s)
                                } else t.cancelable && t.preventDefault()
                            }(t.target)
                        }
                    }
                }), {
                    passive: !1
                }), document.addEventListener("touchend", (function(t) {
                    S.scroll || (S.startTouchY = 0, S.startTouchX = 0)
                })));
                var Z = {
                        hide: function(t) {
                            r('"hide" is deprecated! Use "disablePageScroll" instead. \n https://github.com/FL3NKEY/scroll-lock#disablepagescrollscrollabletarget'), x(t)
                        },
                        show: function(t) {
                            r('"show" is deprecated! Use "enablePageScroll" instead. \n https://github.com/FL3NKEY/scroll-lock#enablepagescrollscrollabletarget'), E(t)
                        },
                        toggle: function(t) {
                            r('"toggle" is deprecated! Do not use it.'), w() ? x() : E(t)
                        },
                        getState: function() {
                            return r('"getState" is deprecated! Use "getScrollState" instead. \n https://github.com/FL3NKEY/scroll-lock#getscrollstate'), w()
                        },
                        getWidth: function() {
                            return r('"getWidth" is deprecated! Use "getPageScrollBarWidth" instead. \n https://github.com/FL3NKEY/scroll-lock#getpagescrollbarwidth'), P()
                        },
                        getCurrentWidth: function() {
                            return r('"getCurrentWidth" is deprecated! Use "getCurrentPageScrollBarWidth" instead. \n https://github.com/FL3NKEY/scroll-lock#getcurrentpagescrollbarwidth'), A()
                        },
                        setScrollableTargets: function(t) {
                            r('"setScrollableTargets" is deprecated! Use "addScrollableTarget" instead. \n https://github.com/FL3NKEY/scroll-lock#addscrollabletargetscrollabletarget'), D(t)
                        },
                        setFillGapSelectors: function(t) {
                            r('"setFillGapSelectors" is deprecated! Use "addFillGapSelector" instead. \n https://github.com/FL3NKEY/scroll-lock#addfillgapselectorfillgapselector'), N(t)
                        },
                        setFillGapTargets: function(t) {
                            r('"setFillGapTargets" is deprecated! Use "addFillGapTarget" instead. \n https://github.com/FL3NKEY/scroll-lock#addfillgaptargetfillgaptarget'), O(t)
                        },
                        clearQueue: function() {
                            r('"clearQueue" is deprecated! Use "clearQueueScrollLocks" instead. \n https://github.com/FL3NKEY/scroll-lock#clearqueuescrolllocks'), C()
                        }
                    },
                    tt = function(t) {
                        for (var e = 1; e < arguments.length; e++) {
                            var i = null != arguments[e] ? arguments[e] : {},
                                n = Object.keys(i);
                            "function" == typeof Object.getOwnPropertySymbols && (n = n.concat(Object.getOwnPropertySymbols(i).filter((function(t) {
                                return Object.getOwnPropertyDescriptor(i, t).enumerable
                            })))), n.forEach((function(e) {
                                y(t, e, i[e])
                            }))
                        }
                        return t
                    }({
                        disablePageScroll: x,
                        enablePageScroll: E,
                        getScrollState: w,
                        clearQueueScrollLocks: C,
                        getTargetScrollBarWidth: k,
                        getCurrentTargetScrollBarWidth: L,
                        getPageScrollBarWidth: P,
                        getCurrentPageScrollBarWidth: A,
                        addScrollableSelector: I,
                        removeScrollableSelector: z,
                        addScrollableTarget: D,
                        removeScrollableTarget: _,
                        addLockableSelector: M,
                        addLockableTarget: T,
                        addFillGapSelector: N,
                        removeFillGapSelector: U,
                        addFillGapTarget: O,
                        removeFillGapTarget: W,
                        setFillGapMethod: F,
                        refillGaps: j,
                        _state: S
                    }, Z);
                e.default = tt
            }]).default
        }, t.exports = i()
    }(U);
    var j = e({
        __proto__: null,
        default: y(U.exports)
    }, [U.exports]);
    return window.theme.Flickity = W, t.ScrollLock = j, t.ajaxinate = v, t.themeAddresses = d, t.themeImages = g, Object.defineProperty(t, "__esModule", {
        value: !0
    }), t
}({});