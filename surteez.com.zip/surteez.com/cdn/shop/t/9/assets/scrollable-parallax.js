! function() {
    "use strict";
    customElements.get("parallax-element") || customElements.define("parallax-element", class extends HTMLElement {
        constructor() {
            super(), this.container = this.parentNode, this.percentage = 0, this.percentageFull = 0, this.animation = this.getAttribute("data-parallax-animation"), this.animations = this.animation.split(","), this.disableOnMobile = this.hasAttribute("data-parallax-disable-on-mobile"), this.viewportHeight = Math.max(document.documentElement.clientHeight, window.innerHeight || 0), this.containerHeight = this.container.offsetHeight, this.main = document.querySelector("[data-main]"), this.firstSection = this.main.children[0], this.orientation = window.theme.getScreenOrientation(), this.scrollEvent = () => this.updateParallax(), this.resizeEvent = () => this.updateHeight(), this.refreshEvent = () => this.refresh()
        }
        assignFooterArguments() {
            this.animations.includes("footer") && (this.shopifySection = this.closest(".shopify-section"), this.footerPrevSectionOffset = 0, this.hasAttribute("data-parallax-rounded-corners") && (this.footerPrevSectionOffset = 8, this.hasAttribute("data-parallax-rounded-corners-large") && (this.footerPrevSectionOffset = 34)), this.prevSection = this.container.parentNode.previousElementSibling, !this.prevSection || this.prevSection.classList.contains("shopify-section") || this.prevSection.classList.contains("main-content") || (this.prevSection = this.main), this.containerHeight = this.container.offsetHeight, this.footerOffset = .15 * this.containerHeight, this.cachedPosition = this.footerOffset, this.cachedPercentage = 0)
        }
        assignCardScrollingArguments() {
            if (!this.animations.includes("card-scrolling")) return;
            let {
                stickyHeaderHeight: t
            } = window.theme.readHeights();
            if (this.headerHeight = t || 0, this.shopifySection = this.closest(".shopify-section"), this.nextSection = this.shopifySection.nextElementSibling, this.cardScrollingStickyTop = this.headerHeight || 0, this.cardScrollingMarginTop = this.nextSection ? parseInt(window.getComputedStyle(this.nextSection).getPropertyValue("margin-top")) : 0, this.after = !1, this.prevSection = this.shopifySection.previousElementSibling, this.prevSection) {
                const t = this.firstSection.id,
                    e = this.prevSection.matches(`#${t}`),
                    i = this.prevSection.offsetHeight;
                this.shopifySection.classList.toggle("sticky-top-zero", e && i <= 2 * this.headerHeight)
            }
            this.opacityValue = t => t ? Boolean(t <= 0) ? 0 : Boolean(t > 0 && t <= 100) ? Number(t / 100).toFixed(4) : Boolean(t > 100) ? 1 : void 0 : 0
        }
        connectedCallback() {
            this.assignFooterArguments(), this.assignCardScrollingArguments(), requestAnimationFrame((() => {
                this.updateParallax(), document.addEventListener("theme:scroll", this.scrollEvent), document.addEventListener("theme:resize", this.resizeEvent), document.addEventListener("theme:parallax:refresh", this.refreshEvent)
            }))
        }
        updateParallax() {
            this.container.classList.contains("is-disabled") || this.disableOnMobile && window.theme.isMobile() || (this.scrollTop = Math.round(window.scrollY), this.scrollBottom = this.scrollTop + this.viewportHeight, this.elementOffsetTopPoint = Math.round(this.container.getBoundingClientRect().top + this.scrollTop), window.Shopify.designMode && (this.assignCardScrollingArguments(), this.containerHeight = this.container.offsetHeight), this.elementOffsetBottomPoint = this.elementOffsetTopPoint + this.containerHeight, this.isBottomOfElementPassed = this.elementOffsetBottomPoint < this.scrollTop, this.isTopOfElementReached = this.elementOffsetTopPoint < this.scrollBottom, this.isInView = this.isTopOfElementReached && !this.isBottomOfElementPassed, this.adjustCalculations(), this.toggleVisibility(), this.isInView && (this.scrollProgress = this.scrollBottom - this.elementOffsetTopPoint, this.percentage = 100 * (this.scrollProgress - this.containerHeight / 2) / this.viewportHeight, this.percentageFull = Number(this.scrollProgress / this.containerHeight).toFixed(2), this.percentageVisible = Number(100 * this.scrollProgress / (this.viewportHeight + this.containerHeight)).toFixed(2), this.animations.includes("circle") && this.animateCircleText(), (this.animations.includes("horizontal") || this.animations.includes("vertical") || this.animations.includes("diagonal")) && this.animateOverlappingImages(), (this.animations.includes("offset-ltr") || this.animations.includes("offset-rtl")) && this.offsetX(), this.animations.includes("card-scrolling") && this.cardScrollingEffect(), this.animations.includes("zoom-on-scroll") && this.zoomInOut(), this.animations.includes("footer") && this.animateFooter()))
        }
        adjustCalculations() {
            this.animations.includes("card-scrolling") && (this.currentSectionTop = this.shopifySection.getBoundingClientRect().top, this.nextSection ? (this.nextSectionTop = this.nextSection.getBoundingClientRect().top, this.sectionOffsetTop = this.nextSectionTop - this.containerHeight - this.cardScrollingMarginTop) : (this.nextSectionTop = this.currentSectionTop + this.containerHeight, this.sectionOffsetTop = this.currentSectionTop), this.distance = Math.floor(this.currentSectionTop - this.headerHeight), this.after = Boolean(Math.round(this.nextSectionTop - this.headerHeight - this.cardScrollingMarginTop + .1 * this.viewportHeight) < 0), this.isInView = this.isTopOfElementReached && !this.after), this.animations.includes("footer") && (window.Shopify.designMode && this.assignFooterArguments(), this.elementOffsetTopPoint = Math.round(this.prevSection ? .getBoundingClientRect().bottom - this.footerPrevSectionOffset + this.scrollTop), this.elementOffsetBottomPoint = this.elementOffsetTopPoint + this.containerHeight, this.isBottomOfElementPassed = this.elementOffsetBottomPoint < this.scrollTop, this.isTopOfElementReached = this.elementOffsetTopPoint < this.scrollBottom, this.isInView = this.isTopOfElementReached && !this.isBottomOfElementPassed, this.isApproaching = Math.round(this.elementOffsetTopPoint - this.viewportHeight / 2) < this.scrollBottom)
        }
        toggleVisibility() {
            this.animations.includes("card-scrolling") && this.shopifySection.classList.toggle("card-scrolling-hidden", this.after), this.animations.includes("footer") && (Boolean(this.isApproaching || this.isInView) ? this.shopifySection.classList.add("section-footer--visible") : this.shopifySection.classList.remove("section-footer--visible"))
        }
        cardScrollingEffect() {
            const t = this.sectionOffsetTop / this.containerHeight * -100;
            this.container.style.setProperty("--card-scrolling-overlay", this.opacityValue(t))
        }
        zoomInOut() {
            if (this.animations.includes("card-scrolling") && this.nextSection) {
                const t = this.nextSectionTop - this.headerHeight - this.cardScrollingMarginTop - this.containerHeight,
                    e = Math.round(t + this.scrollTop),
                    i = this.scrollBottom - e;
                this.percentageVisible = Number(100 * i / (this.viewportHeight + this.containerHeight + this.cardScrollingMarginTop)).toFixed(2)
            }
            const t = .2 * this.percentageVisible / 100;
            let e = Number(1 + t).toFixed(4);
            e = e > 1 ? e : 1, this.container.style.setProperty("--scale", e)
        }
        offsetX() {
            const t = this.hasAttribute("data-parallax-static"),
                e = this.getAttribute("data-parallax-intensity") || 100;
            let i = this.animations.includes("offset-ltr") ? e : 0;
            t && (i = e / 2);
            const s = this.animations.includes("offset-ltr") ? 1 : -1,
                n = e * this.percentageVisible / 100 - i,
                o = Number(n * s).toFixed(2);
            this.container.style.setProperty("--offsetX", `${o}%`)
        }
        updateHeight() {
            if (this.animations.includes("card-scrolling")) {
                let {
                    stickyHeaderHeight: t
                } = window.theme.readHeights();
                if (this.headerHeight = t || 0, this.cardScrollingStickyTop = this.headerHeight || 0, this.cardScrollingMarginTop = this.nextSection ? parseInt(window.getComputedStyle(this.nextSection).getPropertyValue("margin-top")) : 0, this.containerHeight = this.container.offsetHeight, this.prevSection = this.shopifySection.previousElementSibling, this.prevSection) {
                    const t = this.firstSection.id,
                        e = this.prevSection.matches(`#${t}`),
                        i = this.prevSection.offsetHeight;
                    this.shopifySection.classList.toggle("sticky-top-zero", e && i <= 2 * this.headerHeight)
                }
            }
            const t = matchMedia("(min-width: 1024px)").matches;
            (this.orientation !== window.theme.getScreenOrientation() || t) && (this.viewportHeight = Math.round(Math.max(document.documentElement.clientHeight, window.innerHeight || 0)), this.containerHeight = this.container.offsetHeight, this.orientation = window.theme.getScreenOrientation())
        }
        animateCircleText() {
            const t = 70 * this.percentage / 100 * -1;
            this.percentage > 0 && this.container.style.setProperty("--rotate", `${35+t}deg`)
        }
        animateOverlappingImages() {
            const t = .25 * this.getAttribute("data-parallax-intensity"),
                e = t / 2,
                i = this.hasAttribute("data-parallax-single"),
                s = t * this.percentage / 100;
            let n = 0,
                o = 0,
                h = 0,
                r = 0;
            (this.animations.includes("horizontal") || this.animations.includes("diagonal")) && (n = -1 * e + s, h = e - s), (this.animations.includes("vertical") || this.animations.includes("diagonal")) && (o = e - s, r = -1 * e + s), this.container.style.setProperty("--transformX-primary", `${n}%`), this.container.style.setProperty("--transformY-primary", `${o}%`), i || (this.container.style.setProperty("--transformX-secondary", `${h}%`), this.container.style.setProperty("--transformY-secondary", `${r}%`))
        }
        animateFooter() {
            const t = this.footerOffset * this.percentageFull,
                e = Number(t / this.footerOffset * 100).toFixed(2),
                i = new WebKitCSSMatrix(window.getComputedStyle(this.container).transform),
                s = Number(i.m42).toFixed(2);
            let n = Number(this.footerOffset - t).toFixed(2);
            this.percentageFull >= 1 && (n = 0), s !== n && this.cachedPercentage !== e && (this.container.style.setProperty("--transformY", `${n}`), this.cachedPercentage = e, this.cachedPosition = n)
        }
        disconnectedCallback() {
            document.removeEventListener("theme:scroll", this.scrollEvent), document.removeEventListener("theme:resize", this.resizeEvent), document.removeEventListener("theme:parallax:refresh", this.refreshEvent)
        }
        refresh() {
            this.assignFooterArguments(), this.assignCardScrollingArguments(), requestAnimationFrame((() => this.updateParallax()))
        }
    })
}();