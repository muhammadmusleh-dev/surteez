! function() {
    "use strict";
    class e {
        constructor(e, t) {
            this.configuration = {
                expires: null,
                path: "/",
                domain: window.location.hostname,
                sameSite: "none",
                secure: !0
            }, this.name = e, this.value = t
        }
        write() {
            (-1 !== document.cookie.indexOf("; ") && !document.cookie.split("; ").find((e => e.startsWith(this.name))) || -1 === document.cookie.indexOf("; ")) && (document.cookie = `${this.name}=${this.value}; expires=${this.configuration.expires}; path=${this.configuration.path}; domain=${this.configuration.domain}; sameSite=${this.configuration.sameSite}; secure=${this.configuration.secure}`)
        }
        read() {
            if (-1 !== document.cookie.indexOf("; ") && document.cookie.split("; ").find((e => e.startsWith(this.name)))) {
                return document.cookie.split("; ").find((e => e.startsWith(this.name))).split("=")[1]
            }
            return !1
        }
        destroy() {
            document.cookie.split("; ").find((e => e.startsWith(this.name))) && (document.cookie = `${this.name}=null; expires=${this.configuration.expires}; path=${this.configuration.path}; domain=${this.configuration.domain}; sameSite=${this.configuration.sameSite}; secure=${this.configuration.secure}`)
        }
    }
    customElements.get("newsletter-form") || customElements.define("newsletter-form", class extends HTMLElement {
        constructor() {
            super(), this.newsletter = this.querySelector("[data-newsletter-form]"), this.sessionStorage = window.sessionStorage, this.popup = this.newsletter.closest("[data-popup]"), this.stopSubmit = !0, this.isChallengePage = !1, this.formID = null, this.checkForChallengePage(), this.newsletterSubmit = e => this.newsletterSubmitEvent(e)
        }
        connectedCallback() {
            this.newsletter.addEventListener("submit", this.newsletterSubmit), this.isChallengePage || this.showMessage()
        }
        newsletterSubmitEvent(e) {
            this.stopSubmit && (e.preventDefault(), this.removeStorage(), this.writeStorage(), this.stopSubmit = !1, this.newsletter.submit())
        }
        checkForChallengePage() {
            this.isChallengePage = window.location.pathname === theme.routes.root + "challenge"
        }
        writeStorage() {
            void 0 !== this.sessionStorage && this.sessionStorage.setItem("newsletter_form_id", this.newsletter.id)
        }
        readStorage() {
            void 0 !== this.sessionStorage && (this.formID = this.sessionStorage.getItem("newsletter_form_id"))
        }
        removeStorage() {
            this.sessionStorage ? .removeItem("newsletter_form_id")
        }
        showMessage() {
            if (this.readStorage(), this.newsletter.id === this.formID) {
                const t = document.getElementById(this.formID),
                    s = -1 !== window.location.search.indexOf("?customer_posted=true"),
                    i = -1 !== window.location.search.indexOf("accepts_marketing");
                s ? (t.classList.remove("has-error"), t.classList.add("has-success"), this.popup && (this.cookie = new e(this.popup.dataset.cookieName, "user_has_closed"), this.cookie.write())) : i && (t.classList.remove("has-success"), t.classList.add("has-error")), (s || i) && this.scrollToForm(t)
            }
        }
        scrollToForm(e) {
            let {
                stickyHeaderHeight: t
            } = window.theme.readHeights();
            const s = t || 0,
                i = e.closest("section"),
                o = e.closest("footer");
            visibilityHelper.isElementPartiallyVisible(e) || visibilityHelper.isElementTotallyVisible(e) || setTimeout((() => {
                let t = window.scrollY,
                    n = e.getBoundingClientRect().top;
                i ? n = i.getBoundingClientRect().top : o && o.closest(".shopify-section").classList.contains("section-footer--parallax") && (n = document.body.scrollHeight, t = 0);
                const r = n - s + t;
                window.scrollTo({
                    top: r,
                    left: 0,
                    behavior: "smooth"
                })
            }), 400)
        }
        disconnectedCallback() {
            this.newsletter.removeEventListener("submit", this.newsletterSubmit)
        }
    })
}();