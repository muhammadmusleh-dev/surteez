! function() {
    "use strict";
    customElements.get("look-component") || customElements.define("look-component", class extends HTMLElement {
        constructor() {
            super(), this.flkty = null, this.observer = null, this.checkSlidesSizeOnResize = () => this.checkSlidesSize(), this.resizeSliderEvent = e => this.resizeSlider(e), this.pointersInit = e => this.dotPointers(e), this.pointersOver = e => this.dotPointerIn(e), this.pointersOut = e => this.dotPointerOut(e)
        }
        connectedCallback() {
            this.slider = this.querySelector("[data-slider]"), this.productOnRow = Number(this.slider ? .getAttribute("data-products")) || 3, this.slides = this.querySelectorAll("[data-slide-item]"), this.sTLHotspotsItems = this.querySelectorAll("[data-stl-hotspots-item]"), this.pointers = this.querySelectorAll("[data-pointer]"), this.pointerBubbles = this.querySelectorAll("[data-pointer-bubble]"), this.buttonsQuickView = this.querySelectorAll("[data-button-quick-view]"), this.shopTheLookQuickViewButton = this.querySelectorAll("[data-shop-the-look-quick-view-button]"), this.shopTheLookQuickViewButton ? .forEach((e => {
                e.addEventListener("click", (() => {
                    const e = [...this.buttonsQuickView].find((e => e.hasAttribute("data-shop-the-look-quick-view")));
                    e ? .dispatchEvent(new Event("click"))
                }))
            })), this.listen()
        }
        listen() {
            this.slider && (this.checkSlidesSize(), document.addEventListener("theme:resize:width", this.checkSlidesSizeOnResize), this.slider.addEventListener("theme:slider:resize", this.resizeSliderEvent)), this.pointers.forEach((e => {
                e.addEventListener("click", this.pointersInit), e.addEventListener("mouseover", this.pointersOver), e.addEventListener("mouseleave", this.pointersOut)
            })), this.pointerBubbles.forEach(((e, t) => {
                e.addEventListener("click", (e => [...this.pointers][t].dispatchEvent(new Event(e.type)))), e.addEventListener("mouseover", (e => [...this.pointers][t].dispatchEvent(new Event(e.type)))), e.addEventListener("mouseleave", (e => [...this.pointers][t].dispatchEvent(new Event(e.type))))
            }))
        }
        checkSlidesSize() {
            const e = window.innerWidth < theme.sizes.small,
                t = window.innerWidth >= theme.sizes.large,
                i = window.innerWidth >= theme.sizes.small && window.innerWidth < theme.sizes.large,
                s = Boolean(t && this.slides.length > this.productOnRow),
                r = Boolean(i && this.slides.length > 2);
            e ? this.destroySlider() : s || r ? this.initSlider() : (this.destroySlider(), this.slidesTabIndex())
        }
        initSlider() {
            null !== this.flkty ? this.setSliderArrowsPosition() : this.flkty = new window.theme.Flickity(this.slider, {
                prevNextButtons: !0,
                wrapAround: !0,
                adaptiveHeight: !1,
                cellAlign: "left",
                groupCells: !1,
                contain: !0,
                on: {
                    ready: () => {
                        this.slidesTabIndex(), this.setSliderArrowsPosition(), this.dotPointers(), requestAnimationFrame((() => {
                            this.flkty && this.flkty.resize()
                        }))
                    },
                    change: () => {
                        this.slidesTabIndex(), this.dotPointers()
                    }
                }
            })
        }
        setSliderArrowsPosition() {
            if (!(window.innerWidth >= theme.sizes.small)) return;
            const e = this.slider.querySelectorAll(".flickity-button"),
                t = this.slider.querySelector("[data-product-media-container]");
            e.length && t && e.forEach((e => {
                e.style.top = t.offsetHeight / 2 + "px"
            }))
        }
        slidesTabIndex() {
            if (this.slides.length < this.productOnRow + 1) return void this.slider.querySelectorAll("a, button").forEach((e => {
                e.setAttribute("tabindex", "0")
            }));
            window.theme.Flickity.data(this.slider).cells.forEach((e => {
                let t = "-1";
                e.element.classList.contains("is-selected") && (t = "0"), e.element.querySelectorAll("a, button").forEach((e => {
                    e.setAttribute("tabindex", t)
                }))
            }))
        }
        destroySlider() {
            "object" == typeof this.flkty && null !== this.flkty && (this.flkty.destroy(), this.flkty = null)
        }
        resizeSlider(e) {
            const t = e.target,
                i = window.theme.Flickity.data(t) || null;
            i && i.resize()
        }
        dotPointers(e) {
            if (0 === this.pointers.length) return;
            if (this.sTLHotspotsItems.forEach((e => e.classList.remove("on-hover"))), e) {
                const t = e.target.getAttribute("data-pointer");
                return void this.flkty ? .select(t)
            }
            const t = null == this.flkty ? 0 : this.flkty.selectedIndex;
            t >= 0 && this.sTLHotspotsItems[t].classList.add("on-hover")
        }
        dotPointerIn(e) {
            const t = e.target.getAttribute("data-pointer"),
                i = this.slides[t].querySelector("[data-product-media-container]"),
                s = matchMedia("(pointer:coarse)").matches;
            window.innerWidth < theme.sizes.small || s || this.observeImage(i), this.pointers[t].style.setProperty("--target-animation", "none")
        }
        dotPointerOut(e) {
            const t = e.target.getAttribute("data-pointer"),
                i = this.slides[t].querySelector("[data-product-media-container]");
            i.classList.remove("product-grid-item__image--hovered"), i.dispatchEvent(new Event("mouseleave")), this.observer && this.observer.disconnect(), this.pointers.forEach((e => {
                e.style.removeProperty("--target-animation")
            }))
        }
        observeImage(e) {
            this.observer = new IntersectionObserver(((e, t) => {
                e.forEach((e => {
                    const t = e.target;
                    0 == e.intersectionRatio || (t.dispatchEvent(new Event("mouseenter")), t.classList.add("product-grid-item__image--hovered"))
                }))
            }), {
                root: this.slider,
                threshold: [.95, 1]
            }), this.observer.observe(e)
        }
        disconnectedCallback() {
            document.removeEventListener("theme:resize:width", this.checkSlidesSizeOnResize), this.slider && this.slider.removeEventListener("theme:slider:resize", this.resizeSliderEvent)
        }
    })
}();