! function() {
    "use strict";
    const t = "[data-shopify-xr]",
        e = "[data-product-single-media-group]",
        i = "data-shopify-model3d-id";
    class a extends window.theme.DeferredMedia {
        constructor() {
            super()
        }
        loadContent() {
            super.loadContent(), this.modelId = this.element.dataset.modelId, this.xrButton = this.mediaContainer.closest(e) ? .parentElement.querySelector(t), Shopify.loadFeatures([{
                name: "model-viewer-ui",
                version: "1.0",
                onLoad: this.setupModelViewerUI.bind(this)
            }])
        }
        setupModelViewerUI(t) {
            t ? console.warn(t) : (this.modelViewerUI = new Shopify.ModelViewerUI(this.element), this.setupModelViewerListeners())
        }
        setupModelViewerListeners() {
            this.mediaContainer.addEventListener("theme:media:visible", (() => {
                this.xrButton.setAttribute(i, this.modelId), window.theme.touch || (this.modelViewerUI.play(), this.mediaContainer.dispatchEvent(new CustomEvent("theme:media:play"), {
                    bubbles: !0
                }))
            })), this.mediaContainer.addEventListener("theme:media:hidden", (() => {
                this.modelViewerUI.pause()
            })), this.mediaContainer.addEventListener("xrLaunch", (() => {
                this.modelViewerUI.pause()
            })), this.element.addEventListener("load", (() => {
                this.xrButton.setAttribute(i, this.modelId), this.mediaContainer.dispatchEvent(new CustomEvent("theme:media:play"), {
                    bubbles: !0
                })
            })), this.element.addEventListener("shopify_model_viewer_ui_toggle_play", (() => {
                this.pauseOtherMedia(), setTimeout((() => {
                    this.mediaContainer.dispatchEvent(new CustomEvent("theme:media:play"), {
                        bubbles: !0
                    })
                }), 50)
            })), this.element.addEventListener("shopify_model_viewer_ui_toggle_pause", (() => {
                this.mediaContainer.dispatchEvent(new CustomEvent("theme:media:pause"), {
                    bubbles: !0
                })
            })), this.pauseOtherMedia()
        }
    }
    window.ProductModel = {
        loadShopifyXR() {
            Shopify.loadFeatures([{
                name: "shopify-xr",
                version: "1.0",
                onLoad: this.setupShopifyXR.bind(this)
            }])
        },
        setupShopifyXR(t) {
            t ? console.warn(t) : window.ShopifyXR ? (document.querySelectorAll('[id^="ModelJson-"]').forEach((t => {
                window.ShopifyXR.addModels(JSON.parse(t.textContent)), t.remove()
            })), window.ShopifyXR.setupXRElements()) : document.addEventListener("shopify_xr_initialized", (() => this.setupShopifyXR()))
        }
    }, window.addEventListener("DOMContentLoaded", (() => {
        window.ProductModel && window.ProductModel.loadShopifyXR()
    }));
    const s = 1,
        n = {
            history: !1,
            focus: !1,
            mainClass: "pswp--notification pswp--not-close-btn",
            closeOnVerticalDrag: !1
        };
    class r {
        constructor(t) {
            this.button = t, this.a11y = window.theme.a11y, this.a11y.state.trigger = this.button, this.handle = this.button.getAttribute("data-handle"), this.variantId = this.button.getAttribute("data-variant-id"), this.init()
        }
        init() {
            const t = this.variantId ? `&variant=${this.variantId}` : "",
                e = `${theme.routes.root}products/${this.handle}?section_id=api-notification${t}`;
            this.loadPhotoswipeFromFetch(e)
        }
        loadPhotoswipeFromFetch(t) {
            fetch(t).then((t => t.text())).then((t => {
                const e = [{
                    html: t
                }];
                new window.theme.LoadPhotoswipe(e, n, s)
            })).catch((t => console.log("error: ", t)))
        }
    }
    customElements.get("product-info") || customElements.define("product-info", class extends HTMLElement {
        quantityInput = void 0;
        quantityForm = void 0;
        onVariantChangeUnsubscriber = void 0;
        cartUpdateUnsubscriber = void 0;
        abortController = void 0;
        pendingRequestUrl = null;
        preProcessHtmlCallbacks = [];
        postProcessHtmlCallbacks = [];
        constructor() {
            super(), this.flkty = null, this.flktyNav = null, this.isFlickityDragging = !1, this.checkSliderOnResize = () => this.checkSlider(), this.flktyNavOnResize = () => this.resizeFlickityNav(), this.quantityInput = this.querySelector("[data-quantity-field]")
        }
        connectedCallback() {
            this.sessionStorage = window.sessionStorage, this.hasUnitPricing = this.querySelector("[data-product-unit]"), this.notificationPopupButton = this.querySelector("[data-notification-popup]"), this.initializeProductSwapUtility();
            try {
                const t = this.dataset.productHandle;
                window.Shopify ? .Products ? .recordRecentlyViewed && (t ? window.Shopify.Products.recordRecentlyViewed({
                    handle: t
                }) : window.Shopify.Products.recordRecentlyViewed())
            } catch (t) {
                console.warn("Recently viewed recording error:", t)
            }
            this.onVariantChangeUnsubscriber = subscribe(theme.PUB_SUB_EVENTS.optionValueSelectionChange, this.handleOptionValueChange.bind(this)), this.initQuantityHandlers(), this.dispatchEvent(new CustomEvent("theme:product-info:loaded", {
                bubbles: !0
            })), this.variantOptionImages = this.querySelectorAll("[data-variant-option-image]"), this.hasVariantOptionWithImage = this.variantOptionImages.length > 1, this.hasVariantOptionWithImage && (this.optionImagesWidth(), this.onResizeCallback = () => this.resizeEvents(), window.addEventListener("theme:resize:width", this.onResizeCallback)), this.tallLayout = "true" === this.getAttribute("data-tall-layout"), this.featureSliders = this.querySelectorAll("[data-slider]"), this.initUpsellSlider(), this.initFeatureSlider(), this.productSlider(), this.initMediaSwitch(), this.initShopifyXrLaunch(), this.notificationPopupButton && this.setNotificationPopup(this.notificationPopupButton), this.checkLiveCartInfo(), this.checkLiveCartInfoCallback = () => this.checkLiveCartInfo(), document.addEventListener("theme:cart:close", this.checkLiveCartInfoCallback)
        }
        initQuantityHandlers() {
            this.quantityInput && (this.quantityForm = this.querySelector("[data-quantity-wrapper]"), this.quantityForm && (this.setQuantityBoundaries(), this.quantityInput.addEventListener("change", (() => this.updateProductPrices())), this.quantityInput.addEventListener("change", (() => this.checkLiveCartInfo())), this.dataset.originalSection || (this.cartUpdateUnsubscriber = subscribe(theme.PUB_SUB_EVENTS.cartUpdate, this.fetchQuantityRules.bind(this)))))
        }
        initializeProductSwapUtility() {
            this.postProcessHtmlCallbacks.push((t => {
                window ? .Shopify ? .PaymentButton ? .init(), window ? .ProductModel ? .loadShopifyXR(), this.optionImagesWidth(t)
            }))
        }
        optionImagesWidth() {
            const t = this.querySelectorAll("[data-variant-option-image]");
            if (t.length > 1) {
                const e = t[0].closest("[data-variant-buttons]");
                requestAnimationFrame((() => {
                    const i = [...t].map((t => Math.floor(t.offsetHeight))),
                        a = [...t].map((t => Math.floor(t.offsetWidth))),
                        s = Math.max(...a),
                        n = Math.max(...i);
                    e.style.setProperty("--option-image-width", s + "px"), e.style.setProperty("--option-image-height", n + "px")
                }))
            }
        }
        resizeEvents() {
            this.optionImagesWidth()
        }
        handleOptionValueChange({
            data: {
                event: t,
                target: e,
                selectedOptionValues: i
            }
        }) {
            if (!this.contains(t.target)) return;
            const a = e.dataset.productUrl || this.pendingRequestUrl || this.dataset.url;
            this.pendingRequestUrl = a;
            const s = this.dataset.url !== a,
                n = "true" === this.dataset.updateUrl && s;
            this.renderProductInfo({
                requestUrl: this.buildRequestUrlWithParams(a, i, n),
                targetId: e.id,
                callback: s ? this.handleSwapProduct(a, n) : this.handleUpdateProductInfo(a)
            })
        }
        handleSwapProduct(t, e) {
            return i => {
                this.productModal ? .remove();
                const a = e ? "product-info[id^='MainProduct']" : "product-info",
                    s = this.getSelectedVariant(i.querySelector(a));
                this.updateURL(t, s ? .id), e ? (document.querySelector("head title").innerHTML = i.querySelector("head title").innerHTML, HTMLUpdateUtility.viewTransition(document.querySelector("main"), i.querySelector("main"), this.preProcessHtmlCallbacks, this.postProcessHtmlCallbacks)) : HTMLUpdateUtility.viewTransition(this, i.querySelector("product-info"), this.preProcessHtmlCallbacks, this.postProcessHtmlCallbacks), requestAnimationFrame((() => this.optionImagesWidth()))
            }
        }
        renderProductInfo({
            requestUrl: t,
            targetId: e,
            callback: i
        }) {
            this.abortController ? .abort(), this.abortController = new AbortController, fetch(t, {
                signal: this.abortController.signal
            }).then((t => t.text())).then((t => {
                this.pendingRequestUrl = null;
                const e = (new DOMParser).parseFromString(t, "text/html");
                i(e)
            })).then((() => {
                document.querySelector(`#${e}`) ? .focus()
            })).catch((t => {
                "AbortError" === t.name ? console.log("Fetch aborted by user") : console.error(t)
            }))
        }
        getSelectedVariant(t) {
            const e = t.querySelector("variant-selects [data-selected-variant]") ? .innerHTML;
            return e ? JSON.parse(e) : null
        }
        buildRequestUrlWithParams(t, e, i = !1) {
            const a = [];
            return !i && a.push(`section_id=${this.sectionId}`), e.length && a.push(`option_values=${e.join(",")}`), `${t}?${a.join("&")}`
        }
        updateOptionValues(t) {
            const e = t.querySelector("variant-selects");
            e ? .querySelectorAll("[data-aos]") ? .forEach((t => t.classList.add("aos-animate", "no-animation"))), e && HTMLUpdateUtility.viewTransition(this.variantSelectors, e, this.preProcessHtmlCallbacks)
        }
        handleUpdateProductInfo(t) {
            return e => {
                const i = this.getSelectedVariant(e);
                if (this.pickupAvailability ? .update(i), this.updateOptionValues(e), this.updateURL(t, i ? .id), this.updateVariantInputs(i ? .id), !i) return void this.setUnavailable();
                this.updateMedia(i.featured_media);
                const a = (t, i = (t => !1)) => {
                    let a = `${this.sectionId}-${this.dataset.productId}`;
                    const s = e.getElementById(`${t}-${a}`),
                        n = this.querySelector(`#${t}-${a}`);
                    s && n && (n.innerHTML = s.innerHTML, n.classList.toggle("hidden", i(s)))
                };
                this.productState = this.setProductState(i), a("Price"), this.updateTitleAttr(i), a("Inventory"), a("AddToCartText"), this.updateAddToCartState(i), this.updateQuantityRules(this.sectionId, e), this.checkLiveCartInfo(), this.updateProductPrices(i), this.optionImagesWidth(), publish(theme.PUB_SUB_EVENTS.variantChange, {
                    data: {
                        sectionId: this.sectionId,
                        html: e,
                        variant: i
                    }
                })
            }
        }
        updateVariantInputs(t) {
            const e = `${this.sectionId}-${this.dataset.productId}`;
            this.querySelectorAll(`#AddToCartForm--${e}`).forEach((e => {
                const i = e.querySelector('input[name="id"]');
                i.value = t ? ? "", i.dispatchEvent(new Event("change", {
                    bubbles: !0
                }))
            }))
        }
        updateURL(t, e) {
            this.shareButton ? .updateUrl(`${window.theme.routes.shop_url}${t}${e?`?variant=${e}`:""}`), "false" !== this.dataset.updateUrl && window.history.replaceState({}, "", `${t}${e?`?variant=${e}`:""}`)
        }
        setUnavailable() {
            const t = this.querySelector("[data-remaining-wrapper]");
            this.productForm ? .toggleSubmitButton(!0, theme.strings.unavailable), this.querySelectorAll("[data-price-wrapper]").forEach((t => {
                t.hasAttribute("data-atc-button") || t.classList.add("product__price--hidden")
            })), t && (t.classList.remove("count-is-in", "count-is-out", "count-is-low"), t.classList.add("count-is-unavailable"))
        }
        setProductState(t) {
            const e = {
                available: !0,
                soldOut: !1,
                onSale: !1,
                showUnitPrice: !1
            };
            return t ? (t.available || (e.soldOut = !0), t.compare_at_price > t.price && (e.onSale = !0), t.unit_price && (e.showUnitPrice = !0)) : e.available = !1, e
        }
        updateMedia(t) {
            if (!t) return;
            const e = this.querySelector(`[data-product-image][data-image-id="${t.id}"]`),
                i = e ? .closest("[data-product-slide]");
            if (i) {
                const a = parseInt([...i.parentElement.children].indexOf(i)),
                    s = this.querySelector("[data-product-single-media-slider]"),
                    n = window.theme.Flickity.data(s);
                if (n && n.isActive) {
                    const e = s.querySelector(`[data-id="${t.id}"]`);
                    if (e) {
                        this.hideTooltipOnSlideChange(e);
                        const t = parseInt([...e.parentNode.children].indexOf(e));
                        n.select(t)
                    }
                    return
                }
                if (this.tallLayout) {
                    const t = e.getBoundingClientRect().top;
                    if (0 === a && t + window.scrollY > window.pageYOffset) return;
                    window.theme.scrollTo(t), window.theme.closeAllTooltips()
                }
            }
        }
        updateTitleAttr(t) {
            if (t.name) {
                const e = this.productForm ? .querySelector("form");
                e ? .setAttribute("data-variant-title", t.name)
            }
        }
        get productForm() {
            return this.querySelector("product-form")
        }
        get productModal() {
            return document.querySelector(`#ProductModal-${this.dataset.section}`)
        }
        get pickupAvailability() {
            return this.querySelector("pickup-availability")
        }
        get shareButton() {
            return this.querySelector("share-button")
        }
        get variantSelectors() {
            return this.querySelector("variant-selects")
        }
        get relatedProducts() {
            const t = SectionId.getIdForSection(SectionId.parseId(this.sectionId), "related-products");
            return document.querySelector(`product-recommendations[data-section-id^="${t}"]`)
        }
        get quickOrderList() {
            const t = SectionId.getIdForSection(SectionId.parseId(this.sectionId), "quick_order_list");
            return document.querySelector(`quick-order-list[data-id^="${t}"]`)
        }
        get sectionId() {
            return this.dataset.originalSection || this.dataset.section
        }
        productSlider() {
            this.checkSlider(), document.addEventListener("theme:resize:width", this.checkSliderOnResize)
        }
        checkSlider() {
            !this.tallLayout || window.innerWidth < theme.sizes.large ? this.initProductSlider() : this.destroyProductSlider()
        }
        resizeFlickityNav() {
            null !== this.flktyNav && this.flktyNav.resize()
        }
        initProductSlider() {
            const t = this.querySelector("[data-product-single-media-slider]"),
                e = this.querySelector("[data-product-single-media-thumbs]"),
                i = this.querySelectorAll("[data-product-single-media-wrapper]");
            if (i.length > 1 && (this.flkty = new window.theme.Flickity(t, {
                    wrapAround: !0,
                    pageDots: !1,
                    adaptiveHeight: !0,
                    on: {
                        ready: () => {
                            this.slidesAriaHidden(t), i.forEach((t => {
                                if (!t.classList.contains("is-selected")) {
                                    const e = t.querySelectorAll("a, button");
                                    e.length && e.forEach((t => {
                                        t.setAttribute("tabindex", "-1")
                                    }))
                                }
                            }))
                        },
                        dragStart: () => {
                            t.classList.add("is-moving")
                        },
                        dragMove: () => {
                            this.isFlickityDragging = !0
                        },
                        staticClick: () => {
                            this.isFlickityDragging = !1
                        },
                        change: () => {
                            this.slidesAriaHidden(t)
                        },
                        settle: e => {
                            const i = this.flkty.selectedElement.getAttribute("data-media-id");
                            this.flkty.cells.forEach(((t, i) => {
                                const a = t.element.querySelectorAll("a, button");
                                a.length && a.forEach((t => {
                                    t.setAttribute("tabindex", i === e ? "0" : "-1")
                                }))
                            })), this.switchMedia(i), t.classList.remove("is-moving")
                        }
                    }
                }), i.length && i.forEach((t => {
                    t.addEventListener("theme:media:play", (() => {
                        this.flkty.options.draggable = !1, this.flkty.updateDraggable(), t.closest("[data-product-single-media-slider]").classList.add("has-media-active")
                    })), t.addEventListener("theme:media:pause", (() => {
                        this.flkty.options.draggable = !0, this.flkty.updateDraggable(), t.closest("[data-product-single-media-slider]").classList.remove("has-media-active")
                    }))
                })), window.theme.flickitySmoothScrolling(t), null !== e)) {
                this.flktyNav = new window.theme.Flickity(e, {
                    asNavFor: t,
                    contain: !0,
                    pageDots: !1,
                    prevNextButtons: !1,
                    resize: !0,
                    on: {
                        ready: () => {
                            e.setAttribute("tabindex", "-1"), this.slidesAriaHidden(e), requestAnimationFrame(this.flktyNavOnResize)
                        },
                        change: () => {
                            this.slidesAriaHidden(e)
                        }
                    }
                });
                const i = () => {
                    requestAnimationFrame(this.flktyNavOnResize), this.flktyNav.viewport.removeEventListener("transitionend", i)
                };
                null !== this.flktyNav && (document.addEventListener("theme:resize:width", this.flktyNavOnResize), this.flktyNav.viewport.addEventListener("transitionend", i)), window.theme.flickitySmoothScrolling(e);
                const a = this.querySelectorAll(".product-single__thumbnail-link");
                a.length && a.forEach((t => {
                    t.addEventListener("click", (t => {
                        t.preventDefault()
                    }))
                }))
            }
        }
        slidesAriaHidden(t) {
            window.theme.Flickity.data(t).cells.forEach((t => t.element.setAttribute("aria-hidden", "false")))
        }
        destroyProductSlider() {
            null !== this.flkty && (this.flkty.destroy(), this.flktyNav.destroy(), this.flkty = null, this.flktyNav = null)
        }
        initUpsellSlider() {
            const t = this.querySelector("[data-upsell-slider]"),
                e = this.querySelectorAll("[data-upsell-holder]");
            if (e.length > 1) {
                const i = new window.theme.Flickity(t, {
                    wrapAround: !0,
                    pageDots: !0,
                    adaptiveHeight: !0,
                    prevNextButtons: !1,
                    on: {
                        ready: () => {
                            e.forEach((t => {
                                if (!t.classList.contains("is-selected")) {
                                    const e = t.querySelectorAll("a, button");
                                    e.length && e.forEach((t => {
                                        t.setAttribute("tabindex", "-1")
                                    }))
                                }
                            }))
                        }
                    }
                });
                i.on("change", (t => {
                    i.cells.forEach(((e, i) => {
                        const a = e.element.querySelectorAll("a, button");
                        a.length && a.forEach((e => {
                            e.setAttribute("tabindex", i === t ? "0" : "-1")
                        }))
                    }))
                }))
            }
        }
        initFeatureSlider() {
            this.featureSliders.forEach((t => {
                const e = Array.from(t.children);
                if (e.length > 1) {
                    new window.theme.Flickity(t, {
                        wrapAround: !0,
                        pageDots: !0,
                        adaptiveHeight: !0,
                        prevNextButtons: !1,
                        on: {
                            ready: function() {
                                e.forEach((t => {
                                    if (!t.classList.contains("is-selected")) {
                                        const e = t.querySelectorAll("a, button");
                                        e.length && e.forEach((t => {
                                            t.setAttribute("tabindex", "-1")
                                        }))
                                    }
                                }))
                            }
                        }
                    }).on("change", (t => {
                        e.forEach(((e, i) => {
                            const a = e.querySelectorAll("a, button");
                            a.length && a.forEach((e => {
                                e.setAttribute("tabindex", i === t ? "0" : "-1")
                            }))
                        }))
                    }))
                }
            }))
        }
        handleMediaFocus(t) {
            if (t.code !== theme.keyboardKeys.ENTER && t.code !== theme.keyboardKeys.TAB) return;
            const e = t.currentTarget.getAttribute("data-thumbnail-id"),
                i = this.querySelector(`[data-media-id="${e}"]`),
                a = parseInt([...i.parentNode.children].indexOf(i)),
                s = this.querySelector("[data-product-single-media-slider]"),
                n = this.querySelector("[data-product-single-media-thumbs]"),
                r = window.theme.Flickity.data(s) || null,
                o = window.theme.Flickity.data(n) || null;
            r && r.isActive && a > -1 && (t.code === theme.keyboardKeys.ENTER || t.code === theme.keyboardKeys.NUMPADENTER) && r.select(a), o && o.isActive && a > -1 && o.select(a)
        }
        switchMedia(t) {
            const e = document.querySelectorAll("[data-product-single-media-wrapper]"),
                i = this.querySelector(`[data-product-single-media-wrapper][data-media-id="${t}"]`),
                a = !document.body.classList.contains("no-outline");
            e.length && e.forEach((t => {
                t.dispatchEvent(new CustomEvent("theme:media:hidden"), {
                    bubbles: !0
                }), t.classList.add("media--hidden")
            })), a && i.focus(), i.closest("[data-product-single-media-slider]").classList.remove("has-media-active"), i.classList.remove("media--hidden"), i.dispatchEvent(new CustomEvent("theme:media:visible"), {
                bubbles: !0
            });
            const s = i.querySelector("[data-deferred-media]");
            s && "true" !== s.getAttribute("loaded") && i.querySelector("[data-deferred-media-button]").dispatchEvent(new Event("click"))
        }
        hideTooltipOnSlideChange(t) {
            const e = document.querySelector("[data-tooltip-container]");
            if (!e || !e.classList.contains("is-visible")) return;
            const i = this.flkty ? .selectedElement;
            if (!i || !t) return;
            const a = i.offsetHeight,
                s = t.offsetHeight;
            Math.abs(s - a) > 20 && window.theme.closeAllTooltips(!0)
        }
        initMediaSwitch() {
            const t = this.querySelectorAll("[data-thumbnail-id]");
            t.length && t.forEach((t => {
                t.addEventListener("keyup", this.handleMediaFocus.bind(this)), t.addEventListener("click", (t => {
                    t.preventDefault()
                }))
            }))
        }
        initShopifyXrLaunch() {
            document.addEventListener("shopify_xr_launch", (() => {
                this.querySelector("[data-model]:not(.media--hidden)").dispatchEvent(new CustomEvent("xrLaunch"))
            }))
        }
        updateAddToCartState(t) {
            const e = this.querySelectorAll("[data-price-wrapper]"),
                i = this.querySelectorAll("[data-add-to-cart]"),
                a = this.querySelectorAll("[data-form-wrapper]"),
                s = this.querySelector("[data-buy-it-now]"),
                n = this.productState.soldOut;
            e ? .forEach((e => {
                const i = e.querySelector("[data-compare-price]"),
                    a = e.querySelector("[data-product-price]");
                i && (this.productState.onSale ? (i.classList.remove("hidden"), a.classList.add("product__price--sale")) : (i.classList.add("hidden"), a.classList.remove("product__price--sale"))), e.hasAttribute("data-atc-button") || e.classList.toggle("product__price--hidden", !t)
            })), i ? .forEach((t => {
                t.matches("[data-upsell-btn]") || (s ? .classList.remove("hidden"), t.disabled = !1, n && s ? .classList.add("hidden"), t.hasAttribute("data-notification-popup") && this.setNotificationPopup(t))
            })), a ? .forEach((e => {
                const i = e.querySelector("[data-product-select]");
                i && (i.value = t.id), n ? (e.classList.add("variant--soldout"), e.classList.remove("variant--unavailable")) : e.classList.remove("variant--soldout", "variant--unavailable")
            }))
        }
        updateProductPrices(t) {
            if (!(t = t || this.getSelectedVariant(this) || null)) return;
            this.querySelectorAll("[data-price-wrapper]").forEach((e => {
                const i = e.querySelector("[data-compare-price]"),
                    a = e.querySelector("[data-product-price]");
                let s = t.compare_at_price,
                    n = t.price;
                if ((a || i) && e.hasAttribute("data-atc-button")) {
                    const t = this.quantityInput && parseInt(this.quantityInput.value || "1", 10) || 1;
                    n *= t, s *= t
                }
                i && (i.innerHTML = theme.settings.currency_code_enable ? window.theme.formatMoney(s, theme.moneyWithCurrencyFormat) : window.theme.formatMoney(s, theme.moneyFormat)), a && (a.innerHTML = 0 === n ? window.theme.strings.free : theme.settings.currency_code_enable ? window.theme.formatMoney(n, theme.moneyWithCurrencyFormat) : window.theme.formatMoney(n, theme.moneyFormat))
            })), this.hasUnitPricing && this.updateProductUnits(t)
        }
        updateProductUnits(t) {
            let e = null;
            if (t && t.unit_price && (e = t.unit_price), e) {
                const i = this.getBaseUnit(t),
                    a = 0 === e ? window.theme.strings.free : window.theme.formatMoney(e, theme.moneyFormat);
                this.querySelector("[data-product-unit-price]").innerHTML = a, this.querySelector("[data-product-base]").innerHTML = i, this.querySelector("[data-product-unit]").classList.remove("hidden")
            } else this.querySelector("[data-product-unit]").classList.add("hidden")
        }
        getBaseUnit(t) {
            return 1 === t.unit_price_measurement.reference_value ? t.unit_price_measurement.reference_unit : t.unit_price_measurement.reference_value + t.unit_price_measurement.reference_unit
        }
        setQuantityBoundaries() {
            const t = {
                cartQuantity: this.quantityInput.dataset.cartQuantity ? parseInt(this.quantityInput.dataset.cartQuantity) : 0,
                min: this.quantityInput.dataset.min ? parseInt(this.quantityInput.dataset.min) : 1,
                max: this.quantityInput.dataset.max ? parseInt(this.quantityInput.dataset.max) : null,
                step: this.quantityInput.step ? parseInt(this.quantityInput.step) : 1
            };
            let e = t.min;
            const i = null === t.max ? t.max : t.max - t.cartQuantity;
            null !== i && (e = Math.min(e, i)), t.cartQuantity >= t.min && (e = Math.min(e, t.step)), this.quantityInput.min = e, i ? this.quantityInput.max = i : this.quantityInput.removeAttribute("max"), this.quantityInput.value = e;
            const a = this.querySelector("[data-quantity-select]");
            a && (a.innerText = e), publish(theme.PUB_SUB_EVENTS.quantityUpdate, void 0), this.updateProductPrices()
        }
        fetchQuantityRules() {
            const t = this.productForm ? .querySelector('input[name="id"]') ? .value;
            if (t) return fetch(`${this.dataset.url}?variant=${t}&section_id=${this.dataset.section}`).then((t => t.text())).then((t => {
                const e = (new DOMParser).parseFromString(t, "text/html");
                this.updateQuantityRules(this.dataset.section, e)
            })).catch((t => {
                console.warn("Failed to fetch quantity rules:", t)
            }))
        }
        updateQuantityRules(t, e) {
            if (!this.quantityInput) return;
            const i = e.getElementById(`Quantity-Form-${t}`);
            if (!i) return void this.setQuantityBoundaries();
            const a = ["[data-quantity-field]", "[data-quantity-rules]"];
            for (let t of a) {
                const e = this.quantityForm.querySelector(t),
                    a = i.querySelector(t);
                if (e && a)
                    if ("[data-quantity-field]" === t) {
                        const t = ["data-cart-quantity", "data-min", "data-max", "step"];
                        for (let i of t) {
                            const t = a.getAttribute(i);
                            null !== t ? e.setAttribute(i, t) : e.removeAttribute(i)
                        }
                    } else e.innerHTML = a.innerHTML
            }
            this.setQuantityBoundaries()
        }
        checkLiveCartInfo() {
            const t = this.productForm ? .querySelector("[name=id]"),
                e = t ? t.value : null;
            if (!e) return;
            const i = `${theme.routes.root}products/${this.dataset.productHandle}?section_id=api-live-cart-info&variant=${e}`,
                a = this.quantityInput ? parseInt(this.quantityInput.value, 10) : 1;
            fetch(i).then((t => t.text())).then((t => {
                const e = (new DOMParser).parseFromString(t, "text/html"),
                    i = Number(e.querySelector("[data-item-count-for-variant]").innerHTML),
                    s = e.querySelector("[data-max-inventory]").innerHTML,
                    n = Number(s),
                    r = Boolean(a + i > n),
                    o = "" !== s && r,
                    d = "" !== s && i === n ? "form" : "cart",
                    l = this.querySelector("[data-product-form]");
                l && (l.setAttribute("data-max-inventory-reached", o), l.setAttribute("data-error-message-position", d))
            })).catch((t => console.log("error: ", t)))
        }
        setNotificationPopup(t) {
            const e = this.productForm ? .variantIdInput;
            let i = e ? e.value : null;
            if (!i) return;
            let a = !1;
            const s = this.closest("product-info"),
                n = this.sessionStorage.getItem("notification_form_id");
            if (n) {
                const t = n.substring(0, n.lastIndexOf("--")),
                    e = n.split("--").slice(-1)[0];
                a = "NotificationForm--api-notification" === t, a && (i = Number(e))
            }
            t.setAttribute("data-handle", s ? .dataset.productHandle), t.setAttribute("data-variant-id", i), a && (this.scrollToForm(this.closest(".shopify-section")), new r(t))
        }
        scrollToForm(t) {
            const e = document.querySelector("[data-site-header]") ? .dataset.height;
            visibilityHelper.isElementPartiallyVisible(t) || visibilityHelper.isElementTotallyVisible(t) || setTimeout((() => {
                const i = t.getBoundingClientRect().top - e;
                window.scrollTo({
                    top: i,
                    left: 0,
                    behavior: "smooth"
                })
            }), 400)
        }
        disconnectedCallback() {
            this.hasVariantOptionWithImage && window.removeEventListener("theme:resize:width", this.onResizeCallback), null !== this.flktyNav && document.removeEventListener("theme:resize:width", this.flktyNavOnResize), document.removeEventListener("theme:resize:width", this.checkSliderOnResize), this.onVariantChangeUnsubscriber(), this.cartUpdateUnsubscriber ? .(), document.removeEventListener("theme:cart:close", this.checkLiveCartInfoCallback)
        }
    }), customElements.get("product-model") || customElements.define("product-model", a)
}();