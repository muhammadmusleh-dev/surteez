! function() {
    "use strict";
    customElements.get("footer-effect") || customElements.define("footer-effect", class e extends HTMLElement {
        static activeInstance = null;
        constructor() {
            super(), this.container = this.closest("footer"), this.parentContainer = this.container ? .parentElement, this.main = document.querySelector("[data-main]"), this.parallaxElement = this.container ? .querySelector("parallax-element"), this.wavyEnabled = this.hasAttribute("data-parallax-wavy"), this.roundedEnabled = this.getSettingFromParallax("data-parallax-rounded-corners"), this.roundedLargeEnabled = this.getSettingFromParallax("data-parallax-rounded-corners-large"), this.isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent) && this.getSettingFromParallax("data-parallax-disable-on-safari"), this.resizeEvent = () => this.handleResize(), this.currentWaveElement = null, this.targetSection = null, this.isActive = !1
        }
        getSettingFromParallax(e) {
            return this.parallaxElement ? .hasAttribute(e) ? this.parallaxElement.hasAttribute(e) : this.hasAttribute(e)
        }
        connectedCallback() {
            requestIdleCallback((() => {
                this.evaluateActivation()
            }))
        }
        evaluateActivation() {
            const t = this.getAllFooterEffects(),
                a = e.activeInstance,
                s = t.indexOf(this),
                i = a ? t.indexOf(a) : -1;
            (!a || -1 !== s && s < i) && this.becomeActive()
        }
        getAllFooterEffects() {
            return Array.from(document.querySelectorAll("footer-effect"))
        }
        becomeActive() {
            e.activeInstance && e.activeInstance !== this && e.activeInstance.becomePassive(), e.activeInstance = this, this.isActive = !0, this.init(), document.addEventListener("theme:resize", this.resizeEvent)
        }
        becomePassive() {
            this.isActive && (this.isActive = !1, this.cleanup(), document.removeEventListener("theme:resize", this.resizeEvent), e.activeInstance === this && (e.activeInstance = null))
        }
        disconnectedCallback() {
            const e = this.isActive;
            this.becomePassive(), e && this.handoverToNextFooter()
        }
        handoverToNextFooter() {
            setTimeout((() => {
                const t = this.getAllFooterEffects();
                t.length > 0 && !e.activeInstance && t[0].becomeActive()
            }), 10)
        }
        init() {
            this.shouldStopParallax() ? this.removeFooterEffect() : this.applyFooterEffect()
        }
        shouldStopParallax() {
            return Math.round(Math.max(document.documentElement.clientHeight, window.innerHeight || 0)) < (this.container ? .clientHeight || 0) + (this.wavyEnabled ? 50 : 0) || window.innerWidth < theme.sizes.small || this.isSafari
        }
        findPreviousSection() {
            if (!this.container) return null;
            let e = this.container.closest(".shopify-section") ? .previousElementSibling;
            return !e || e.classList.contains("shopify-section") || e.classList.contains("main-content") || (e = this.main), e
        }
        applyFooterEffect() {
            const e = this.findPreviousSection();
            if (!e) return;
            this.targetSection = e;
            const t = getComputedStyle(this.container).getPropertyValue("--bg");
            e.style.setProperty("--footer-bg", t), this.parentContainer.style.setProperty("--footer-parallax-height", "auto"), this.wavyEnabled ? this.applyWavyEffect(e) : this.applyNonWavyEffect(e), this.main.classList.add("main-content--parallax"), this.parentContainer.classList.add("section-footer--parallax"), this.parentContainer.style.setProperty("--footer-parallax-height", `${this.container.clientHeight}px`)
        }
        applyWavyEffect(e) {
            this.removeExistingWaves(e);
            const t = this.container ? .querySelector(":scope > [data-wave]");
            t && (this.currentWaveElement = t.cloneNode(!0), e.append(this.currentWaveElement), e.classList.add("wavy"), this.container ? .classList.remove("wavy"))
        }
        applyNonWavyEffect(e) {
            this.roundedEnabled ? (e.classList.add("parallax-rounded-corners", "parallax-shadow"), this.roundedLargeEnabled && document.body.classList.add("body--rounded-corners-large")) : e.classList.add("parallax-shadow")
        }
        removeFooterEffect() {
            this.targetSection && this.cleanupSection(this.targetSection), this.cleanupAllFooterEffects(), this.wavyEnabled && this.container ? .classList.add("wavy"), this.main.classList.remove("main-content--parallax"), this.parentContainer.classList.remove("section-footer--parallax"), this.parentContainer.style.setProperty("--footer-parallax-height", "auto")
        }
        cleanupSection(e) {
            e && (e.classList.remove("wavy", "parallax-shadow", "parallax-rounded-corners"), this.removeExistingWaves(e), e.style.removeProperty("--footer-bg"), document.body.classList.remove("body--rounded-corners-large"))
        }
        removeExistingWaves(e) {
            e.querySelectorAll(":scope > [data-wave]").forEach((e => e.remove()))
        }
        cleanupAllFooterEffects() {
            document.querySelectorAll(".wavy:not(.site-footer)").forEach((e => {
                e.classList.remove("wavy"), this.removeExistingWaves(e)
            }));
            document.querySelectorAll(".parallax-shadow:not(.site-footer)").forEach((e => {
                e.classList.remove("parallax-shadow", "parallax-rounded-corners"), this.removeExistingWaves(e), e.style.removeProperty("--footer-bg")
            })), document.body.classList.remove("body--rounded-corners-large")
        }
        handleResize() {
            clearTimeout(this.resizeTimer), this.resizeTimer = setTimeout((() => {
                this.shouldStopParallax() ? this.removeFooterEffect() : this.targetSection && this.isEffectActive() || this.applyFooterEffect()
            }), 150)
        }
        isEffectActive() {
            return !!this.targetSection && (this.wavyEnabled ? this.targetSection.classList.contains("wavy") && this.targetSection.querySelector(":scope > [data-wave]") : this.targetSection.classList.contains("parallax-shadow"))
        }
        cleanup() {
            this.removeFooterEffect(), this.currentWaveElement = null, this.targetSection = null, clearTimeout(this.resizeTimer)
        }
        refresh() {
            this.cleanup(), this.init()
        }
    })
}();