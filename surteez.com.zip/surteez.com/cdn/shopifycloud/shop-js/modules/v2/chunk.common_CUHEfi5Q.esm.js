const e = "show_sign_in_toast",
    t = "undefined" == typeof document ? {
        activeElement: null,
        addEventListener: () => {},
        appendChild: () => {},
        body: {},
        cookie: "",
        createElement: () => {},
        createTextNode: () => {},
        documentElement: {
            clientHeight: 0,
            clientWidth: 0,
            lang: "",
            style: {
                overflow: "",
                removeProperty: () => {}
            }
        },
        getElementById: () => null,
        head: {
            appendChild: () => {}
        },
        location: void 0,
        querySelector: () => {},
        querySelectorAll: () => [],
        removeEventListener: () => {},
        styleSheets: {}
    } : document,
    n = [];
for (let e = 0; e < 256; ++e) n.push((e + 256).toString(16).slice(1));
let o;
const r = new Uint8Array(16);
var i = {
    randomUUID: "undefined" != typeof crypto && crypto.randomUUID && crypto.randomUUID.bind(crypto)
};

function a(e, t, a) {
    if (i.randomUUID && !t && !e) return i.randomUUID();
    const s = (e = e || {}).random ? ? e.rng ? .() ? ? function() {
        if (!o) {
            if ("undefined" == typeof crypto || !crypto.getRandomValues) throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
            o = crypto.getRandomValues.bind(crypto)
        }
        return o(r)
    }();
    if (s.length < 16) throw new Error("Random bytes length must be >= 16");
    return s[6] = 15 & s[6] | 64, s[8] = 63 & s[8] | 128,
        function(e, t = 0) {
            return (n[e[t + 0]] + n[e[t + 1]] + n[e[t + 2]] + n[e[t + 3]] + "-" + n[e[t + 4]] + n[e[t + 5]] + "-" + n[e[t + 6]] + n[e[t + 7]] + "-" + n[e[t + 8]] + n[e[t + 9]] + "-" + n[e[t + 10]] + n[e[t + 11]] + n[e[t + 12]] + n[e[t + 13]] + n[e[t + 14]] + n[e[t + 15]]).toLowerCase()
        }(s)
}
const s = {
        addEventListener: () => {},
        analytics: {},
        btoa: () => "",
        clearTimeout: () => {},
        CSS: {
            supports: (e, t) => !1
        },
        customElements: {},
        devicePixelRatio: 1,
        getComputedStyle: e => ({}),
        HTMLElement: {},
        innerHeight: 0,
        innerWidth: 0,
        localStorage: {
            getItem() {
                throw new Error("localStorage is not available")
            },
            setItem() {
                throw new Error("localStorage is not available")
            },
            removeItem() {
                throw new Error("localStorage is not available")
            }
        },
        sessionStorage: {
            getItem() {
                throw new Error("sessionStorage is not available")
            },
            setItem() {
                throw new Error("sessionStorage is not available")
            },
            removeItem() {
                throw new Error("sessionStorage is not available")
            }
        },
        location: {
            assign: () => {},
            hostname: "",
            href: "",
            origin: "",
            pathname: "",
            search: ""
        },
        matchMedia: () => ({
            matches: !1
        }),
        open: () => {},
        PublicKeyCredential: {
            isConditionalMediationAvailable: () => Promise.resolve(!1)
        },
        removeEventListener: () => {},
        ResizeObserver: void 0,
        screen: {
            availWidth: 0,
            height: 0,
            orientation: {
                type: ""
            },
            width: 0
        },
        screenLeft: 0,
        screenTop: 0,
        screenX: 0,
        screenY: 0,
        scrollTo: () => {},
        setTimeout: () => 0,
        Shopify: {},
        ShopifyAnalytics: {},
        top: {
            addEventListener: () => {},
            removeEventListener: () => {}
        },
        trekkie: {},
        URL: URL,
        visualViewport: {}
    },
    l = "undefined" == typeof window ? s : window;

function c(e) {
    const t = e ? "sessionStorage" : "localStorage";
    try {
        const e = l[t],
            n = "__storage_test__";
        return e.setItem(n, n), e.removeItem(n), !0
    } catch (e) {
        return !1
    }
}

function d(e, t, {
    session: n
} = {}) {
    if (!c(n)) return !1;
    return l[n ? "sessionStorage" : "localStorage"].setItem(e, t), !0
}

function u(e, {
    session: t
} = {}) {
    if (!c(t)) return null;
    return l[t ? "sessionStorage" : "localStorage"].getItem(e)
}
const p = "signInWithShop";

function h(e) {
    try {
        return JSON.parse(u(`${p}:${e}`, {
            session: !0
        }))
    } catch (e) {
        return null
    }
}

function f(e) {
    return Object.assign(Object.assign({}, e), {
        id: a()
    })
}

function m(e, t) {
    let n = t;
    t && (n = f(t)), d(`${p}:${e}`, JSON.stringify(n), {
        session: !0
    })
}

function g(e) {
    var t, n, o;
    null === (o = null === (n = null === (t = null == l ? void 0 : l.Shopify) || void 0 === t ? void 0 : t.SignInWithShop) || void 0 === n ? void 0 : n.renderToast) || void 0 === o || o.call(n, f(e))
}

function v(e, t) {
    var n = {};
    for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && t.indexOf(o) < 0 && (n[o] = e[o]);
    if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
        var r = 0;
        for (o = Object.getOwnPropertySymbols(e); r < o.length; r++) t.indexOf(o[r]) < 0 && Object.prototype.propertyIsEnumerable.call(e, o[r]) && (n[o[r]] = e[o[r]])
    }
    return n
}

function _(e, t, n, o) {
    return new(n || (n = Promise))((function(r, i) {
        function a(e) {
            try {
                l(o.next(e))
            } catch (e) {
                i(e)
            }
        }

        function s(e) {
            try {
                l(o.throw(e))
            } catch (e) {
                i(e)
            }
        }

        function l(e) {
            var t;
            e.done ? r(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                e(t)
            }))).then(a, s)
        }
        l((o = o.apply(e, t || [])).next())
    }))
}

function y(e, t, n, o) {
    if ("a" === n && !o) throw new TypeError("Private accessor was defined without a getter");
    if ("function" == typeof t ? e !== t || !o : !t.has(e)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return "m" === n ? o : "a" === n ? o.call(e) : o ? o.value : t.get(e)
}

function w(e, t, n, o, r) {
    if ("m" === o) throw new TypeError("Private method is not writable");
    if ("a" === o && !r) throw new TypeError("Private accessor was defined without a setter");
    if ("function" == typeof t ? e !== t || !r : !t.has(e)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return "a" === o ? r.call(e, n) : r ? r.value = n : t.set(e, n), n
}
"function" == typeof SuppressedError && SuppressedError;
var b, x, k, E, S, C, P, M, O, T, I, j, A = {},
    N = [],
    L = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,
    U = Array.isArray;

function D(e, t) {
    for (var n in t) e[n] = t[n];
    return e
}

function R(e) {
    e && e.parentNode && e.parentNode.removeChild(e)
}

function z(e, t, n) {
    var o, r, i, a = {};
    for (i in t) "key" == i ? o = t[i] : "ref" == i ? r = t[i] : a[i] = t[i];
    if (arguments.length > 2 && (a.children = arguments.length > 3 ? b.call(arguments, 2) : n), "function" == typeof e && null != e.defaultProps)
        for (i in e.defaultProps) null == a[i] && (a[i] = e.defaultProps[i]);
    return $(e, a, o, r, null)
}

function $(e, t, n, o, r) {
    var i = {
        type: e,
        props: t,
        key: n,
        ref: o,
        __k: null,
        __: null,
        __b: 0,
        __e: null,
        __c: null,
        constructor: void 0,
        __v: null == r ? ++k : r,
        __i: -1,
        __u: 0
    };
    return null == r && null != x.vnode && x.vnode(i), i
}

function F(e) {
    return e.children
}

function B(e, t) {
    this.props = e, this.context = t
}

function H(e, t) {
    if (null == t) return e.__ ? H(e.__, e.__i + 1) : null;
    for (var n; t < e.__k.length; t++)
        if (null != (n = e.__k[t]) && null != n.__e) return n.__e;
    return "function" == typeof e.type ? H(e) : null
}

function V(e) {
    var t, n;
    if (null != (e = e.__) && null != e.__c) {
        for (e.__e = e.__c.base = null, t = 0; t < e.__k.length; t++)
            if (null != (n = e.__k[t]) && null != n.__e) {
                e.__e = e.__c.base = n.__e;
                break
            }
        return V(e)
    }
}

function W(e) {
    (!e.__d && (e.__d = !0) && E.push(e) && !q.__r++ || S != x.debounceRendering) && ((S = x.debounceRendering) || C)(q)
}

function q() {
    for (var e, t, n, o, r, i, a, s = 1; E.length;) E.length > s && E.sort(P), e = E.shift(), s = E.length, e.__d && (n = void 0, r = (o = (t = e).__v).__e, i = [], a = [], t.__P && ((n = D({}, o)).__v = o.__v + 1, x.vnode && x.vnode(n), ee(t.__P, n, o, t.__n, t.__P.namespaceURI, 32 & o.__u ? [r] : null, i, null == r ? H(o) : r, !!(32 & o.__u), a), n.__v = o.__v, n.__.__k[n.__i] = n, te(i, n, a), n.__e != r && V(n)));
    q.__r = 0
}

function K(e, t, n, o, r, i, a, s, l, c, d) {
    var u, p, h, f, m, g, v = o && o.__k || N,
        _ = t.length;
    for (l = function(e, t, n, o, r) {
            var i, a, s, l, c, d = n.length,
                u = d,
                p = 0;
            for (e.__k = new Array(r), i = 0; i < r; i++) null != (a = t[i]) && "boolean" != typeof a && "function" != typeof a ? (l = i + p, (a = e.__k[i] = "string" == typeof a || "number" == typeof a || "bigint" == typeof a || a.constructor == String ? $(null, a, null, null, null) : U(a) ? $(F, {
                children: a
            }, null, null, null) : null == a.constructor && a.__b > 0 ? $(a.type, a.props, a.key, a.ref ? a.ref : null, a.__v) : a).__ = e, a.__b = e.__b + 1, s = null, -1 != (c = a.__i = G(a, n, l, u)) && (u--, (s = n[c]) && (s.__u |= 2)), null == s || null == s.__v ? (-1 == c && (r > d ? p-- : r < d && p++), "function" != typeof a.type && (a.__u |= 4)) : c != l && (c == l - 1 ? p-- : c == l + 1 ? p++ : (c > l ? p-- : p++, a.__u |= 4))) : e.__k[i] = null;
            if (u)
                for (i = 0; i < d; i++) null != (s = n[i]) && !(2 & s.__u) && (s.__e == o && (o = H(s)), ie(s, s));
            return o
        }(n, t, v, l, _), u = 0; u < _; u++) null != (h = n.__k[u]) && (p = -1 == h.__i ? A : v[h.__i] || A, h.__i = u, g = ee(e, h, p, r, i, a, s, l, c, d), f = h.__e, h.ref && p.ref != h.ref && (p.ref && re(p.ref, null, h), d.push(h.ref, h.__c || f, h)), null == m && null != f && (m = f), 4 & h.__u || p.__k === h.__k ? l = X(h, l, e) : "function" == typeof h.type && void 0 !== g ? l = g : f && (l = f.nextSibling), h.__u &= -7);
    return n.__e = m, l
}

function X(e, t, n) {
    var o, r;
    if ("function" == typeof e.type) {
        for (o = e.__k, r = 0; o && r < o.length; r++) o[r] && (o[r].__ = e, t = X(o[r], t, n));
        return t
    }
    e.__e != t && (t && e.type && !n.contains(t) && (t = H(e)), n.insertBefore(e.__e, t || null), t = e.__e);
    do {
        t = t && t.nextSibling
    } while (null != t && 8 == t.nodeType);
    return t
}

function Y(e, t) {
    return t = t || [], null == e || "boolean" == typeof e || (U(e) ? e.some((function(e) {
        Y(e, t)
    })) : t.push(e)), t
}

function G(e, t, n, o) {
    var r, i, a = e.key,
        s = e.type,
        l = t[n];
    if (null === l && null == e.key || l && a == l.key && s == l.type && !(2 & l.__u)) return n;
    if (o > (null == l || 2 & l.__u ? 0 : 1))
        for (r = n - 1, i = n + 1; r >= 0 || i < t.length;) {
            if (r >= 0) {
                if ((l = t[r]) && !(2 & l.__u) && a == l.key && s == l.type) return r;
                r--
            }
            if (i < t.length) {
                if ((l = t[i]) && !(2 & l.__u) && a == l.key && s == l.type) return i;
                i++
            }
        }
    return -1
}

function J(e, t, n) {
    "-" == t[0] ? e.setProperty(t, null == n ? "" : n) : e[t] = null == n ? "" : "number" != typeof n || L.test(t) ? n : n + "px"
}

function Z(e, t, n, o, r) {
    var i;
    e: if ("style" == t)
        if ("string" == typeof n) e.style.cssText = n;
        else {
            if ("string" == typeof o && (e.style.cssText = o = ""), o)
                for (t in o) n && t in n || J(e.style, t, "");
            if (n)
                for (t in n) o && n[t] == o[t] || J(e.style, t, n[t])
        }
    else if ("o" == t[0] && "n" == t[1]) i = t != (t = t.replace(M, "$1")), t = t.toLowerCase() in e || "onFocusOut" == t || "onFocusIn" == t ? t.toLowerCase().slice(2) : t.slice(2), e.l || (e.l = {}), e.l[t + i] = n, n ? o ? n.u = o.u : (n.u = O, e.addEventListener(t, i ? I : T, i)) : e.removeEventListener(t, i ? I : T, i);
    else {
        if ("http://www.w3.org/2000/svg" == r) t = t.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
        else if ("width" != t && "height" != t && "href" != t && "list" != t && "form" != t && "tabIndex" != t && "download" != t && "rowSpan" != t && "colSpan" != t && "role" != t && "popover" != t && t in e) try {
            e[t] = null == n ? "" : n;
            break e
        } catch (e) {}
        "function" == typeof n || (null == n || !1 === n && "-" != t[4] ? e.removeAttribute(t) : e.setAttribute(t, "popover" == t && 1 == n ? "" : n))
    }
}

function Q(e) {
    return function(t) {
        if (this.l) {
            var n = this.l[t.type + e];
            if (null == t.t) t.t = O++;
            else if (t.t < n.u) return;
            return n(x.event ? x.event(t) : t)
        }
    }
}

function ee(e, t, n, o, r, i, a, s, l, c) {
    var d, u, p, h, f, m, g, v, _, y, w, b, k, E, S, C, P, M = t.type;
    if (null != t.constructor) return null;
    128 & n.__u && (l = !!(32 & n.__u), i = [s = t.__e = n.__e]), (d = x.__b) && d(t);
    e: if ("function" == typeof M) try {
        if (v = t.props, _ = "prototype" in M && M.prototype.render, y = (d = M.contextType) && o[d.__c], w = d ? y ? y.props.value : d.__ : o, n.__c ? g = (u = t.__c = n.__c).__ = u.__E : (_ ? t.__c = u = new M(v, w) : (t.__c = u = new B(v, w), u.constructor = M, u.render = ae), y && y.sub(u), u.props = v, u.state || (u.state = {}), u.context = w, u.__n = o, p = u.__d = !0, u.__h = [], u._sb = []), _ && null == u.__s && (u.__s = u.state), _ && null != M.getDerivedStateFromProps && (u.__s == u.state && (u.__s = D({}, u.__s)), D(u.__s, M.getDerivedStateFromProps(v, u.__s))), h = u.props, f = u.state, u.__v = t, p) _ && null == M.getDerivedStateFromProps && null != u.componentWillMount && u.componentWillMount(), _ && null != u.componentDidMount && u.__h.push(u.componentDidMount);
        else {
            if (_ && null == M.getDerivedStateFromProps && v !== h && null != u.componentWillReceiveProps && u.componentWillReceiveProps(v, w), !u.__e && null != u.shouldComponentUpdate && !1 === u.shouldComponentUpdate(v, u.__s, w) || t.__v == n.__v) {
                for (t.__v != n.__v && (u.props = v, u.state = u.__s, u.__d = !1), t.__e = n.__e, t.__k = n.__k, t.__k.some((function(e) {
                        e && (e.__ = t)
                    })), b = 0; b < u._sb.length; b++) u.__h.push(u._sb[b]);
                u._sb = [], u.__h.length && a.push(u);
                break e
            }
            null != u.componentWillUpdate && u.componentWillUpdate(v, u.__s, w), _ && null != u.componentDidUpdate && u.__h.push((function() {
                u.componentDidUpdate(h, f, m)
            }))
        }
        if (u.context = w, u.props = v, u.__P = e, u.__e = !1, k = x.__r, E = 0, _) {
            for (u.state = u.__s, u.__d = !1, k && k(t), d = u.render(u.props, u.state, u.context), S = 0; S < u._sb.length; S++) u.__h.push(u._sb[S]);
            u._sb = []
        } else
            do {
                u.__d = !1, k && k(t), d = u.render(u.props, u.state, u.context), u.state = u.__s
            } while (u.__d && ++E < 25);
        u.state = u.__s, null != u.getChildContext && (o = D(D({}, o), u.getChildContext())), _ && !p && null != u.getSnapshotBeforeUpdate && (m = u.getSnapshotBeforeUpdate(h, f)), C = d, null != d && d.type === F && null == d.key && (C = ne(d.props.children)), s = K(e, U(C) ? C : [C], t, n, o, r, i, a, s, l, c), u.base = t.__e, t.__u &= -161, u.__h.length && a.push(u), g && (u.__E = u.__ = null)
    } catch (e) {
        if (t.__v = null, l || null != i)
            if (e.then) {
                for (t.__u |= l ? 160 : 128; s && 8 == s.nodeType && s.nextSibling;) s = s.nextSibling;
                i[i.indexOf(s)] = null, t.__e = s
            } else
                for (P = i.length; P--;) R(i[P]);
        else t.__e = n.__e, t.__k = n.__k;
        x.__e(e, t, n)
    } else null == i && t.__v == n.__v ? (t.__k = n.__k, t.__e = n.__e) : s = t.__e = oe(n.__e, t, n, o, r, i, a, l, c);
    return (d = x.diffed) && d(t), 128 & t.__u ? void 0 : s
}

function te(e, t, n) {
    for (var o = 0; o < n.length; o++) re(n[o], n[++o], n[++o]);
    x.__c && x.__c(t, e), e.some((function(t) {
        try {
            e = t.__h, t.__h = [], e.some((function(e) {
                e.call(t)
            }))
        } catch (e) {
            x.__e(e, t.__v)
        }
    }))
}

function ne(e) {
    return "object" != typeof e || null == e || e.__b && e.__b > 0 ? e : U(e) ? e.map(ne) : D({}, e)
}

function oe(e, t, n, o, r, i, a, s, l) {
    var c, d, u, p, h, f, m, g = n.props,
        v = t.props,
        _ = t.type;
    if ("svg" == _ ? r = "http://www.w3.org/2000/svg" : "math" == _ ? r = "http://www.w3.org/1998/Math/MathML" : r || (r = "http://www.w3.org/1999/xhtml"), null != i)
        for (c = 0; c < i.length; c++)
            if ((h = i[c]) && "setAttribute" in h == !!_ && (_ ? h.localName == _ : 3 == h.nodeType)) {
                e = h, i[c] = null;
                break
            }
    if (null == e) {
        if (null == _) return document.createTextNode(v);
        e = document.createElementNS(r, _, v.is && v), s && (x.__m && x.__m(t, i), s = !1), i = null
    }
    if (null == _) g === v || s && e.data == v || (e.data = v);
    else {
        if (i = i && b.call(e.childNodes), g = n.props || A, !s && null != i)
            for (g = {}, c = 0; c < e.attributes.length; c++) g[(h = e.attributes[c]).name] = h.value;
        for (c in g)
            if (h = g[c], "children" == c);
            else if ("dangerouslySetInnerHTML" == c) u = h;
        else if (!(c in v)) {
            if ("value" == c && "defaultValue" in v || "checked" == c && "defaultChecked" in v) continue;
            Z(e, c, null, h, r)
        }
        for (c in v) h = v[c], "children" == c ? p = h : "dangerouslySetInnerHTML" == c ? d = h : "value" == c ? f = h : "checked" == c ? m = h : s && "function" != typeof h || g[c] === h || Z(e, c, h, g[c], r);
        if (d) s || u && (d.__html == u.__html || d.__html == e.innerHTML) || (e.innerHTML = d.__html), t.__k = [];
        else if (u && (e.innerHTML = ""), K("template" == t.type ? e.content : e, U(p) ? p : [p], t, n, o, "foreignObject" == _ ? "http://www.w3.org/1999/xhtml" : r, i, a, i ? i[0] : n.__k && H(n, 0), s, l), null != i)
            for (c = i.length; c--;) R(i[c]);
        s || (c = "value", "progress" == _ && null == f ? e.removeAttribute("value") : null != f && (f !== e[c] || "progress" == _ && !f || "option" == _ && f != g[c]) && Z(e, c, f, g[c], r), c = "checked", null != m && m != e[c] && Z(e, c, m, g[c], r))
    }
    return e
}

function re(e, t, n) {
    try {
        if ("function" == typeof e) {
            var o = "function" == typeof e.__u;
            o && e.__u(), o && null == t || (e.__u = e(t))
        } else e.current = t
    } catch (e) {
        x.__e(e, n)
    }
}

function ie(e, t, n) {
    var o, r;
    if (x.unmount && x.unmount(e), (o = e.ref) && (o.current && o.current != e.__e || re(o, null, t)), null != (o = e.__c)) {
        if (o.componentWillUnmount) try {
            o.componentWillUnmount()
        } catch (e) {
            x.__e(e, t)
        }
        o.base = o.__P = null
    }
    if (o = e.__k)
        for (r = 0; r < o.length; r++) o[r] && ie(o[r], t, n || "function" != typeof e.type);
    n || R(e.__e), e.__c = e.__ = e.__e = void 0
}

function ae(e, t, n) {
    return this.constructor(e, n)
}

function se(e, t, n) {
    var o, r, i, a;
    t == document && (t = document.documentElement), x.__ && x.__(e, t), r = (o = "function" == typeof n) ? null : t.__k, i = [], a = [], ee(t, e = (!o && n || t).__k = z(F, null, [e]), r || A, A, t.namespaceURI, !o && n ? [n] : r ? null : t.firstChild ? b.call(t.childNodes) : null, i, !o && n ? n : r ? r.__e : t.firstChild, o, a), te(i, e, a)
}

function le(e, t, n) {
    var o, r, i, a, s = D({}, e.props);
    for (i in e.type && e.type.defaultProps && (a = e.type.defaultProps), t) "key" == i ? o = t[i] : "ref" == i ? r = t[i] : s[i] = null == t[i] && null != a ? a[i] : t[i];
    return arguments.length > 2 && (s.children = arguments.length > 3 ? b.call(arguments, 2) : n), $(e.type, s, o || e.key, r || e.ref, null)
}

function ce(e) {
    function t(e) {
        var n, o;
        return this.getChildContext || (n = new Set, (o = {})[t.__c] = this, this.getChildContext = function() {
            return o
        }, this.componentWillUnmount = function() {
            n = null
        }, this.shouldComponentUpdate = function(e) {
            this.props.value != e.value && n.forEach((function(e) {
                e.__e = !0, W(e)
            }))
        }, this.sub = function(e) {
            n.add(e);
            var t = e.componentWillUnmount;
            e.componentWillUnmount = function() {
                n && n.delete(e), t && t.call(e)
            }
        }), e.children
    }
    return t.__c = "__cC" + j++, t.__ = e, t.Provider = t.__l = (t.Consumer = function(e, t) {
        return e.children(t)
    }).contextType = t, t
}
b = N.slice, x = {
    __e: function(e, t, n, o) {
        for (var r, i, a; t = t.__;)
            if ((r = t.__c) && !r.__) try {
                if ((i = r.constructor) && null != i.getDerivedStateFromError && (r.setState(i.getDerivedStateFromError(e)), a = r.__d), null != r.componentDidCatch && (r.componentDidCatch(e, o || {}), a = r.__d), a) return r.__E = r
            } catch (t) {
                e = t
            }
        throw e
    }
}, k = 0, B.prototype.setState = function(e, t) {
    var n;
    n = null != this.__s && this.__s != this.state ? this.__s : this.__s = D({}, this.state), "function" == typeof e && (e = e(D({}, n), this.props)), e && D(n, e), null != e && this.__v && (t && this._sb.push(t), W(this))
}, B.prototype.forceUpdate = function(e) {
    this.__v && (this.__e = !0, e && this.__h.push(e), W(this))
}, B.prototype.render = F, E = [], C = "function" == typeof Promise ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, P = function(e, t) {
    return e.__v.__b - t.__v.__b
}, q.__r = 0, M = /(PointerCapture)$|Capture$/i, O = 0, T = Q(!1), I = Q(!0), j = 0;
var de = 0;

function ue(e, t, n, o, r, i) {
    t || (t = {});
    var a, s, l = t;
    if ("ref" in l)
        for (s in l = {}, t) "ref" == s ? a = t[s] : l[s] = t[s];
    var c = {
        type: e,
        props: l,
        key: n,
        ref: a,
        __k: null,
        __: null,
        __b: 0,
        __e: null,
        __c: null,
        constructor: void 0,
        __v: --de,
        __i: -1,
        __u: 0,
        __source: r,
        __self: i
    };
    if ("function" == typeof e && (a = e.defaultProps))
        for (s in a) void 0 === l[s] && (l[s] = a[s]);
    return x.vnode && x.vnode(c), c
}
var pe, he, fe, me, ge = 0,
    ve = [],
    _e = x,
    ye = _e.__b,
    we = _e.__r,
    be = _e.diffed,
    xe = _e.__c,
    ke = _e.unmount,
    Ee = _e.__;

function Se(e, t) {
    _e.__h && _e.__h(he, e, ge || t), ge = 0;
    var n = he.__H || (he.__H = {
        __: [],
        __h: []
    });
    return e >= n.__.length && n.__.push({}), n.__[e]
}

function Ce(e) {
    return ge = 1, Pe(Fe, e)
}

function Pe(e, t, n) {
    var o = Se(pe++, 2);
    if (o.t = e, !o.__c && (o.__ = [n ? n(t) : Fe(void 0, t), function(e) {
            var t = o.__N ? o.__N[0] : o.__[0],
                n = o.t(t, e);
            t !== n && (o.__N = [n, o.__[1]], o.__c.setState({}))
        }], o.__c = he, !he.__f)) {
        var r = function(e, t, n) {
            if (!o.__c.__H) return !0;
            var r = o.__c.__H.__.filter((function(e) {
                return !!e.__c
            }));
            if (r.every((function(e) {
                    return !e.__N
                }))) return !i || i.call(this, e, t, n);
            var a = o.__c.props !== e;
            return r.forEach((function(e) {
                if (e.__N) {
                    var t = e.__[0];
                    e.__ = e.__N, e.__N = void 0, t !== e.__[0] && (a = !0)
                }
            })), i && i.call(this, e, t, n) || a
        };
        he.__f = !0;
        var i = he.shouldComponentUpdate,
            a = he.componentWillUpdate;
        he.componentWillUpdate = function(e, t, n) {
            if (this.__e) {
                var o = i;
                i = void 0, r(e, t, n), i = o
            }
            a && a.call(this, e, t, n)
        }, he.shouldComponentUpdate = r
    }
    return o.__N || o.__
}

function Me(e, t) {
    var n = Se(pe++, 3);
    !_e.__s && $e(n.__H, t) && (n.__ = e, n.u = t, he.__H.__h.push(n))
}

function Oe(e, t) {
    var n = Se(pe++, 4);
    !_e.__s && $e(n.__H, t) && (n.__ = e, n.u = t, he.__h.push(n))
}

function Te(e) {
    return ge = 5, je((function() {
        return {
            current: e
        }
    }), [])
}

function Ie(e, t, n) {
    ge = 6, Oe((function() {
        if ("function" == typeof e) {
            var n = e(t());
            return function() {
                e(null), n && "function" == typeof n && n()
            }
        }
        if (e) return e.current = t(),
            function() {
                return e.current = null
            }
    }), null == n ? n : n.concat(e))
}

function je(e, t) {
    var n = Se(pe++, 7);
    return $e(n.__H, t) && (n.__ = e(), n.__H = t, n.__h = e), n.__
}

function Ae(e, t) {
    return ge = 8, je((function() {
        return e
    }), t)
}

function Ne(e) {
    var t = he.context[e.__c],
        n = Se(pe++, 9);
    return n.c = e, t ? (null == n.__ && (n.__ = !0, t.sub(he)), t.props.value) : e.__
}

function Le() {
    for (var e; e = ve.shift();)
        if (e.__P && e.__H) try {
            e.__H.__h.forEach(Re), e.__H.__h.forEach(ze), e.__H.__h = []
        } catch (t) {
            e.__H.__h = [], _e.__e(t, e.__v)
        }
}
_e.__b = function(e) {
    he = null, ye && ye(e)
}, _e.__ = function(e, t) {
    e && t.__k && t.__k.__m && (e.__m = t.__k.__m), Ee && Ee(e, t)
}, _e.__r = function(e) {
    we && we(e), pe = 0;
    var t = (he = e.__c).__H;
    t && (fe === he ? (t.__h = [], he.__h = [], t.__.forEach((function(e) {
        e.__N && (e.__ = e.__N), e.u = e.__N = void 0
    }))) : (t.__h.forEach(Re), t.__h.forEach(ze), t.__h = [], pe = 0)), fe = he
}, _e.diffed = function(e) {
    be && be(e);
    var t = e.__c;
    t && t.__H && (t.__H.__h.length && (1 !== ve.push(t) && me === _e.requestAnimationFrame || ((me = _e.requestAnimationFrame) || De)(Le)), t.__H.__.forEach((function(e) {
        e.u && (e.__H = e.u), e.u = void 0
    }))), fe = he = null
}, _e.__c = function(e, t) {
    t.some((function(e) {
        try {
            e.__h.forEach(Re), e.__h = e.__h.filter((function(e) {
                return !e.__ || ze(e)
            }))
        } catch (n) {
            t.some((function(e) {
                e.__h && (e.__h = [])
            })), t = [], _e.__e(n, e.__v)
        }
    })), xe && xe(e, t)
}, _e.unmount = function(e) {
    ke && ke(e);
    var t, n = e.__c;
    n && n.__H && (n.__H.__.forEach((function(e) {
        try {
            Re(e)
        } catch (e) {
            t = e
        }
    })), n.__H = void 0, t && _e.__e(t, n.__v))
};
var Ue = "function" == typeof requestAnimationFrame;

function De(e) {
    var t, n = function() {
            clearTimeout(o), Ue && cancelAnimationFrame(t), setTimeout(e)
        },
        o = setTimeout(n, 100);
    Ue && (t = requestAnimationFrame(n))
}

function Re(e) {
    var t = he,
        n = e.__c;
    "function" == typeof n && (e.__c = void 0, n()), he = t
}

function ze(e) {
    var t = he;
    e.__c = e.__(), he = t
}

function $e(e, t) {
    return !e || e.length !== t.length || t.some((function(t, n) {
        return t !== e[n]
    }))
}

function Fe(e, t) {
    return "function" == typeof t ? t(e) : t
}

function Be(e, t) {
    for (var n in t) e[n] = t[n];
    return e
}

function He(e, t) {
    for (var n in e)
        if ("__source" !== n && !(n in t)) return !0;
    for (var o in t)
        if ("__source" !== o && e[o] !== t[o]) return !0;
    return !1
}

function Ve(e, t) {
    this.props = e, this.context = t
}(Ve.prototype = new B).isPureReactComponent = !0, Ve.prototype.shouldComponentUpdate = function(e, t) {
    return He(this.props, e) || He(this.state, t)
};
var We = x.__b;
x.__b = function(e) {
    e.type && e.type.__f && e.ref && (e.props.ref = e.ref, e.ref = null), We && We(e)
};
var qe = "undefined" != typeof Symbol && Symbol.for && Symbol.for("react.forward_ref") || 3911;

function Ke(e) {
    function t(t) {
        var n = Be({}, t);
        return delete n.ref, e(n, t.ref || null)
    }
    return t.$$typeof = qe, t.render = t, t.prototype.isReactComponent = t.__f = !0, t.displayName = "ForwardRef(" + (e.displayName || e.name) + ")", t
}
var Xe = x.__e;
x.__e = function(e, t, n, o) {
    if (e.then)
        for (var r, i = t; i = i.__;)
            if ((r = i.__c) && r.__c) return null == t.__e && (t.__e = n.__e, t.__k = n.__k), r.__c(e, t);
    Xe(e, t, n, o)
};
var Ye = x.unmount;

function Ge(e, t, n) {
    return e && (e.__c && e.__c.__H && (e.__c.__H.__.forEach((function(e) {
        "function" == typeof e.__c && e.__c()
    })), e.__c.__H = null), null != (e = Be({}, e)).__c && (e.__c.__P === n && (e.__c.__P = t), e.__c.__e = !0, e.__c = null), e.__k = e.__k && e.__k.map((function(e) {
        return Ge(e, t, n)
    }))), e
}

function Je(e, t, n) {
    return e && n && (e.__v = null, e.__k = e.__k && e.__k.map((function(e) {
        return Je(e, t, n)
    })), e.__c && e.__c.__P === t && (e.__e && n.appendChild(e.__e), e.__c.__e = !0, e.__c.__P = n)), e
}

function Ze() {
    this.__u = 0, this.o = null, this.__b = null
}

function Qe(e) {
    var t = e.__.__c;
    return t && t.__a && t.__a(e)
}

function et() {
    this.i = null, this.l = null
}
x.unmount = function(e) {
    var t = e.__c;
    t && t.__R && t.__R(), t && 32 & e.__u && (e.type = null), Ye && Ye(e)
}, (Ze.prototype = new B).__c = function(e, t) {
    var n = t.__c,
        o = this;
    null == o.o && (o.o = []), o.o.push(n);
    var r = Qe(o.__v),
        i = !1,
        a = function() {
            i || (i = !0, n.__R = null, r ? r(s) : s())
        };
    n.__R = a;
    var s = function() {
        if (!--o.__u) {
            if (o.state.__a) {
                var e = o.state.__a;
                o.__v.__k[0] = Je(e, e.__c.__P, e.__c.__O)
            }
            var t;
            for (o.setState({
                    __a: o.__b = null
                }); t = o.o.pop();) t.forceUpdate()
        }
    };
    o.__u++ || 32 & t.__u || o.setState({
        __a: o.__b = o.__v.__k[0]
    }), e.then(a, a)
}, Ze.prototype.componentWillUnmount = function() {
    this.o = []
}, Ze.prototype.render = function(e, t) {
    if (this.__b) {
        if (this.__v.__k) {
            var n = document.createElement("div"),
                o = this.__v.__k[0].__c;
            this.__v.__k[0] = Ge(this.__b, n, o.__O = o.__P)
        }
        this.__b = null
    }
    var r = t.__a && z(F, null, e.fallback);
    return r && (r.__u &= -33), [z(F, null, t.__a ? null : e.children), r]
};
var tt = function(e, t, n) {
    if (++n[1] === n[0] && e.l.delete(t), e.props.revealOrder && ("t" !== e.props.revealOrder[0] || !e.l.size))
        for (n = e.i; n;) {
            for (; n.length > 3;) n.pop()();
            if (n[1] < n[0]) break;
            e.i = n = n[2]
        }
};

function nt(e) {
    return this.getChildContext = function() {
        return e.context
    }, e.children
}

function ot(e) {
    var t = this,
        n = e.h;
    t.componentWillUnmount = function() {
        se(null, t.v), t.v = null, t.h = null
    }, t.h && t.h !== n && t.componentWillUnmount(), t.v || (t.h = n, t.v = {
        nodeType: 1,
        parentNode: n,
        childNodes: [],
        contains: function() {
            return !0
        },
        appendChild: function(e) {
            this.childNodes.push(e), t.h.appendChild(e)
        },
        insertBefore: function(e, n) {
            this.childNodes.push(e), t.h.insertBefore(e, n)
        },
        removeChild: function(e) {
            this.childNodes.splice(this.childNodes.indexOf(e) >>> 1, 1), t.h.removeChild(e)
        }
    }), se(z(nt, {
        context: t.context
    }, e.__v), t.v)
}

function rt(e, t) {
    var n = z(ot, {
        __v: e,
        h: t
    });
    return n.containerInfo = t, n
}(et.prototype = new B).__a = function(e) {
    var t = this,
        n = Qe(t.__v),
        o = t.l.get(e);
    return o[0]++,
        function(r) {
            var i = function() {
                t.props.revealOrder ? (o.push(r), tt(t, e, o)) : r()
            };
            n ? n(i) : i()
        }
}, et.prototype.render = function(e) {
    this.i = null, this.l = new Map;
    var t = Y(e.children);
    e.revealOrder && "b" === e.revealOrder[0] && t.reverse();
    for (var n = t.length; n--;) this.l.set(t[n], this.i = [1, 0, this.i]);
    return e.children
}, et.prototype.componentDidUpdate = et.prototype.componentDidMount = function() {
    var e = this;
    this.l.forEach((function(t, n) {
        tt(e, n, t)
    }))
};
var it = "undefined" != typeof Symbol && Symbol.for && Symbol.for("react.element") || 60103,
    at = /^(?:accent|alignment|arabic|baseline|cap|clip(?!PathU)|color|dominant|fill|flood|font|glyph(?!R)|horiz|image(!S)|letter|lighting|marker(?!H|W|U)|overline|paint|pointer|shape|stop|strikethrough|stroke|text(?!L)|transform|underline|unicode|units|v|vector|vert|word|writing|x(?!C))[A-Z]/,
    st = /^on(Ani|Tra|Tou|BeforeInp|Compo)/,
    lt = /[A-Z0-9]/g,
    ct = "undefined" != typeof document,
    dt = function(e) {
        return ("undefined" != typeof Symbol && "symbol" == typeof Symbol() ? /fil|che|rad/ : /fil|che|ra/).test(e)
    };
B.prototype.isReactComponent = {}, ["componentWillMount", "componentWillReceiveProps", "componentWillUpdate"].forEach((function(e) {
    Object.defineProperty(B.prototype, e, {
        configurable: !0,
        get: function() {
            return this["UNSAFE_" + e]
        },
        set: function(t) {
            Object.defineProperty(this, e, {
                configurable: !0,
                writable: !0,
                value: t
            })
        }
    })
}));
var ut = x.event;

function pt() {}

function ht() {
    return this.cancelBubble
}

function ft() {
    return this.defaultPrevented
}
x.event = function(e) {
    return ut && (e = ut(e)), e.persist = pt, e.isPropagationStopped = ht, e.isDefaultPrevented = ft, e.nativeEvent = e
};
var mt = {
        enumerable: !1,
        configurable: !0,
        get: function() {
            return this.class
        }
    },
    gt = x.vnode;
x.vnode = function(e) {
    "string" == typeof e.type && function(e) {
        var t = e.props,
            n = e.type,
            o = {},
            r = -1 === n.indexOf("-");
        for (var i in t) {
            var a = t[i];
            if (!("value" === i && "defaultValue" in t && null == a || ct && "children" === i && "noscript" === n || "class" === i || "className" === i)) {
                var s = i.toLowerCase();
                "defaultValue" === i && "value" in t && null == t.value ? i = "value" : "download" === i && !0 === a ? a = "" : "translate" === s && "no" === a ? a = !1 : "o" === s[0] && "n" === s[1] ? "ondoubleclick" === s ? i = "ondblclick" : "onchange" !== s || "input" !== n && "textarea" !== n || dt(t.type) ? "onfocus" === s ? i = "onfocusin" : "onblur" === s ? i = "onfocusout" : st.test(i) && (i = s) : s = i = "oninput" : r && at.test(i) ? i = i.replace(lt, "-$&").toLowerCase() : null === a && (a = void 0), "oninput" === s && o[i = s] && (i = "oninputCapture"), o[i] = a
            }
        }
        "select" == n && o.multiple && Array.isArray(o.value) && (o.value = Y(t.children).forEach((function(e) {
            e.props.selected = -1 != o.value.indexOf(e.props.value)
        }))), "select" == n && null != o.defaultValue && (o.value = Y(t.children).forEach((function(e) {
            e.props.selected = o.multiple ? -1 != o.defaultValue.indexOf(e.props.value) : o.defaultValue == e.props.value
        }))), t.class && !t.className ? (o.class = t.class, Object.defineProperty(o, "className", mt)) : (t.className && !t.class || t.class && t.className) && (o.class = o.className = t.className), e.props = o
    }(e), e.$$typeof = it, gt && gt(e)
};
var vt = x.__r;
x.__r = function(e) {
    vt && vt(e), e.__c
};
var _t = x.diffed;
x.diffed = function(e) {
        _t && _t(e);
        var t = e.props,
            n = e.__e;
        null != n && "textarea" === e.type && "value" in t && t.value !== n.value && (n.value = null == t.value ? "" : t.value)
    },
    function() {
        if ("undefined" != typeof document && !("adoptedStyleSheets" in document)) {
            var e = "ShadyCSS" in window && !ShadyCSS.nativeShadow,
                t = document.implementation.createHTMLDocument(""),
                n = new WeakMap,
                o = "object" == typeof DOMException ? Error : DOMException,
                r = Object.defineProperty,
                i = Array.prototype.forEach,
                a = /@import.+?;?$/gm,
                s = CSSStyleSheet.prototype;
            s.replace = function() {
                return Promise.reject(new o("Can't call replace on non-constructed CSSStyleSheets."))
            }, s.replaceSync = function() {
                throw new o("Failed to execute 'replaceSync' on 'CSSStyleSheet': Can't call replaceSync on non-constructed CSSStyleSheets.")
            };
            var l = new WeakMap,
                c = new WeakMap,
                d = new WeakMap,
                u = new WeakMap,
                p = P.prototype;
            p.replace = function(e) {
                try {
                    return this.replaceSync(e), Promise.resolve(this)
                } catch (e) {
                    return Promise.reject(e)
                }
            }, p.replaceSync = function(e) {
                if (C(this), "string" == typeof e) {
                    var t = this;
                    l.get(t).textContent = function(e) {
                        var t = e.replace(a, "");
                        return t !== e && console.warn("@import rules are not allowed here. See https://github.com/WICG/construct-stylesheets/issues/119#issuecomment-588352418"), t.trim()
                    }(e), u.set(t, []), c.get(t).forEach((function(e) {
                        e.isConnected() && S(t, E(t, e))
                    }))
                }
            }, r(p, "cssRules", {
                configurable: !0,
                enumerable: !0,
                get: function() {
                    return C(this), l.get(this).sheet.cssRules
                }
            }), r(p, "media", {
                configurable: !0,
                enumerable: !0,
                get: function() {
                    return C(this), l.get(this).sheet.media
                }
            }), ["addRule", "deleteRule", "insertRule", "removeRule"].forEach((function(e) {
                p[e] = function() {
                    var t = this;
                    C(t);
                    var n = arguments;
                    u.get(t).push({
                        method: e,
                        args: n
                    }), c.get(t).forEach((function(o) {
                        if (o.isConnected()) {
                            var r = E(t, o).sheet;
                            r[e].apply(r, n)
                        }
                    }));
                    var o = l.get(t).sheet;
                    return o[e].apply(o, n)
                }
            })), r(P, Symbol.hasInstance, {
                configurable: !0,
                value: x
            });
            var h = {
                    childList: !0,
                    subtree: !0
                },
                f = new WeakMap,
                m = new WeakMap,
                g = new WeakMap,
                v = new WeakMap;
            if (A.prototype = {
                    isConnected: function() {
                        var e = m.get(this);
                        return e instanceof Document ? "loading" !== e.readyState : function(e) {
                            return "isConnected" in e ? e.isConnected : document.contains(e)
                        }(e.host)
                    },
                    connect: function() {
                        var e = I(this);
                        v.get(this).observe(e, h), g.get(this).length > 0 && j(this), T(e, (function(e) {
                            M(e).connect()
                        }))
                    },
                    disconnect: function() {
                        v.get(this).disconnect()
                    },
                    update: function(e) {
                        var t = this,
                            n = m.get(t) === document ? "Document" : "ShadowRoot";
                        if (!Array.isArray(e)) throw new TypeError("Failed to set the 'adoptedStyleSheets' property on " + n + ": Iterator getter is not callable.");
                        if (!e.every(x)) throw new TypeError("Failed to set the 'adoptedStyleSheets' property on " + n + ": Failed to convert value to 'CSSStyleSheet'");
                        if (e.some(k)) throw new TypeError("Failed to set the 'adoptedStyleSheets' property on " + n + ": Can't adopt non-constructed stylesheets");
                        t.sheets = e;
                        var o, r, i = g.get(t),
                            a = (o = e).filter((function(e, t) {
                                return o.indexOf(e) === t
                            }));
                        (r = a, i.filter((function(e) {
                            return -1 === r.indexOf(e)
                        }))).forEach((function(e) {
                            var n;
                            (n = E(e, t)).parentNode.removeChild(n),
                                function(e, t) {
                                    d.get(e).delete(t), c.set(e, c.get(e).filter((function(e) {
                                        return e !== t
                                    })))
                                }(e, t)
                        })), g.set(t, a), t.isConnected() && a.length > 0 && j(t)
                    }
                }, window.CSSStyleSheet = P, O(Document), "ShadowRoot" in window) {
                O(ShadowRoot);
                var _ = Element.prototype,
                    y = _.attachShadow;
                _.attachShadow = function(e) {
                    var t = y.call(this, e);
                    return "closed" === e.mode && n.set(this, t), t
                }
            }
            var w = M(document);
            w.isConnected() ? w.connect() : document.addEventListener("DOMContentLoaded", w.connect.bind(w))
        }

        function b(e) {
            return e.shadowRoot || n.get(e)
        }

        function x(e) {
            return "object" == typeof e && (p.isPrototypeOf(e) || s.isPrototypeOf(e))
        }

        function k(e) {
            return "object" == typeof e && s.isPrototypeOf(e)
        }

        function E(e, t) {
            return d.get(e).get(t)
        }

        function S(e, t) {
            requestAnimationFrame((function() {
                t.textContent = l.get(e).textContent, u.get(e).forEach((function(e) {
                    return t.sheet[e.method].apply(t.sheet, e.args)
                }))
            }))
        }

        function C(e) {
            if (!l.has(e)) throw new TypeError("Illegal invocation")
        }

        function P() {
            var e = this,
                n = document.createElement("style");
            t.body.appendChild(n), l.set(e, n), c.set(e, []), d.set(e, new WeakMap), u.set(e, [])
        }

        function M(e) {
            var t = f.get(e);
            return t || (t = new A(e), f.set(e, t)), t
        }

        function O(e) {
            r(e.prototype, "adoptedStyleSheets", {
                configurable: !0,
                enumerable: !0,
                get: function() {
                    return M(this).sheets
                },
                set: function(e) {
                    M(this).update(e)
                }
            })
        }

        function T(e, t) {
            for (var n = document.createNodeIterator(e, NodeFilter.SHOW_ELEMENT, (function(e) {
                    return b(e) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT
                }), null, !1), o = void 0; o = n.nextNode();) t(b(o))
        }

        function I(e) {
            var t = m.get(e);
            return t instanceof Document ? t.body : t
        }

        function j(e) {
            var t = document.createDocumentFragment(),
                n = g.get(e),
                o = v.get(e),
                r = I(e);
            o.disconnect(), n.forEach((function(n) {
                t.appendChild(E(n, e) || function(e, t) {
                    var n = document.createElement("style");
                    return d.get(e).set(t, n), c.get(e).push(t), n
                }(n, e))
            })), r.insertBefore(t, null), o.observe(r, h), n.forEach((function(t) {
                S(t, E(t, e))
            }))
        }

        function A(t) {
            var n = this;
            n.sheets = [], m.set(n, t), g.set(n, []), v.set(n, new MutationObserver((function(t, o) {
                document ? t.forEach((function(t) {
                    e || i.call(t.addedNodes, (function(e) {
                        e instanceof Element && T(e, (function(e) {
                            M(e).connect()
                        }))
                    })), i.call(t.removedNodes, (function(t) {
                        t instanceof Element && (function(e, t) {
                            return t instanceof HTMLStyleElement && g.get(e).some((function(t) {
                                return E(t, e)
                            }))
                        }(n, t) && j(n), e || T(t, (function(e) {
                            M(e).disconnect()
                        })))
                    }))
                })) : o.disconnect()
            })))
        }
    }();
const yt = ce({
        client: void 0,
        leaveBreadcrumb: () => {
            throw new Error("Invalid attempt to call leaveBreadcrumb outside of context.")
        },
        notify: () => {
            throw new Error("Invalid attempt to call notify outside of context.")
        }
    }),
    wt = () => {
        const e = Ne(yt);
        if (!e) throw new Error("Invalid attempt to use useBugsnag outside of BugsnagProvider.");
        return e
    };
var bt = '*,::backdrop,:after,:before{--tw-border-spacing-x:0;--tw-border-spacing-y:0;--tw-translate-x:0;--tw-translate-y:0;--tw-rotate:0;--tw-skew-x:0;--tw-skew-y:0;--tw-scale-x:1;--tw-scale-y:1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness:proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:#3b82f680;--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000;--tw-shadow-colored:0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }/*! tailwindcss v3.4.14 | MIT License | https://tailwindcss.com*/*,:after,:before{border:0 solid;box-sizing:border-box}:after,:before{--tw-content:""}:host,html{-webkit-text-size-adjust:100%;font-feature-settings:normal;-webkit-tap-highlight-color:transparent;font-family:GTStandard-M,sans-serif;font-variation-settings:normal;line-height:1.5;tab-size:4}body{line-height:inherit;margin:0}hr{border-top-width:1px;color:inherit;height:0}abbr:where([title]){-webkit-text-decoration:underline dotted;text-decoration:underline dotted}h1,h2,h3,h4,h5,h6{font-size:inherit;font-weight:inherit}a{color:inherit;text-decoration:inherit}b,strong{font-weight:bolder}code,kbd,pre,samp{font-feature-settings:normal;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,Liberation Mono,Courier New,monospace;font-size:1em;font-variation-settings:normal}small{font-size:80%}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:initial}sub{bottom:-.25em}sup{top:-.5em}table{border-collapse:collapse;border-color:inherit;text-indent:0}button,input,optgroup,select,textarea{font-feature-settings:inherit;color:inherit;font-family:inherit;font-size:100%;font-variation-settings:inherit;font-weight:inherit;letter-spacing:inherit;line-height:inherit;margin:0;padding:0}button,select{text-transform:none}button,input:where([type=button]),input:where([type=reset]),input:where([type=submit]){-webkit-appearance:button;background-color:initial;background-image:none}:-moz-focusring{outline:auto}:-moz-ui-invalid{box-shadow:none}progress{vertical-align:initial}::-webkit-inner-spin-button,::-webkit-outer-spin-button{height:auto}[type=search]{-webkit-appearance:textfield;outline-offset:-2px}::-webkit-search-decoration{-webkit-appearance:none}::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}summary{display:list-item}blockquote,dd,dl,figure,h1,h2,h3,h4,h5,h6,hr,p,pre{margin:0}fieldset{margin:0}fieldset,legend{padding:0}menu,ol,ul{list-style:none;margin:0;padding:0}dialog{padding:0}textarea{resize:vertical}input::placeholder,textarea::placeholder{color:#9ca3af;opacity:1}[role=button],button{cursor:pointer}:disabled{cursor:default}audio,canvas,embed,iframe,img,object,svg,video{display:block;vertical-align:middle}img,video{height:auto;max-width:100%}[hidden]:where(:not([hidden=until-found])){display:none}:host{font-family:GTStandard-M,sans-serif}:host([data-nametag=shop-portal-provider]){all:initial!important}:host(shopify-payment-terms){font-family:inherit}.\\!container{width:100%!important}.container{width:100%}@media (min-width:768px){.\\!container{max-width:768px!important}.container{max-width:768px}}@media (min-width:1024px){.\\!container{max-width:1024px!important}.container{max-width:1024px}}@media (min-width:1280px){.\\!container{max-width:1280px!important}.container{max-width:1280px}}@media (min-width:1536px){.\\!container{max-width:1536px!important}.container{max-width:1536px}}.sr-only{clip:rect(0,0,0,0);border-width:0;height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;white-space:nowrap;width:1px}.pointer-events-none{pointer-events:none}.\\!visible{visibility:visible!important}.visible{visibility:visible}.invisible{visibility:hidden}.fixed{position:fixed}.absolute{position:absolute}.relative{position:relative}.inset-0{inset:0}.inset-05{inset:2px}.inset-x-0{left:0;right:0}.inset-y-0{bottom:0;top:0}.bottom-8{bottom:32px}.bottom-\\[15\\%\\]{bottom:15%}.right-0{right:0}.-z-10{z-index:-10}.z-0{z-index:0}.z-10{z-index:10}.z-30{z-index:30}.z-40{z-index:40}.z-50{z-index:50}.z-max{z-index:2147483647}.-m-px{margin:-1px}.m-0{margin:0}.m-\\[1em\\]{margin:1em}.m-auto{margin:auto}.mx-auto{margin-left:auto;margin-right:auto}.my-0\\.5{margin-bottom:.125rem;margin-top:.125rem}.my-1{margin-bottom:4px;margin-top:4px}.my-5{margin-bottom:20px;margin-top:20px}.my-7{margin-bottom:28px;margin-top:28px}.my-px{margin-bottom:1px;margin-top:1px}.-ml-1{margin-left:-4px}.mb-2{margin-bottom:8px}.mb-3{margin-bottom:12px}.mb-4{margin-bottom:16px}.mb-5{margin-bottom:20px}.mb-7{margin-bottom:28px}.ml-1{margin-left:4px}.ml-auto{margin-left:auto}.mr-0\\.5{margin-right:.125rem}.mr-20{margin-right:5rem}.mr-3{margin-right:12px}.mt-4{margin-top:16px}.mt-5{margin-top:20px}.mt-8{margin-top:32px}.box-content{box-sizing:initial}.block{display:block}.inline-block{display:inline-block}.inline{display:inline}.flex{display:flex}.inline-flex{display:inline-flex}.hidden{display:none}.aspect-branded-button-icon{aspect-ratio:60/25}.aspect-shop-pay-icon{aspect-ratio:99/25}.size-0{height:0;width:0}.size-10{height:40px;width:40px}.size-5{height:20px;width:20px}.size-6{height:24px;width:24px}.size-8{height:32px;width:32px}.size-full{height:100%;width:100%}.h-10{height:40px}.h-3{height:12px}.h-4{height:16px}.h-4-5{height:18px}.h-5{height:20px}.h-8{height:32px}.h-9{height:36px}.h-\\[14px\\]{height:14px}.h-\\[22px\\]{height:22px}.h-auto{height:auto}.h-branded-button-icon{height:var(--font-paragraph--size,16px)}.h-full{height:100%}.h-px{height:1px}.max-h-8{max-height:32px}.max-h-\\[80vh\\]{max-height:80vh}.w-1{width:4px}.w-16{width:64px}.w-22{width:88px}.w-37{width:148px}.w-44{width:11rem}.w-55{width:220px}.w-6{width:24px}.w-85{width:340px}.w-9{width:36px}.w-\\[432px\\]{width:432px}.w-\\[59px\\]{width:59px}.w-auto{width:auto}.w-fit{width:fit-content}.w-full{width:100%}.w-pay-button{width:var(--shop-pay-button-width,260px)}.w-px{width:1px}.min-w-0{min-width:0}.min-w-100{min-width:400px}.min-w-85{min-width:340px}.min-w-max{min-width:max-content}.max-w-100{max-width:400px}.max-w-85{max-width:340px}.max-w-\\[40\\%\\]{max-width:40%}.max-w-full{max-width:100%}.flex-1{flex:1 1 0%}.flex-none{flex:none}.flex-shrink-0{flex-shrink:0}.flex-grow{flex-grow:1}.translate-x-0{--tw-translate-x:0px}.translate-x-0,.translate-y-0{transform:translate(var(--tw-translate-x),var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}.translate-y-0{--tw-translate-y:0px}.translate-y-94{--tw-translate-y:376px}.translate-y-94,.translate-y-\\[9\\.375\\%\\]{transform:translate(var(--tw-translate-x),var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}.translate-y-\\[9\\.375\\%\\]{--tw-translate-y:9.375%}.translate-y-full{--tw-translate-y:100%}.rotate-45,.translate-y-full{transform:translate(var(--tw-translate-x),var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}.rotate-45{--tw-rotate:45deg}.scale-0{--tw-scale-x:0;--tw-scale-y:0}.scale-0,.scale-100{transform:translate(var(--tw-translate-x),var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}.scale-100{--tw-scale-x:1;--tw-scale-y:1}.transform{transform:translate(var(--tw-translate-x),var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}@keyframes fadeIn{0%{opacity:0}to{opacity:1}}.animate-fade-in{animation:fadeIn 1s}@keyframes fadeOut{0%{opacity:1;transform:translateY(0)}to{opacity:0;transform:translateY(100%)}}.animate-fade-out{animation:fadeOut .3s ease-out}@keyframes follow{0%{transform:scaleY(1);width:100%}25%{transform:scaleY(1)}50%{transform:scaleY(1.2)}to{transform:scaleY(1);width:36px}}.animate-follow{animation:follow .3s cubic-bezier(.45,0,.15,1)}@keyframes pulse{50%{opacity:.5}}.animate-pulse{animation:pulse 2s cubic-bezier(.4,0,.6,1) infinite}@keyframes reveal{to{stroke-dashoffset:408}}.animate-reveal{animation:reveal 1.3s ease-in-out 0s infinite reverse}@keyframes slideUp{0%,20%{opacity:0;transform:translateY(100%)}to{opacity:1;transform:translateY(0)}}.animate-slide-up{animation:slideUp .3s ease-in}@keyframes spin{to{transform:rotate(1turn)}}.animate-spin{animation:spin 1.3s linear infinite}.cursor-pointer{cursor:pointer}.select-none{-webkit-user-select:none;user-select:none}.resize{resize:both}.list-none{list-style-type:none}.appearance-none{appearance:none}.flex-row{flex-direction:row}.flex-col{flex-direction:column}.flex-nowrap{flex-wrap:nowrap}.content-center{align-content:center}.items-end{align-items:flex-end}.items-center{align-items:center}.justify-start{justify-content:flex-start}.justify-end{justify-content:flex-end}.justify-center{justify-content:center}.justify-between{justify-content:space-between}.gap-0{gap:0}.gap-0\\.5{gap:.125rem}.gap-1{gap:4px}.gap-2{gap:8px}.gap-3{gap:12px}.gap-4{gap:16px}.gap-text-icon{gap:.25em}.gap-x-1{column-gap:4px}.gap-x-1-5{column-gap:6px}.gap-x-3{column-gap:12px}.gap-x-4{column-gap:16px}.space-y-3>:not([hidden])~:not([hidden]){--tw-space-y-reverse:0;margin-bottom:calc(12px*var(--tw-space-y-reverse));margin-top:calc(12px*(1 - var(--tw-space-y-reverse)))}.space-y-4>:not([hidden])~:not([hidden]){--tw-space-y-reverse:0;margin-bottom:calc(16px*var(--tw-space-y-reverse));margin-top:calc(16px*(1 - var(--tw-space-y-reverse)))}.self-center{align-self:center}.overflow-hidden{overflow:hidden}.overflow-visible{overflow:visible}.truncate{overflow:hidden;white-space:nowrap}.text-ellipsis,.truncate{text-overflow:ellipsis}.whitespace-nowrap{white-space:nowrap}.whitespace-pre-line{white-space:pre-line}.rounded-login-button{border-radius:var(--buttons-radius,var(--x-primary-button-border-radius,var(--shop-pay-button-border-radius,12px)))}.rounded-login-card{border-radius:var(--x-border-radius-large,12px)}.rounded-max{border-radius:999px}.rounded-md{border-radius:12px}.rounded-sm{border-radius:8px}.rounded-sm100{border-radius:10px}.rounded-xl{border-radius:20px}.rounded-xs{border-radius:4px}.rounded-xxl{border-radius:28px}.border{border-width:1px}.border-0{border-width:0}.border-\\[0\\.5px\\]{border-width:.5px}.border-b{border-bottom-width:1px}.border-solid{border-style:solid}.border-none{border-style:none}.border-checkout-branded{border-color:var(--x-textfield-border-color,#00000014)}.border-checkout-branded-dark{border-color:#ffffff14}.border-grayscale-l2{--tw-border-opacity:1;border-color:rgb(203 203 202/var(--tw-border-opacity))}.border-grayscale-l2l{--tw-border-opacity:1;border-color:rgb(227 227 227/var(--tw-border-opacity))}.border-white\\/20{border-color:#fff3}.bg-core-idp-social-logins{background-color:var(--x-social-color-background,#fff)}.bg-grayscale-l2{--tw-bg-opacity:1;background-color:rgb(203 203 202/var(--tw-bg-opacity))}.bg-grayscale-l3{--tw-bg-opacity:1;background-color:rgb(240 240 240/var(--tw-bg-opacity))}.bg-grayscale-l4{--tw-bg-opacity:1;background-color:rgb(242 244 245/var(--tw-bg-opacity))}.bg-grayscale-primary-light{--tw-bg-opacity:1;background-color:rgb(112 112 112/var(--tw-bg-opacity))}.bg-overlay{background-color:#0006}.bg-poppy-d1{--tw-bg-opacity:1;background-color:rgb(217 42 15/var(--tw-bg-opacity))}.bg-poppy-l2{--tw-bg-opacity:1;background-color:rgb(255 236 233/var(--tw-bg-opacity))}.bg-purple-primary{--tw-bg-opacity:1;background-color:rgb(84 51 235/var(--tw-bg-opacity))}.bg-transparent{background-color:initial}.bg-white{--tw-bg-opacity:1;background-color:rgb(255 255 255/var(--tw-bg-opacity))}.bg-opacity-5{--tw-bg-opacity:0.05}.bg-gradient-to-b{background-image:linear-gradient(to bottom,var(--tw-gradient-stops))}.bg-gradient-to-r{background-image:linear-gradient(to right,var(--tw-gradient-stops))}.bg-none{background-image:none}.from-black\\/95{--tw-gradient-from:#000000f2 var(--tw-gradient-from-position);--tw-gradient-to:#0000 var(--tw-gradient-to-position);--tw-gradient-stops:var(--tw-gradient-from),var(--tw-gradient-to)}.from-transparent{--tw-gradient-from:#0000 var(--tw-gradient-from-position);--tw-gradient-to:#0000 var(--tw-gradient-to-position);--tw-gradient-stops:var(--tw-gradient-from),var(--tw-gradient-to)}.to-black\\/60{--tw-gradient-to:#0009 var(--tw-gradient-to-position)}.to-white{--tw-gradient-to:#fff var(--tw-gradient-to-position)}.fill-purple-primary{fill:#5433eb}.stroke-white{stroke:#fff}.p-0{padding:0}.p-3{padding:12px}.p-4{padding:16px}.p-6{padding:24px}.p-8{padding:32px}.p-shop-button{padding:max(var(--button-padding-block,16px),8px) max(var(--button-padding-inline,44px),16px)}.p-shop-login{padding:var(--x-spacing-base,14px)}.px-0{padding-left:0;padding-right:0}.px-11{padding-left:44px;padding-right:44px}.px-2{padding-left:8px;padding-right:8px}.px-3{padding-left:12px;padding-right:12px}.px-4{padding-left:16px;padding-right:16px}.px-5{padding-left:20px;padding-right:20px}.px-6{padding-left:24px;padding-right:24px}.py-1{padding-bottom:4px;padding-top:4px}.py-2-5{padding-bottom:10px;padding-top:10px}.py-2\\.5{padding-bottom:.625rem;padding-top:.625rem}.py-3{padding-bottom:12px;padding-top:12px}.py-4{padding-bottom:16px;padding-top:16px}.pb-0{padding-bottom:0}.pb-2{padding-bottom:8px}.pb-3{padding-bottom:12px}.pb-4{padding-bottom:16px}.pb-6{padding-bottom:24px}.pr-1\\.5{padding-right:.375rem}.pr-3{padding-right:12px}.pt-0{padding-top:0}.pt-3{padding-top:12px}.pt-4{padding-top:16px}.text-center{text-align:center}.align-middle{vertical-align:middle}.font-inherit{font-family:inherit}.font-sans{font-family:GTStandard-M,sans-serif}.font-system{font-family:ui-sans-serif,system-ui,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji}.text-body-large{font-size:16px;font-weight:450;letter-spacing:-.5px;line-height:22px}.text-body-small{font-weight:450}.text-body-small,.text-body-title-small{font-size:14px;letter-spacing:-.2px;line-height:18px}.text-body-title-small{font-weight:500}.text-branded-button{font-size:var(--font-paragraph--size,16px);font-weight:500;letter-spacing:-.5px;line-height:var(--font-paragraph--line-height,22px)}.text-button-large{font-size:16px;font-weight:600;letter-spacing:-.5px;line-height:22px}.text-button-medium{font-size:14px;font-weight:600;letter-spacing:-.2px;line-height:18px}.text-caption{font-size:12px;font-weight:450;letter-spacing:-.2px;line-height:16px}.text-header-normal{font-size:24px;font-weight:450;letter-spacing:-1px;line-height:26px}.text-subtitle{font-size:18px;font-weight:500;letter-spacing:-1px;line-height:20px}.font-bold{font-weight:700}.font-light{font-weight:300}.font-medium{font-weight:500}.font-normal{font-weight:400}.font-semibold{font-weight:600}.uppercase{text-transform:uppercase}.leading-6{line-height:1.5rem}.leading-\\[16px\\]{line-height:16px}.leading-\\[20px\\]{line-height:20px}.leading-normal{line-height:1.5}.leading-snug{line-height:1.375}.tracking-wider{letter-spacing:.05em}.text-black{--tw-text-opacity:1;color:rgb(0 0 0/var(--tw-text-opacity))}.text-grayscale-d0{--tw-text-opacity:1;color:rgb(102 102 102/var(--tw-text-opacity))}.text-grayscale-d1{--tw-text-opacity:1;color:rgb(64 64 64/var(--tw-text-opacity))}.text-grayscale-d2{--tw-text-opacity:1;color:rgb(18 18 18/var(--tw-text-opacity))}.text-grayscale-d2\\/70{color:#121212b3}.text-grayscale-l1{--tw-text-opacity:1;color:rgb(168 168 167/var(--tw-text-opacity))}.text-grayscale-l4{--tw-text-opacity:1;color:rgb(242 244 245/var(--tw-text-opacity))}.text-grayscale-primary-light{--tw-text-opacity:1;color:rgb(112 112 112/var(--tw-text-opacity))}.text-poppy-d1{--tw-text-opacity:1;color:rgb(217 42 15/var(--tw-text-opacity))}.text-purple-primary{--tw-text-opacity:1;color:rgb(84 51 235/var(--tw-text-opacity))}.text-white{--tw-text-opacity:1;color:rgb(255 255 255/var(--tw-text-opacity))}.underline{text-decoration-line:underline}.no-underline{text-decoration-line:none}.opacity-0{opacity:0}.opacity-100{opacity:1}.shadow-card{--tw-shadow:0 4px 12px #0000000a;--tw-shadow-colored:0 4px 12px var(--tw-shadow-color)}.shadow-card,.shadow-lg{box-shadow:var(--tw-ring-offset-shadow,0 0 #0000),var(--tw-ring-shadow,0 0 #0000),var(--tw-shadow)}.shadow-lg{--tw-shadow:0px 8px 30px 0px #0006;--tw-shadow-colored:0px 8px 30px 0px var(--tw-shadow-color)}.shadow-sm{--tw-shadow:0px 1px 4px 0px #0000001a;--tw-shadow-colored:0px 1px 4px 0px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow,0 0 #0000),var(--tw-ring-shadow,0 0 #0000),var(--tw-shadow)}.outline-none{outline:2px solid #0000;outline-offset:2px}.ring-1{--tw-ring-offset-shadow:var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);--tw-ring-shadow:var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);box-shadow:var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow,0 0 #0000)}.ring-inset{--tw-ring-inset:inset}.ring-black\\/5{--tw-ring-color:#0000000d}.blur{--tw-blur:blur(8px)}.blur,.filter{filter:var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow)}.backdrop-blur-xl{--tw-backdrop-blur:blur(24px);backdrop-filter:var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia)}.transition{transition-duration:.15s;transition-property:color,background-color,border-color,text-decoration-color,fill,stroke,opacity,box-shadow,transform,filter,backdrop-filter;transition-timing-function:cubic-bezier(.4,0,.2,1)}.transition-all{transition-duration:.15s;transition-property:all;transition-timing-function:cubic-bezier(.4,0,.2,1)}.transition-colors{transition-duration:.15s;transition-property:color,background-color,border-color,text-decoration-color,fill,stroke;transition-timing-function:cubic-bezier(.4,0,.2,1)}.transition-opacity{transition-duration:.15s;transition-property:opacity;transition-timing-function:cubic-bezier(.4,0,.2,1)}.transition-transform{transition-duration:.15s;transition-property:transform;transition-timing-function:cubic-bezier(.4,0,.2,1)}.duration-300{transition-duration:.3s}.duration-400{transition-duration:.4s}.ease-cubic-modal{transition-timing-function:cubic-bezier(.32,.72,0,1)}.ease-in-out{transition-timing-function:cubic-bezier(.4,0,.2,1)}.ease-out{transition-timing-function:cubic-bezier(0,0,.2,1)}.will-change-transform{will-change:transform}.forced-color-adjust-none{forced-color-adjust:none}.stroke-dasharray-reveal{stroke-dasharray:136}.stroke-dashoffset-reveal{stroke-dashoffset:136}.first_pt-0:first-child{padding-top:0}.last_border-b-0:last-child{border-bottom-width:0}.last_pb-0:last-child{padding-bottom:0}.hover_bg-purple-d0:hover{--tw-bg-opacity:1;background-color:rgb(69 36 219/var(--tw-bg-opacity))}.hover_text-black:hover{--tw-text-opacity:1;color:rgb(0 0 0/var(--tw-text-opacity))}.hover_text-grayscale-d0:hover{--tw-text-opacity:1;color:rgb(102 102 102/var(--tw-text-opacity))}.hover_text-grayscale-d1:hover{--tw-text-opacity:1;color:rgb(64 64 64/var(--tw-text-opacity))}.hover_text-grayscale-l2l:hover{--tw-text-opacity:1;color:rgb(227 227 227/var(--tw-text-opacity))}.hover_opacity-70:hover{opacity:.7}.hover_opacity-80:hover{opacity:.8}.hover_outline-none:hover{outline:2px solid #0000;outline-offset:2px}.focus_text-black:focus{--tw-text-opacity:1;color:rgb(0 0 0/var(--tw-text-opacity))}.focus_text-grayscale-d0:focus{--tw-text-opacity:1;color:rgb(102 102 102/var(--tw-text-opacity))}.focus_opacity-70:focus{opacity:.7}.focus_outline-none:focus{outline:2px solid #0000;outline-offset:2px}.focus_outline-0:focus{outline-width:0}.focus-visible_outline-none:focus-visible{outline:2px solid #0000;outline-offset:2px}.focus-visible_ring:focus-visible{--tw-ring-offset-shadow:var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);--tw-ring-shadow:var(--tw-ring-inset) 0 0 0 calc(3px + var(--tw-ring-offset-width)) var(--tw-ring-color);box-shadow:var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow,0 0 #0000)}.focus-visible_ring-purple-l1:focus-visible{--tw-ring-opacity:1;--tw-ring-color:rgb(156 131 248/var(--tw-ring-opacity))}.active_text-black:active{--tw-text-opacity:1;color:rgb(0 0 0/var(--tw-text-opacity))}.active_text-grayscale-d0:active{--tw-text-opacity:1;color:rgb(102 102 102/var(--tw-text-opacity))}.active_opacity-70:active{opacity:.7}.active_outline-none:active{outline:2px solid #0000;outline-offset:2px}.hover_enabled_bg-purple-d0:enabled:hover{--tw-bg-opacity:1;background-color:rgb(69 36 219/var(--tw-bg-opacity))}.hover_enabled_bg-transparent:enabled:hover{background-color:initial}.focus_enabled_outline-none:enabled:focus{outline:2px solid #0000;outline-offset:2px}.focus_enabled_ring:enabled:focus{--tw-ring-offset-shadow:var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);--tw-ring-shadow:var(--tw-ring-inset) 0 0 0 calc(3px + var(--tw-ring-offset-width)) var(--tw-ring-color);box-shadow:var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow,0 0 #0000)}.focus_enabled_ring-purple-l1:enabled:focus{--tw-ring-opacity:1;--tw-ring-color:rgb(156 131 248/var(--tw-ring-opacity))}.focus-visible_enabled_outline-none:enabled:focus-visible{outline:2px solid #0000;outline-offset:2px}.focus-visible_enabled_ring:enabled:focus-visible{--tw-ring-offset-shadow:var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);--tw-ring-shadow:var(--tw-ring-inset) 0 0 0 calc(3px + var(--tw-ring-offset-width)) var(--tw-ring-color);box-shadow:var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow,0 0 #0000)}.focus-visible_enabled_ring-purple-l1:enabled:focus-visible{--tw-ring-opacity:1;--tw-ring-color:rgb(156 131 248/var(--tw-ring-opacity))}.disabled_opacity-50:disabled{opacity:.5}.group:hover .group-hover_bg-purple-d0{--tw-bg-opacity:1;background-color:rgb(69 36 219/var(--tw-bg-opacity))}.group:hover .group-hover_text-grayscale-l2l{--tw-text-opacity:1;color:rgb(227 227 227/var(--tw-text-opacity))}.data-hidden_invisible[data-visible=false]{visibility:hidden}.data-hidden_absolute[data-visible=false]{position:absolute}.data-hidden_inset-0[data-visible=false]{inset:0}.data-hidden_hidden[data-visible=false]{display:none}.data-hidden_opacity-0[data-visible=false]{opacity:0}.group[data-visible=false] .group-data-hidden_translate-x-full{--tw-translate-x:100%;transform:translate(var(--tw-translate-x),var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}.group[data-visible=false] .group-data-hidden_animate-none{animation:none}.group[data-visible=false] .group-data-hidden_opacity-0{opacity:0}@media (prefers-reduced-motion:reduce){.motion-reduce_animate-none{animation:none}.motion-reduce_transition-none{transition-property:none}.motion-reduce_transition-opacity{transition-duration:.15s;transition-property:opacity;transition-timing-function:cubic-bezier(.4,0,.2,1)}.motion-reduce_duration-0{transition-duration:0s}}@media (max-width:448px){.sm_absolute{position:absolute}.sm_inset-x-0{left:0;right:0}.sm_bottom-0{bottom:0}.sm_top-auto{top:auto}.sm_hidden{display:none}.sm_max-w-none{max-width:none}.sm_translate-y-0{--tw-translate-y:0px}.sm_translate-y-0,.sm_translate-y-full{transform:translate(var(--tw-translate-x),var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}.sm_translate-y-full{--tw-translate-y:100%}.sm_scale-100{--tw-scale-x:1;--tw-scale-y:1;transform:translate(var(--tw-translate-x),var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}.sm_rounded-none{border-radius:0}.sm_rounded-b-none{border-bottom-left-radius:0;border-bottom-right-radius:0}}';

function xt({
    children: e,
    instanceId: t,
    type: n,
    variant: o
}) {
    const r = Te(null),
        [i, a] = Ce(null),
        {
            notify: s
        } = wt();
    return Oe((() => {
        a(r.current.attachShadow({
            mode: "open"
        }))
    }), []), Oe((() => {
        if (i) {
            const e = new CSSStyleSheet;
            e.replace(bt).then((() => {
                i.adoptedStyleSheets = [e]
            })).catch((e => {
                s(new Error(`Failed to adopt stylesheets for portal provider: ${e}`))
            }))
        }
    }), [i, s]), ue("div", {
        "data-nametag": "shop-portal-provider",
        "data-portal-instance-id": t,
        "data-type": n,
        "data-variant": o,
        ref: r,
        children: i && rt(e, i)
    })
}
const kt = ce({
        analyticsData: {
            analyticsTraceId: ""
        },
        getTrekkieAttributes: () => _(void 0, void 0, void 0, (function*() {
            return Promise.resolve({})
        })),
        produceMonorailEvent: () => {
            throw new Error("Invalid attempt to call produceMonorailEvent outside of context.")
        },
        trackModalStateChange: () => {
            throw new Error("Invalid attempt to call trackModalStateChange outside of context.")
        },
        trackPageImpression: () => _(void 0, void 0, void 0, (function*() {
            throw new Error("Invalid attempt to call trackPageImpression outside of context.")
        })),
        trackUserAction: () => {
            throw new Error("Invalid attempt to call trackUserAction outside of context.")
        },
        trackPostMessageTransmission: () => {
            throw new Error("Invalid attempt to call trackPostMessageTransmission outside of context.")
        }
    }),
    Et = () => Ne(kt),
    St = ce({
        log: () => {
            throw new Error("Invalid attempt to call log outside of context.")
        },
        recordCounter: () => {
            throw new Error("Invalid attempt to call recordCounter outside of context.")
        },
        recordGauge: () => {
            throw new Error("Invalid attempt to call recordGauge outside of context.")
        },
        recordHistogram: () => {
            throw new Error("Invalid attempt to call recordHistogram outside of context.")
        },
        client: void 0
    }),
    Ct = () => Ne(St),
    Pt = ce({
        devMode: !1,
        element: null,
        instanceId: ""
    }),
    Mt = () => Ne(Pt),
    Ot = ce({
        dispatch: () => {
            throw new Error("Invalid attempt to call dispatch outside of AuthorizeStateProvider")
        },
        loaded: !1,
        modalDismissible: !1,
        modalForceHidden: !1,
        modalVisible: !1,
        uiRendered: !1
    }),
    Tt = {
        loaded: !1,
        uiRendered: !1,
        modalDismissible: !1,
        modalForceHidden: !1,
        modalVisible: !1
    },
    It = ({
        children: e
    }) => {
        const {
            leaveBreadcrumb: t,
            notify: n
        } = wt(), {
            trackModalStateChange: o
        } = Et(), r = Ae((({
            action: e,
            previousState: r,
            state: i
        }) => {
            const a = r.modalVisible !== i.modalVisible,
                s = i.modalVisible ? "shown" : "hidden";
            if ("loaded" === e.type && (o({
                    currentState: "loaded",
                    reason: "event_loaded"
                }), t("iframe loaded", {}, "state")), a) switch (e.type) {
                case "loaded":
                    o({
                        currentState: s,
                        reason: "event_loaded_with_auto_open"
                    });
                    break;
                case "windoidOpened":
                    o({
                        currentState: s,
                        dismissMethod: "windoid_continue",
                        reason: "event_windoid_opened"
                    });
                    break;
                case "showModal":
                    o({
                        currentState: s,
                        reason: e.reason
                    });
                    break;
                case "hideModal":
                    o({
                        currentState: s,
                        dismissMethod: e.dismissMethod,
                        reason: e.reason
                    });
                    break;
                case "reset":
                    o({
                        currentState: s,
                        reason: "event_restarted"
                    });
                    break;
                default:
                    n(new Error(`Could not determine state change reason for action: ${e}`))
            }
        }), [t, n, o]), i = Ae(((e, t) => {
            const n = ((e, t) => {
                switch (t.type) {
                    case "hideModal":
                        return Object.assign(Object.assign({}, e), {
                            modalVisible: !1
                        });
                    case "loaded":
                        {
                            const n = t.payload.autoOpen && t.payload.sessionDetected && !e.modalVisible;
                            return Object.assign(Object.assign(Object.assign({}, e), {
                                loaded: !0
                            }), n && !e.modalForceHidden && {
                                modalDismissible: !1,
                                modalVisible: !0
                            })
                        }
                    case "modalDismissible":
                        return Object.assign(Object.assign({}, e), {
                            modalDismissible: !0
                        });
                    case "reset":
                        return Object.assign(Object.assign({}, Tt), {
                            modalForceHidden: e.modalForceHidden
                        });
                    case "uiRendered":
                        return Object.assign(Object.assign({}, e), {
                            uiRendered: !0
                        });
                    case "showModal":
                        return e.modalForceHidden && "user_button_clicked" !== t.reason ? e : Object.assign(Object.assign({}, e), {
                            modalDismissible: !1,
                            modalForceHidden: !1,
                            modalVisible: !0
                        });
                    case "windoidClosed":
                        return Object.assign(Object.assign({}, e), {
                            modalForceHidden: !1
                        });
                    case "windoidOpened":
                        return Object.assign(Object.assign({}, e), {
                            modalForceHidden: !0,
                            modalVisible: !1
                        });
                    default:
                        return e
                }
            })(e, t);
            return r({
                action: t,
                previousState: e,
                state: n
            }), n
        }), [r]), [a, s] = Pe(i, {
            loaded: !1,
            modalDismissible: !1,
            modalForceHidden: !1,
            modalVisible: !1,
            uiRendered: !1
        }), l = je((() => {
            const {
                loaded: e,
                modalDismissible: t,
                modalForceHidden: n,
                modalVisible: o,
                uiRendered: r
            } = a;
            return {
                dispatch: s,
                loaded: e,
                modalDismissible: t,
                modalForceHidden: n,
                modalVisible: o,
                uiRendered: r
            }
        }), [s, a]);
        return ue(Ot.Provider, {
            value: l,
            children: e
        })
    };

function jt(e) {
    return At(e).map((e => e instanceof Error ? e : new Nt(`[${typeof e}] ${function(e){if("string"!=typeof e)try{return JSON.stringify(e)??typeof e}catch{}return`
        $ {
            e
        }
        `}(e).slice(0,10240)}`)))
}

function At(e, t = 0) {
    return t >= 20 ? [e, "Truncated cause stack"] : e instanceof Error && e.cause ? [e, ...At(e.cause, t + 1)] : [e]
}
var Nt = class extends Error {
        name = "BugsnagInvalidError"
    },
    Lt = /^\s*at .*(\S+:\d+|\(native\))/m,
    Ut = /^(eval@)?(\[native code])?$/;

function Dt(e) {
    return e.stack ? e.stack.match(Lt) ? function(e) {
        return e.stack.split("\n").filter((e => !!e.match(Lt))).map((e => {
            let t = e.replace(/^\s+/, "").replace(/^.*?\s+/, ""),
                n = t.match(/ (\(.+\)$)/);
            t = n ? t.replace(n[0], "") : t;
            let o = Rt(n ? n[1] : t);
            return {
                method: n && t || void 0,
                file: ["eval", "<anonymous>"].indexOf(o[0]) > -1 ? void 0 : o[0],
                lineNumber: o[1],
                columnNumber: o[2]
            }
        }))
    }(e) : function(e) {
        return e.stack.split("\n").filter((e => !e.match(Ut))).map((e => {
            if (-1 === e.indexOf("@") && -1 === e.indexOf(":")) return {
                method: e
            };
            let t = /((.*".+"[^@]*)?[^@]*)(?:@)/,
                n = e.match(t),
                o = n && n[1] ? n[1] : void 0,
                r = Rt(e.replace(t, ""));
            return {
                method: o,
                file: r[0],
                lineNumber: r[1],
                columnNumber: r[2]
            }
        }))
    }(e) : []
}

function Rt(e) {
    if (-1 === e.indexOf(":")) return [e];
    let t = /(.+?)(?::(\d+))?(?::(\d+))?$/.exec(e.replace(/[()]/g, ""));
    return [t[1], t[2] ? Number(t[2]) : void 0, t[3] ? Number(t[3]) : void 0]
}
var zt = class {
    breadcrumbs = [];
    apiKey;
    plugins;
    appId;
    appType;
    appVersion;
    releaseStage;
    locale;
    userAgent;
    metadata;
    persistedMetadata;
    onError;
    onPostErrorListeners = [];
    endpoints;
    session;
    constructor(e) {
        this.apiKey = e.apiKey, this.appType = e.appType, this.appId = e.appId, this.appVersion = e.appVersion, this.releaseStage = e.releaseStage, this.locale = e.locale, this.userAgent = e.userAgent, this.metadata = e.metadata, this.onError = e.onError, this.persistedMetadata = {}, this.endpoints = e.endpoints ? ? {
            notify: "https://error-analytics-production.shopifysvc.com",
            sessions: "https://error-analytics-sessions-production.shopifysvc.com/observeonly"
        }, this.plugins = e.plugins ? ? [], this.plugins.forEach((e => e.load(this))), this.leaveBreadcrumb("Bugsnag started", void 0, "state"), (e.withSessionTracking ? ? 1) && (this.session = {
            id: this.getRandomUUID(),
            startedAt: (new Date).toISOString(),
            events: {
                handled: 0,
                unhandled: 0
            }
        }, this.startSession())
    }
    addMetadata(e) {
        for (let t of Object.keys(e)) this.persistedMetadata[t] = e[t]
    }
    getSessionId() {
        return this.session ? .id
    }
    leaveBreadcrumb(e, t, n = "manual") {
        this.breadcrumbs.push({
            name: e,
            metaData: t,
            type: n,
            timestamp: (new Date).toISOString()
        })
    }
    notify(e, {
        errorClass: t,
        severity: n,
        severityType: o,
        handled: r = !0,
        metadata: i,
        context: a,
        groupingHash: s
    } = {}) {
        let l = jt(e),
            c = { ...this.metadata,
                ...this.persistedMetadata,
                ...i
            },
            d = this.buildBugsnagEvent(l, {
                errorClass: t,
                severityType: o,
                handled: r,
                severity: n,
                metadata: c,
                context: a,
                groupingHash: s
            });
        if ((this.onError ? .(d, e) ? ? 1) && "development" !== this.releaseStage) {
            this.updateAndAppendSessionInformation(d);
            let e = this.sendToBugsnag(d);
            return this.onPostErrorListeners.forEach((e => e(d))), e
        }
        return Promise.resolve()
    }
    addOnPostError(e) {
        this.onPostErrorListeners.push(e)
    }
    updateAndAppendSessionInformation(e) {
        this.session && (e.unhandled ? this.session.events.unhandled++ : this.session.events.handled++, e.session = this.session)
    }
    buildBugsnagEvent(e, {
        errorClass: t,
        severity: n = "error",
        severityType: o = "handledException",
        handled: r,
        metadata: i = {},
        context: a,
        groupingHash: s
    }) {
        let l = (new Date).toISOString(),
            {
                breadcrumbs: c,
                appId: d,
                appType: u,
                appVersion: p,
                releaseStage: h,
                locale: f,
                userAgent: m
            } = this,
            g = e.map(((e, n) => ({
                errorClass: 0 === n ? t ? ? e.name : e.name,
                stacktrace: $t(d, e),
                message: e.message,
                type: "browserjs"
            })));
        return {
            payloadVersion: "5",
            exceptions: g,
            severity: n,
            severityReason: {
                type: o
            },
            unhandled: !r,
            app: {
                id: d,
                type: u,
                version: p,
                releaseStage: h
            },
            device: {
                time: l,
                locale: f,
                userAgent: m
            },
            breadcrumbs: c,
            context: a,
            metaData: i,
            groupingHash: s
        }
    }
    async startSession() {
        if ("development" === this.releaseStage) return void console.log("Skipping error logging session tracking in development mode");
        let {
            apiKey: e
        } = this, t = {
            notifier: {
                name: "Bugsnag JavaScript",
                version: "7.22.2",
                url: "https://github.com/bugsnag/bugsnag-js"
            },
            app: {
                version: this.appVersion,
                releaseStage: this.releaseStage,
                type: this.appType
            },
            device: {
                id: this.appId,
                locale: this.locale,
                userAgent: this.userAgent
            },
            sessions: [this.session]
        };
        try {
            await fetch(this.endpoints.sessions, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Bugsnag-Api-Key": e,
                    "Bugsnag-Payload-Version": "5",
                    "Bugsnag-Sent-At": this.session ? .startedAt ? ? (new Date).toISOString()
                },
                body: JSON.stringify(t)
            })
        } catch (e) {
            console.warn("[bugsnag-light] failed to start session"), console.warn(e)
        }
    }
    async sendToBugsnag(e) {
        let {
            apiKey: t
        } = this, n = {
            apiKey: t,
            notifier: {
                name: "Bugsnag JavaScript",
                version: "7.22.2",
                url: "https://github.com/bugsnag/bugsnag-js"
            },
            events: [e]
        };
        try {
            await fetch(this.endpoints.notify, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Bugsnag-Api-Key": t,
                    "Bugsnag-Payload-Version": "5",
                    "Bugsnag-Sent-At": e.device.time
                },
                body: JSON.stringify(n)
            })
        } catch (e) {
            console.warn("[bugsnag-light] failed to send an event"), console.warn(e)
        }
    }
    getRandomUUID() {
        try {
            return crypto.randomUUID()
        } catch {
            return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (e => {
                let t = 16 * Math.random() | 0;
                return ("x" === e ? t : 3 & t | 8).toString(16)
            }))
        }
    }
};

function $t(e, t) {
    let n = Dt(t).map((t => {
        let n = t.file ? .includes(e);
        return {
            method: t.method ? ? "",
            file: t.file ? ? "",
            lineNumber: t.lineNumber ? ? 0,
            columnNumber: t.columnNumber,
            inProject: n
        }
    }));
    if (t instanceof Nt) {
        let e = n.findIndex((e => e.method.endsWith("notify")));
        e > -1 && (n = n.slice(e + 1))
    }
    return n
}
const Ft = "undefined" == typeof navigator ? {
    languages: [],
    userAgent: "",
    userAgentData: {},
    userLanguage: "",
    credentials: {}
} : navigator;
var Bt = "e35d7136cee78d344ccffdbd5ca710fa";

function Ht(e, t) {
    if (!{}.hasOwnProperty.call(e, t)) throw new TypeError("attempted to use private field on non-instance");
    return e
}
var Vt = 0;

function Wt(e) {
    return "__private_" + Vt++ + "_" + e
}

function qt(e) {
    return Object.entries(e).map((([e, t]) => ({
        key: e,
        value: {
            stringValue: String(t)
        }
    })))
}

function Kt(e) {
    if (Array.isArray(e)) return {
        arrayValue: {
            values: e.map((e => Kt(e)))
        }
    };
    switch (typeof e) {
        case "boolean":
            return {
                boolValue: Boolean(e)
            };
        case "number":
            return {
                doubleValue: Number(e)
            };
        default:
            return {
                stringValue: String(e)
            }
    }
}
const Xt = function(e, t, n) {
    const o = [0];
    for (let r = 0; r < n; r++) {
        const n = Math.floor(e * t ** r);
        o.push(n)
    }
    return o
}(5, 2, 12);
var Yt = Wt("exporter"),
    Gt = Wt("attributes"),
    Jt = Wt("metrics"),
    Zt = Wt("logs");
class Qt {
    constructor({
        exporter: e,
        attributes: t
    }) {
        Object.defineProperty(this, Yt, {
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, Gt, {
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, Jt, {
            writable: !0,
            value: []
        }), Object.defineProperty(this, Zt, {
            writable: !0,
            value: []
        }), Ht(this, Yt)[Yt] = e, Ht(this, Gt)[Gt] = null != t ? t : {}
    }
    addAttributes(e) {
        Ht(this, Gt)[Gt] = { ...Ht(this, Gt)[Gt],
            ...e
        }
    }
    histogram({
        name: e,
        value: t,
        unit: n,
        bounds: o,
        attributes: r,
        scale: i,
        requiresKeepalive: a
    }) {
        const s = 1e6 * Date.now();
        o ? Ht(this, Jt)[Jt].push({
            name: e,
            type: "histogram",
            value: t,
            unit: n,
            timeUnixNano: s,
            attributes: r,
            bounds: o,
            requiresKeepalive: a
        }) : Ht(this, Jt)[Jt].push({
            name: e,
            type: "exponential_histogram",
            value: t,
            unit: n,
            timeUnixNano: s,
            attributes: r,
            scale: i,
            requiresKeepalive: a
        })
    }
    counter({
        name: e,
        value: t,
        unit: n,
        attributes: o,
        requiresKeepalive: r
    }) {
        const i = 1e6 * Date.now();
        Ht(this, Jt)[Jt].push({
            name: e,
            type: "counter",
            value: t,
            unit: n,
            timeUnixNano: i,
            attributes: o,
            requiresKeepalive: r
        })
    }
    gauge({
        name: e,
        value: t,
        unit: n,
        attributes: o,
        requiresKeepalive: r
    }) {
        const i = 1e6 * Date.now();
        Ht(this, Jt)[Jt].push({
            name: e,
            type: "gauge",
            value: t,
            unit: n,
            timeUnixNano: i,
            attributes: o,
            requiresKeepalive: r
        })
    }
    log({
        body: e,
        attributes: t,
        requiresKeepalive: n
    }) {
        const o = 1e6 * Date.now();
        Ht(this, Zt)[Zt].push({
            timeUnixNano: o,
            body: e,
            attributes: t,
            requiresKeepalive: n
        })
    }
    async exportMetrics() {
        Ht(this, Jt)[Jt].forEach((e => {
            e.attributes = { ...Ht(this, Gt)[Gt],
                ...e.attributes
            }
        }));
        const e = Ht(this, Jt)[Jt];
        Ht(this, Jt)[Jt] = [], await this.exportByKeepalive(e, ((e, t) => Ht(this, Yt)[Yt].exportMetrics(this.aggregateMetrics(e), t)))
    }
    async exportLogs() {
        const e = Ht(this, Zt)[Zt];
        Ht(this, Zt)[Zt] = [], await this.exportByKeepalive(e, ((e, t) => Ht(this, Yt)[Yt].exportLogs(this.formatLogs(e), t)))
    }
    aggregateMetrics(e) {
        const t = {};
        return e.forEach((e => {
            switch (e.type) {
                case "histogram":
                    ! function(e, t) {
                        var n;
                        const {
                            name: o,
                            value: r,
                            unit: i,
                            timeUnixNano: a,
                            attributes: s
                        } = t, l = null !== (n = t.bounds) && void 0 !== n ? n : Xt, c = new Array(l.length + 1).fill(0);
                        e[o] || = {
                            name: o,
                            unit: i || "1",
                            histogram: {
                                aggregationTemporality: 1,
                                dataPoints: []
                            }
                        };
                        for (let e = 0; e < c.length; e++) {
                            const t = l[e];
                            if (void 0 === t) c[e] = 1;
                            else if (r <= t) {
                                c[e] = 1;
                                break
                            }
                        }
                        e[o].histogram.dataPoints.push({
                            startTimeUnixNano: a,
                            timeUnixNano: a,
                            count: 1,
                            sum: r,
                            min: r,
                            max: r,
                            bucketCounts: c,
                            explicitBounds: l,
                            attributes: qt(null != s ? s : {})
                        })
                    }(t, e);
                    break;
                case "exponential_histogram":
                    ! function(e, t) {
                        const {
                            name: n,
                            value: o,
                            unit: r,
                            timeUnixNano: i,
                            attributes: a,
                            scale: s
                        } = t;
                        e[n] || = {
                            name: n,
                            unit: r || "1",
                            exponentialHistogram: {
                                aggregationTemporality: 1,
                                dataPoints: []
                            }
                        };
                        const l = o <= 0 ? 0 : o,
                            c = s || 3,
                            d = 2 ** c / Math.log(2),
                            u = Math.ceil(Math.log(o) * d) - 1,
                            p = o <= 0 ? 1 : 0,
                            h = {
                                offset: 0,
                                bucketCounts: []
                            },
                            f = {
                                offset: o > 0 ? u : 0,
                                bucketCounts: o > 0 ? [1] : []
                            };
                        e[n].exponentialHistogram.dataPoints.push({
                            attributes: qt(null != a ? a : {}),
                            startTimeUnixNano: i,
                            timeUnixNano: i,
                            count: 1,
                            sum: l,
                            scale: c,
                            zeroCount: p,
                            positive: f,
                            negative: h,
                            min: l,
                            max: l,
                            zeroThreshold: 0
                        })
                    }(t, e);
                    break;
                case "counter":
                    ! function(e, t) {
                        const {
                            name: n,
                            value: o,
                            unit: r,
                            timeUnixNano: i,
                            attributes: a
                        } = t;
                        e[n] || = {
                            name: n,
                            unit: r || "1",
                            sum: {
                                aggregationTemporality: 1,
                                isMonotonic: !0,
                                dataPoints: []
                            }
                        }, e[n].sum.dataPoints.push({
                            startTimeUnixNano: i,
                            timeUnixNano: i,
                            asDouble: o,
                            attributes: qt(null != a ? a : {})
                        })
                    }(t, e);
                    break;
                case "gauge":
                    ! function(e, t) {
                        const {
                            name: n,
                            value: o,
                            unit: r,
                            timeUnixNano: i,
                            attributes: a
                        } = t;
                        e[n] || = {
                            name: n,
                            unit: r || "1",
                            gauge: {
                                dataPoints: []
                            }
                        }, e[n].gauge.dataPoints.push({
                            startTimeUnixNano: i,
                            timeUnixNano: i,
                            asDouble: o,
                            attributes: qt(null != a ? a : {})
                        })
                    }(t, e)
            }
        })), Object.values(t)
    }
    async exportByKeepalive(e, t) {
        if (0 === e.length) return;
        const n = [],
            o = [];
        e.forEach((e => {
            var t;
            null === (t = e.requiresKeepalive) || void 0 === t || t ? n.push(e) : o.push(e)
        }));
        const r = [n.length > 0 ? t(n, {
            keepalive: !0
        }) : void 0, o.length > 0 ? t(o, {
            keepalive: !1
        }) : void 0].filter((e => void 0 !== e));
        await Promise.all(r)
    }
    formatLogs(e) {
        return e.map((e => {
            const t = {
                timeUnixNano: e.timeUnixNano,
                observedTimeUnixNano: e.timeUnixNano,
                attributes: (n = { ...Ht(this, Gt)[Gt],
                    ...e.attributes
                }, Object.entries(n).map((([e, t]) => ({
                    key: e,
                    value: Kt(t)
                }))))
            };
            var n;
            return e.body && (t.body = {
                stringValue: e.body
            }), t
        }))
    }
}
var en, tn, nn = Wt("url"),
    on = Wt("serviceName"),
    rn = Wt("logger"),
    an = Wt("fetchFn"),
    sn = Wt("maxPayloadSizeBytes");
class ln {
    constructor(e, t, n) {
        var o;
        Object.defineProperty(this, nn, {
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, on, {
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, rn, {
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, an, {
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, sn, {
            writable: !0,
            value: void 0
        }), Ht(this, nn)[nn] = e.replace(/\/v1\/(logs|metrics|traces)\/?$/, ""), Ht(this, on)[on] = t, Ht(this, rn)[rn] = null == n ? void 0 : n.logger, Ht(this, an)[an] = null == n ? void 0 : n.fetchFn, Ht(this, sn)[sn] = null !== (o = null == n ? void 0 : n.maxPayloadSizeBytes) && void 0 !== o ? o : 51200
    }
    async exportMetrics(e, t) {
        var n;
        const o = null === (n = null == t ? void 0 : t.keepalive) || void 0 === n || n;
        await this.exportBatches("/v1/metrics", [...e], (e => ({
            resourceMetrics: [{
                resource: {
                    attributes: [{
                        key: "service.name",
                        value: {
                            stringValue: Ht(this, on)[on]
                        }
                    }]
                },
                scopeMetrics: [{
                    scope: {
                        name: "open-telemetry-mini-client",
                        version: "1.1.0",
                        attributes: []
                    },
                    metrics: e
                }]
            }]
        })), o)
    }
    async exportLogs(e, t) {
        var n;
        const o = null === (n = null == t ? void 0 : t.keepalive) || void 0 === n || n;
        await this.exportBatches("/v1/logs", [...e], (e => ({
            resourceLogs: [{
                resource: {
                    attributes: [{
                        key: "service.name",
                        value: {
                            stringValue: Ht(this, on)[on]
                        }
                    }]
                },
                scopeLogs: [{
                    scope: {
                        name: "open-telemetry-mini-client",
                        version: "1.1.0",
                        attributes: []
                    },
                    logRecords: e
                }]
            }]
        })), o)
    }
    async exportTo(e, t, n) {
        var o;
        const r = JSON.stringify(e),
            i = (new TextEncoder).encode(r).length;
        if (i > Ht(this, sn)[sn]) throw new dn(`Payload size ${i} exceeds ${Ht(this,sn)[sn]} bytes`);
        const a = await this.exporterFetch()(`${Ht(this,nn)[nn]}${t}`, {
            method: "POST",
            keepalive: n,
            headers: {
                "Content-Type": "application/json"
            },
            body: r
        });
        if (null === (o = Ht(this, rn)[rn]) || void 0 === o || o.log({
                status: a.status
            }), !a.ok) {
            if (400 === a.status) {
                const e = await a.text();
                throw new cn(`Invalid OpenTelemetry Data: ${e}`)
            }
            if (429 === a.status || 503 === a.status) {
                const t = await a.text(),
                    n = a.headers.get("Retry-After"),
                    o = n ? {
                        seconds: Number(n)
                    } : void 0;
                throw new cn("Server did not accept data", {
                    errorData: t,
                    retryAfter: o,
                    body: e
                })
            }
            if (401 === a.status || 403 === a.status) {
                const t = await a.text();
                throw new un(`Authentication failed: ${a.status} ${401===a.status?"Unauthorized":"Forbidden"}`, {
                    errorData: t,
                    body: e
                })
            }
            throw new cn(`Server responded with ${a.status}`)
        }
    }
    exporterFetch() {
        return Ht(this, an)[an] || fetch
    }
    async exportBatches(e, t, n, o) {
        let r = t.length;
        for (; t.length > 0;) try {
            const i = t.slice(0, r);
            await this.exportTo(n(i), e, o), t.splice(0, r)
        } catch (e) {
            if (!(e instanceof dn && r > 1)) throw e;
            r = Math.ceil(r / 2)
        }
    }
}
class cn extends Error {
    constructor(e, t) {
        super(e), this.metadata = void 0, this.name = "OpenTelemetryClientError", this.metadata = t
    }
}
class dn extends Error {
    constructor(...e) {
        super(...e), this.name = "PayloadTooLargeError"
    }
}
class un extends Error {
    constructor(e, t) {
        super(e), this.name = "AuthenticationFailedError", this.metadata = void 0, this.name = "AuthenticationFailedError", this.metadata = t
    }
}
class pn extends Qt {
    counter(e) {
        super.counter(e), this.exportMetrics()
    }
    gauge(e) {
        super.gauge(e), this.exportMetrics()
    }
    histogram(e) {
        super.histogram(e), this.exportMetrics()
    }
    log(e) {
        super.log(e), this.exportLogs()
    }
}
class hn {
    constructor({
        exporter: e,
        getKeepalive: t
    }) {
        en.set(this, void 0), tn.set(this, void 0), w(this, en, e, "f"), w(this, tn, t, "f")
    }
    exportMetrics(e, t) {
        return _(this, void 0, void 0, (function*() {
            var n;
            try {
                yield y(this, en, "f").exportMetrics(e, Object.assign(Object.assign({}, t), {
                    keepalive: y(this, tn, "f").call(this)
                }))
            } catch (o) {
                if (o instanceof cn) {
                    const r = null === (n = o.metadata) || void 0 === n ? void 0 : n.retryAfter;
                    if (r) return void(yield new Promise((n => {
                        setTimeout((() => this.exportMetrics(e, t).finally(n)), 1e3 * r.seconds)
                    })))
                }
                throw o
            }
        }))
    }
    exportLogs(e, t) {
        return _(this, void 0, void 0, (function*() {
            var n;
            try {
                yield y(this, en, "f").exportLogs(e, Object.assign(Object.assign({}, t), {
                    keepalive: y(this, tn, "f").call(this)
                }))
            } catch (o) {
                if (o instanceof cn) {
                    const r = null === (n = o.metadata) || void 0 === n ? void 0 : n.retryAfter;
                    if (r) return void(yield new Promise((n => {
                        setTimeout((() => this.exportLogs(e, t).finally(n)), 1e3 * r.seconds)
                    })))
                }
                throw o
            }
        }))
    }
}
en = new WeakMap, tn = new WeakMap;
const fn = {
    blockedRequest: "Blocked Request",
    emptyeEventCreatedAtMs: "event_created_at_ms metadata field cannot be empty",
    errorParsingCreatedAtMs: "Error parsing: X-Monorail-Edge-Event-Created-At-Ms",
    failedToReadRequestBody: "Failed to read request body",
    incorrectContentType: "Incorrect Content-Type. Expected: application/json or text/plain",
    methodNotAllowed: "Method Not Allowed",
    noPermissionToGetURL: "Your client does not have permission to get URL",
    noResponseFromEdge: "No response from edge",
    schemaValidationError: "Schema validation error"
};

function mn() {
    {
        const e = new ln("https://otlp-http-production.shopifysvc.com/v1/metrics", "shop-js");
        return new hn({
            exporter: e,
            getKeepalive: () => "readyState" in t && "complete" === t.readyState
        })
    }
}
const gn = ["Load failed", "Failed to fetch", "when attempting to fetch resource"],
    vn = ["NotFoundError", "NotSupportedError", "ReferenceError", "SyntaxError", "TypeError"],
    _n = ["development", "spin"].includes("production"),
    yn = e => {
        const {
            errorClass: t,
            message: n
        } = e;
        return Boolean("NetworkError" === t || gn.some((e => null == n ? void 0 : n.includes(e))) || (o = n, Boolean((null == o ? void 0 : o.includes("A network failure may have prevented the request from completing")) || (null == o ? void 0 : o.includes("Backpressure applied")))));
        var o
    },
    wn = ({
        event: e,
        metadata: n,
        onNetworkError: o
    }) => {
        var r, i, a, s, c, d;
        const u = e.exceptions[0];
        if (!u) return !1;
        if ((e => {
                const {
                    errorClass: t,
                    message: n
                } = e, o = "SecurityError" === t && (null == n ? void 0 : n.includes("Failed to read the 'cookie' property from 'Document'")) && (null == n ? void 0 : n.includes("sandboxed")), r = e.stacktrace.some((e => e.inProject));
                return Boolean(!r || o)
            })(u)) return !1;
        if ((e => vn.includes(e.errorClass))(u)) return !1;
        if (yn(u)) return o(), !1;
        const p = null === (i = null === (r = l.Shopify) || void 0 === r ? void 0 : r.featureAssets) || void 0 === i ? void 0 : i["shop-js"],
            h = Boolean(p && Object.keys(p).length > 0),
            f = Array.from(t.querySelectorAll('script[src*="/shop-js/"]')).map((e => e.src));
        e.device = {
            locale: Ft.userLanguage || Ft.language,
            userAgent: Ft.userAgent,
            orientation: null === (s = null === (a = l.screen) || void 0 === a ? void 0 : a.orientation) || void 0 === s ? void 0 : s.type,
            time: (new Date).toISOString()
        }, e.metaData = Object.assign(Object.assign(Object.assign({}, e.metaData), n), {
            custom: Object.assign(Object.assign(Object.assign({}, null === (c = e.metaData) || void 0 === c ? void 0 : c.custom), n.custom), {
                beta: !0,
                bundleLocale: "en",
                compactUX: !0,
                domain: null === (d = null == l ? void 0 : l.location) || void 0 === d ? void 0 : d.hostname,
                shopJsUrls: f,
                shopJsFeatureAssetsExist: h
            })
        }), e.request = {
            url: l.location.href
        }
    };
class bn {
    constructor(e) {
        this.opentelClient = new pn({
            exporter: mn()
        });
        const t = function({
            metadata: e,
            onNetworkError: t
        }) {
            return {
                apiKey: Bt,
                appId: "shop-js",
                appVersion: "1.0.34-beta",
                onError: n => wn({
                    event: n,
                    metadata: e,
                    onNetworkError: t
                }),
                releaseStage: "production",
                withSessionTracking: !1
            }
        }({
            metadata: {
                custom: {
                    feature: e
                }
            },
            onNetworkError: this.handleNetworkError.bind(this)
        });
        this.client = new zt(t), this.feature = e || "", this.leaveBreadcrumb = this.leaveBreadcrumb.bind(this), this.notify = this.notify.bind(this)
    }
    leaveBreadcrumb(e, t, n) {
        this.client ? _n ? console.log("[Bugsnag leaveBreadcrumb called]", e, t, n) : this.client.leaveBreadcrumb(e, t, n) : console.log("Bugsnag.leaveBreadcrumb() called before client creation.")
    }
    notify(e, t) {
        return _(this, void 0, void 0, (function*() {
            var n;
            this.client ? _n ? console.log("[Bugsnag notify called]", e) : this.client.notify(e, t) : null === (n = console.warn) || void 0 === n || n.call(console, "Bugsnag.notify() called before client creation.")
        }))
    }
    handleNetworkError() {
        this.opentelClient.counter({
            attributes: {
                feature: this.feature,
                error: "NetworkError"
            },
            name: "shop_js_network_error",
            value: 1
        })
    }
}
const xn = ({
    children: e
}) => {
    const {
        featureName: t
    } = Mt(), n = je((() => {
        var e;
        t || ["development", "spin"].includes("production") && (null === (e = console.warn) || void 0 === e || e.call(console, "BugsnagProvider created without a feature name."));
        const {
            client: n,
            leaveBreadcrumb: o,
            notify: r
        } = new bn(t);
        return {
            client: n,
            leaveBreadcrumb: o,
            notify: r
        }
    }), [t]);
    return ue(yt.Provider, {
        value: n,
        children: e
    })
};

function kn(e) {
    return e.replace(/[-:_]([a-z])/g, ((e, t) => `${t.toUpperCase()}`))
}

function En(e) {
    return e.replace(/([a-z0-9])([A-Z])/g, ((e, t, n) => `${t}-${n.toLowerCase()}`)).replace(/[\s_]+/g, "-")
}
class Sn extends Error {
    constructor(e, t, n = a()) {
        super(e), this.name = t, this.analyticsTraceId = n;
        const o = t.replace(/[A-Z]/g, (e => `_${e.toLowerCase()}`)).replace(/^_/, "");
        this.analyticsTraceId = n, this.code = o, this.name = t
    }
}

function Cn({
    children: e
}) {
    const [t] = function(e) {
        var t = Se(pe++, 10),
            n = Ce();
        return t.__ = e, he.componentDidCatch || (he.componentDidCatch = function(e, o) {
            t.__ && t.__(e, o), n[1](e)
        }), [n[0], function() {
            n[1](void 0)
        }]
    }(), {
        notify: n
    } = wt();
    return Me((() => {
        t && n(t instanceof Error ? t : new Sn(t, "UnhandledError"), {
            context: "Error in Preact tree"
        })
    }), [t, n]), ue(F, {
        children: e
    })
}

function Pn(e, t, n = !1) {
    let o;
    return function(...r) {
        const i = n && !o;
        "number" == typeof o && clearTimeout(o), o = setTimeout((() => {
            o = void 0, n || e.apply(this, r)
        }), t), i && e.apply(this, r)
    }
}

function Mn(e) {
    return _(this, arguments, void 0, (function*(e, {
        maxRetries: t = 3,
        retryDelay: n = 1e3,
        signal: o
    } = {}) {
        const r = e => _(this, [e], void 0, (function*({
            retryCount: e = 0,
            importPromise: i,
            retryImportPath: a
        }) {
            var s;
            if (!(null == o ? void 0 : o.aborted)) try {
                return i ? yield i(): yield(s = a || "",
                    import (s))
            } catch (i) {
                if (!(i instanceof Error) || (null == o ? void 0 : o.aborted)) return;
                const a = (e => {
                    try {
                        return new l.URL(e)
                    } catch (e) {
                        return null
                    }
                })(i.message.replace("Failed to fetch dynamically imported module: ", "").trim());
                if (!a) throw i;
                if (a.searchParams.set("t", `${Number(new Date)}`), e < t - 1) {
                    if (yield new Promise((e => setTimeout(e, n))), null == o ? void 0 : o.aborted) return;
                    return r({
                        retryCount: e + 1,
                        retryImportPath: a.href
                    })
                }
                throw i
            }
        }));
        return r({
            importPromise: e
        })
    }))
}
const On = ["en", "bg-BG", "cs", "da", "de", "el", "es", "fi", "fr", "hi", "hr-HR", "hu", "id", "it", "ja", "ko", "lt-LT", "ms", "nb", "nl", "pl", "pt-BR", "pt-PT", "ro-RO", "ru", "sk-SK", "sl-SI", "sv", "th", "tr", "vi", "zh-CN", "zh-TW"],
    Tn = ce({
        loading: void 0,
        locale: "en",
        translations: void 0
    });

function In(e) {
    return On.includes(e)
}
const jn = [],
    An = [],
    Nn = new Map;
const Ln = Pn((function(e) {
    let t = {};
    const n = Nn.get(e);
    An.forEach((e => {
        t = Object.assign(Object.assign({}, t), e)
    })), Nn.set(e, Object.assign(Object.assign({}, n), t)), jn.forEach((e => e())), jn.splice(0, jn.length), An.splice(0, An.length)
}), 250);

function Un({
    children: e,
    getFeatureDictionary: n,
    overrideLocale: o
}) {
    const {
        notify: r
    } = wt(), {
        recordCounter: i
    } = Ct(), {
        featureName: a
    } = Mt(), [s, c] = Ce(), [d, u] = Ce("en"), p = Ae((() => {
        var e;
        const n = Object.freeze([o, t.documentElement.lang, null === (e = l.Shopify) || void 0 === e ? void 0 : e.locale, ...Ft.languages].filter((e => e)));
        let r;
        for (const e of n) {
            if (In(e)) {
                r = e;
                break
            }
            try {
                const t = new Intl.Locale(e);
                if (t.language && In(t.language)) {
                    r = t.language;
                    break
                }
                i("shop_js_unsupported_locale", {
                    attributes: {
                        locale: e
                    }
                }), console.error(`Unsupported locale: "${e}"`)
            } catch (t) {
                i("shop_js_invalid_locale", {
                    attributes: {
                        locale: e
                    }
                }), console.error(`Invalid locale: "${e}"`)
            }
        }
        return r || "en"
    }), [o, i]), h = Ae((() => _(this, void 0, void 0, (function*() {
        if (In(d)) try {
            if (!Nn.has(d)) {
                c(!0);
                try {
                    const e = yield Mn((() => _(this, void 0, void 0, (function*() {
                        return {
                            button: {
                                close: "Close"
                            }
                        }
                    }))), {
                        maxRetries: 5,
                        retryDelay: 1e3
                    });
                    Nn.set(d, e)
                } catch (e) {
                    if ("en" !== d) throw new Sn("Failed to fetch non-English translations", "HandledTranslationFetchError");
                    r(new Sn(`Failed to load shared translations for "en" locale: ${e}`, "TranslationFetchError"))
                }
            }
            if (a && n) {
                c(!0);
                try {
                    const e = (yield n(d)) || {};
                    An.push(e)
                } catch (e) {
                    if ("en" !== d) throw new Sn("Failed to fetch non-English translations", "HandledTranslationFetchError");
                    r(new Sn(`Failed to load ${a} translations for "en" locale: ${e}`, "TranslationFetchError"))
                }
            }
            jn.push((() => c(!1))), Ln(d)
        } catch (e) {
            e instanceof Sn && "HandledTranslationFetchError" === e.name && (i("shop_js_handle_silent_error", {
                attributes: {
                    error: e.name,
                    locale: d
                }
            }), u("en"))
        }
    }))), [a, n, d, r, i]);
    Me((() => {
        const e = p();
        u(e)
    }), [p]), Me((() => {
        try {
            h()
        } catch (e) {
            e instanceof Error && r(e)
        }
    }), [h, d, r]);
    const f = je((() => ({
        loading: s,
        locale: d,
        translations: Nn
    })), [s, d]);
    return ue(Tn.Provider, {
        value: f,
        children: !1 === s && e
    })
}

function Dn(e, t = 200, n = !1) {
    const o = Te(),
        r = Te(e);
    return r.current = e, Ae(((...e) => {
        var i;
        const a = n && !o.current;
        "number" == typeof o.current && clearTimeout(o.current), o.current = setTimeout(((...e) => {
            var t;
            o.current = void 0, n || null === (t = r.current) || void 0 === t || t.call(r, ...e)
        }), t, ...e), a && (null === (i = r.current) || void 0 === i || i.call(r, ...e))
    }), [t, n])
}

function Rn(e, t, n) {
    return (t = function(e) {
        var t = function(e, t) {
            if ("object" != typeof e || !e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 !== n) {
                var o = n.call(e, t);
                if ("object" != typeof o) return o;
                throw new TypeError("@@toPrimitive must return a primitive value.")
            }
            return ("string" === t ? String : Number)(e)
        }(e, "string");
        return "symbol" == typeof t ? t : t + ""
    }(t)) in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e
}

function zn(e, t) {
    var n = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        t && (o = o.filter((function(t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable
        }))), n.push.apply(n, o)
    }
    return n
}

function $n(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n = null != arguments[t] ? arguments[t] : {};
        t % 2 ? zn(Object(n), !0).forEach((function(t) {
            Rn(e, t, n[t])
        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : zn(Object(n)).forEach((function(t) {
            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
        }))
    }
    return e
}
const Fn = "http://localhost:8082",
    Bn = "https://monorail-edge.shopifysvc.com",
    Hn = "/v1/produce";

function Vn(e) {
    return void 0 !== e.schemaId
}
class Wn {
    constructor(e) {
        this.producer = e
    }
    do(e, t) {
        return Vn(e) ? this.producer.produce(e) : this.producer.produceBatch(e)
    }
}

function qn() {
    if ("undefined" != typeof crypto && crypto && "function" == typeof crypto.randomUUID) return crypto.randomUUID();
    const e = new Array(36);
    for (let t = 0; t < 36; t++) e[t] = Math.floor(16 * Math.random());
    return e[14] = 4, e[19] = e[19] &= -5, e[19] = e[19] |= 8, e[8] = e[13] = e[18] = e[23] = "-", e.map((e => e.toString(16))).join("")
}

function Kn(e, t = !0) {
    return e && Object.keys(e).length && t ? Object.keys(e).map((t => ({
        [Xn(t)]: e[t]
    }))).reduce(((e, t) => $n($n({}, e), t))) : e
}

function Xn(e) {
    return e.split(/(?=[A-Z])/).join("_").toLowerCase()
}

function Yn(e) {
    return e.events.map((e => {
        let t = !0,
            n = !0;
        return e && e.options && Object.prototype.hasOwnProperty.call(e.options, "convertEventCase") && (t = Boolean(e.options.convertEventCase)), e && e.options && Object.prototype.hasOwnProperty.call(e.options, "convertMetaDataCase") && (n = Boolean(e.options.convertMetaDataCase)), $n({
            schema_id: e.schemaId,
            payload: Kn(e.payload, t)
        }, e.metadata && {
            metadata: Kn(e.metadata, n)
        })
    }))
}
class Gn extends Error {
    constructor(e) {
        super(`Error producing to the Monorail Edge. Response received: ${JSON.stringify(e)}`), Rn(this, "name", "MonorailUnableToProduceError"), this.response = e, Object.setPrototypeOf(this, Gn.prototype)
    }
}
class Jn extends Error {
    constructor(e) {
        super(`Response not from Monorail Edge. Response received: ${JSON.stringify(e)}`), Rn(this, "name", "MonorailInterceptedProduceError"), this.response = e, Object.setPrototypeOf(this, Jn.prototype)
    }
}
class Zn extends Error {
    constructor(e) {
        super(`Error producing to the Monorail Edge. Response received: ${JSON.stringify(e)}`), Rn(this, "name", "MonorailBatchProduceError"), Object.setPrototypeOf(this, Zn.prototype), this.response = e
    }
}
class Qn extends Error {
    constructor(e, t) {
        super(`Error completing request. A network failure may have prevented the request from completing. Error: ${e}. Schemas: ${Array.from(new Set(t)).join(", ")}`), Rn(this, "name", "MonorailRequestError"), Object.setPrototypeOf(this, Qn.prototype)
    }
}
class eo extends Error {
    constructor(e, t) {
        super(`Error reading response from Monorail Edge. Status: ${t||"unknown"}. Error: ${(null==e?void 0:e.message)||"Unknown error"}`), Rn(this, "name", "MonorailResponseReadError"), this.error = e, this.status = t, Object.setPrototypeOf(this, eo.prototype)
    }
}
class to {
    static withEndpoint(e) {
        return new to(`https://${new URL(e).hostname}`)
    }
    constructor(e = Fn, t = {}) {
        var n, o;
        if (this.edgeDomain = e, this.optionsOrKeepalive = t, "boolean" == typeof t) return this.keepalive = t, void(this.detectInterceptedErrorEnabled = !1);
        this.keepalive = null !== (n = t.keepalive) && void 0 !== n && n, this.detectInterceptedErrorEnabled = null !== (o = t.detectInterceptedErrorEnabled) && void 0 !== o && o
    }
    async produceBatch(e) {
        const t = {
            events: Yn(e),
            metadata: Kn(e.metadata)
        };
        let n, o;
        try {
            n = await fetch(this.produceBatchEndpoint(), {
                method: "post",
                headers: no(e.metadata),
                body: JSON.stringify(t),
                keepalive: this.keepalive
            })
        } catch (t) {
            throw new Qn(t, e.events.map((e => e.schemaId)))
        }
        if (207 === n.status) {
            const e = await n.json();
            throw new Zn(e)
        }
        try {
            o = await n.text()
        } catch (e) {
            throw new eo(e, n.status)
        }
        if (!n.ok) {
            if (!Boolean(n.headers.get("x-request-id")) && this.detectInterceptedErrorEnabled) throw new Jn({
                status: n.status,
                message: o
            });
            throw new Gn({
                status: n.status,
                message: o
            })
        }
        return {
            status: n.status
        }
    }
    async produce(e) {
        let t, n, o = !0;
        e && e.options && Object.prototype.hasOwnProperty.call(e.options, "convertEventCase") && (o = Boolean(e.options.convertEventCase));
        try {
            t = await async function({
                endpoint: e,
                event: t,
                keepalive: n
            }) {
                var o, r, i, a, s;
                const l = t.metadata ? {
                    clientMessageId: null === (o = t.metadata) || void 0 === o ? void 0 : o.clientMessageId,
                    eventCreatedAtMs: null === (r = t.metadata) || void 0 === r ? void 0 : r.eventCreatedAtMs,
                    consent: null === (i = t.metadata) || void 0 === i ? void 0 : i.consent,
                    consent_provider: null === (a = t.metadata) || void 0 === a ? void 0 : a.consent_provider,
                    consent_version: null === (s = t.metadata) || void 0 === s ? void 0 : s.consent_version
                } : void 0;
                return fetch(null != e ? e : Bn + Hn, {
                    method: "post",
                    headers: no(t.metadata),
                    body: JSON.stringify({
                        schema_id: t.schemaId,
                        payload: t.payload,
                        metadata: l && Kn(l, !0)
                    }),
                    keepalive: n
                })
            }({
                endpoint: this.produceEndpoint(),
                keepalive: this.keepalive,
                event: $n($n({}, e), {}, {
                    payload: Kn(e.payload, o)
                })
            })
        } catch (t) {
            throw new Qn(t, [e.schemaId])
        }
        if (!t) throw new Gn({
            message: "No response from edge"
        });
        try {
            n = await t.text()
        } catch (e) {
            throw new eo(e, t.status)
        }
        if (!t.ok) {
            if (!Boolean(t.headers.get("x-request-id")) && this.detectInterceptedErrorEnabled) throw new Jn({
                status: t.status,
                message: n
            });
            throw new Gn({
                status: t.status,
                message: n
            })
        }
        return {
            status: t.status
        }
    }
    produceBatchEndpoint() {
        return this.edgeDomain + "/unstable/produce_batch"
    }
    produceEndpoint() {
        return this.edgeDomain + Hn
    }
}

function no(e) {
    const t = {
        "Content-Type": "application/json; charset=utf-8",
        "X-Monorail-Edge-Event-Created-At-Ms": (e && e.eventCreatedAtMs || Date.now()).toString(),
        "X-Monorail-Edge-Event-Sent-At-Ms": Date.now().toString(),
        "X-Monorail-Edge-Client-Message-Id": (e && e.clientMessageId || qn()).toString()
    };
    return e && e.userAgent && (t["User-Agent"] = e.userAgent), e && e.remoteIp && (t["X-Forwarded-For"] = e.remoteIp), e && e.deviceInstallId && (t["X-Monorail-Edge-Device-Install-Id"] = e.deviceInstallId), e && e.client && (t["X-Monorail-Edge-Client"] = e.client), e && e.clientOs && (t["X-Monorail-Edge-Client-OS"] = e.clientOs), t
}
class oo {
    static printWelcomeMessage(e) {
        console.log(`%c👋 from Monorail%c\n\nWe've noticed that you're${e?"":" not"} running in debug mode. As such, we will ${e?"produce":"not produce"} Monorail events to the console. \n\nIf you want Monorail events to ${e?"stop":"start"} appearing here, %cset debugMode=${(!e).toString()}%c, for the Monorail Log Producer in your code.`, "font-size: large;", "font-size: normal;", "font-weight: bold;", "font-weight: normal;")
    }
    constructor(e) {
        this.sendToConsole = e, e && oo.printWelcomeMessage(e)
    }
    async produce(e) {
        return this.sendToConsole && console.log("Monorail event produced", e), new Promise((t => {
            t(e)
        }))
    }
    produceBatch(e) {
        return this.sendToConsole && console.log("Monorail Batch event produced", e), new Promise((t => {
            t(e)
        }))
    }
}
class ro {
    constructor(e) {
        this.version = e.version
    }
}
class io {
    constructor(e, t = () => !1) {
        if (Rn(this, "eventsAwaitingConsent", []), null == e || !e.provider) throw new ao("ConsentTrackingMiddleware requires an instance of ConsentTrackingProvider");
        this.isStrictlyNecessary = t, this.provider = e.provider
    }
    async do(e, t) {
        if (Vn(e)) {
            const n = await this.provider.annotateEvent(e);
            return this.isConsentGivenForEmission(n) ? (await this.processBufferedEvents(t), t(n)) : this.isStrictlyNecessary(n) ? t(n) : (this.eventsAwaitingConsent.push(e), Promise.resolve({
                status: 0,
                message: "Consent not granted and event not marked strictly necessary, event not sent"
            }))
        } {
            if (this.isConsentGivenForEmission(await this.provider.annotateEvent(e.events[0]))) {
                await this.processBufferedEvents(t);
                const n = await Promise.all(e.events.map((e => this.provider.annotateEvent(e))));
                return t($n($n({}, e), {}, {
                    events: n
                }))
            }
            const n = e.events.filter((e => !!this.isStrictlyNecessary(e) || (this.eventsAwaitingConsent.push(e), !1)));
            if (n.length > 0) {
                const o = await Promise.all(n.map((e => this.provider.annotateEvent(e))));
                return t($n($n({}, e), {}, {
                    events: o
                }))
            }
            return Promise.resolve({
                status: 0,
                message: "Consent not granted for any event, and no event marked strictly necessary, event batch not sent"
            })
        }
    }
    isConsentGivenForEmission(e) {
        var t;
        const n = null === (t = e.metadata) || void 0 === t ? void 0 : t.consent,
            o = this.provider.getRequiredConsentForEmission();
        return Boolean(Array.isArray(n) && n.some((e => o.includes(e))))
    }
    async
    processBufferedEvents(e) {
        if (0 === this.eventsAwaitingConsent.length) return;
        const t = this.eventsAwaitingConsent;
        this.eventsAwaitingConsent = [];
        const n = await Promise.all(t.map((e => this.provider.annotateEvent(e))));
        await e({
            events: n
        })
    }
}
class ao extends Error {
    constructor(e) {
        super(e), Object.setPrototypeOf(this, ao.prototype)
    }
}

function so(e, t) {
    var n, o, r;
    if (e === t) return !0;
    if (typeof e != typeof t) return !1;
    if ("function" == typeof e && void 0 !== (null === (n = e.toString) || void 0 === n ? void 0 : n.call(e)) && (null === (o = e.toString) || void 0 === o ? void 0 : o.call(e)) === (null === (r = t.toString) || void 0 === r ? void 0 : r.call(t))) return !0;
    if (e && t && "object" == typeof e && "object" == typeof t) {
        if (e.constructor !== t.constructor) return !1;
        let n, o;
        const r = Object.keys(e);
        if (Array.isArray(e)) {
            if (n = e.length, n !== t.length) return !1;
            for (o = n; 0 != o--;)
                if (!so(e[o], t[o])) return !1;
            return !0
        }
        if (e.valueOf !== Object.prototype.valueOf) return e.valueOf() === t.valueOf();
        if (e.toString !== Object.prototype.toString) return e.toString() === t.toString();
        if (n = r.length, n !== Object.keys(t).length) return !1;
        for (o = n; 0 != o--;)
            if (!Object.prototype.hasOwnProperty.call(t, r[o])) return !1;
        for (o = n; 0 != o--;) {
            const n = r[o];
            if (!so(e[n], t[n])) return !1
        }
        return !0
    }
    return e != e && t != t
}
const lo = "",
    co = "1",
    uo = "0",
    po = "p",
    ho = "a",
    fo = "m",
    mo = "t",
    go = "m",
    vo = "a",
    _o = "p",
    yo = "s";

function wo(e) {
    try {
        return decodeURIComponent(e)
    } catch (e) {
        return ""
    }
}

function bo(e, t = !1) {
    const n = function() {
        try {
            return document.cookie
        } catch {
            return !1
        }
    }() ? document.cookie.split("; ") : [];
    for (let t = 0; t < n.length; t++) {
        const [o, r] = n[t].split("=");
        if (e === wo(o)) {
            return wo(r)
        }
    }
    if (t && "_tracking_consent" === e && !window.localStorage.getItem("tracking_consent_fetched")) {
        if ("undefined" != typeof __CtaTestEnv__ && "true" === __CtaTestEnv__) return;
        return console.debug("_tracking_consent missing"),
            function(e = "/") {
                const t = new XMLHttpRequest;
                t.open("HEAD", e, !1), t.withCredentials = !0, t.send()
            }(), window.localStorage.setItem("tracking_consent_fetched", "true"), bo(e, !1)
    }
}

function xo() {
    const e = new URLSearchParams(window.location.search).get("_cs") || bo("_tracking_consent");
    if (void 0 !== e) return function(e) {
        const t = e.slice(0, 1);
        if ("{" == t) return function(e) {
            var t;
            let n;
            try {
                n = JSON.parse(e)
            } catch {
                return
            }
            if ("2.1" !== n.v) return;
            if (null === (t = n.con) || void 0 === t || !t.CMP) return;
            return n
        }(e);
        if ("3" == t) return function(e) {
            const t = e.slice(1).split("_"),
                [n, o, r, i, a] = t;
            let s, l;
            try {
                s = t[5] ? JSON.parse(t.slice(5).join("_")) : void 0
            } catch {}
            if (a) {
                const e = a.replace(/\*/g, "/").replace(/-/g, "+"),
                    t = Array.from(atob(e)).map((e => e.charCodeAt(0).toString(16).padStart(2, "0"))).join("");
                l = [8, 13, 18, 23].reduce(((e, t) => e.slice(0, t) + "-" + e.slice(t)), t)
            }

            function c(e) {
                const t = n.split(".")[0];
                return t.includes(e.toLowerCase()) ? uo : t.includes(e.toUpperCase()) ? co : lo
            }

            function d(e) {
                return n.includes(e.replace("t", "s").toUpperCase())
            }
            return {
                v: "3",
                con: {
                    CMP: {
                        [vo]: c(vo),
                        [_o]: c(_o),
                        [go]: c(go),
                        [yo]: c(yo)
                    }
                },
                region: o || "",
                cus: s,
                purposes: {
                    [ho]: d(ho),
                    [po]: d(po),
                    [fo]: d(fo),
                    [mo]: d(mo)
                },
                sale_of_data_region: "t" == i,
                display_banner: "t" == r,
                consent_id: l
            }
        }(e);
        return
    }(e)
}

function ko(e) {
    const t = xo();
    if (!t || !t.purposes) return !0;
    const n = t.purposes[e];
    return "boolean" != typeof n || n
}

function Eo() {
    return ko(ho)
}

function So() {
    return ko(po)
}

function Co() {
    return ko(fo)
}

function Po() {
    return ko(mo)
}

function Mo() {
    const e = [];
    return Eo() && e.push("analytics"), Co() && e.push("marketing"), Po() && e.push("sale_of_data"), So() && e.push("preferences"), e
}
class Oo extends ro {
    async annotateEvent(e) {
        return Promise.resolve(function(e, t) {
            if ("v1" === t) {
                const n = Mo();
                return { ...e,
                    metadata: { ...null == e ? void 0 : e.metadata,
                        consent: n,
                        consent_provider: "consent-tracking-api",
                        consent_version: t
                    }
                }
            }
            throw new To(t || "unknown")
        }(e, this.version))
    }
    getRequiredConsentForEmission() {
        if ("v1" === this.version) return ["analytics", "marketing"];
        throw new To(this.version || "unknown")
    }
}
class To extends Error {
    constructor(e) {
        super(`Version ${e} is not supported by the consent-tracking-api provider`), this.name = "MonorailConsentTrackingApiProviderVersionError", Object.setPrototypeOf(this, To.prototype)
    }
}

function Io() {
    var e;
    const n = null === (e = t.querySelector("script#shop-js-analytics")) || void 0 === e ? void 0 : e.innerHTML;
    return n ? JSON.parse(n) : {}
}

function jo() {
    return _(this, void 0, void 0, (function*() {
        let e;
        return Promise.race([new Promise((t => e = setTimeout((() => t({})), 1e4))), new Promise((e => {
            var t, n, o;
            const r = (null === (n = null === (t = l.ShopifyAnalytics) || void 0 === t ? void 0 : t.lib) || void 0 === n ? void 0 : n.ready) || (null === (o = l.analytics) || void 0 === o ? void 0 : o.ready);
            null == r || r((() => {
                var t, n, o, r;
                const i = (null === (n = null === (t = l.ShopifyAnalytics) || void 0 === t ? void 0 : t.lib) || void 0 === n ? void 0 : n.trekkie) || (null === (o = l.analytics) || void 0 === o ? void 0 : o.trekkie),
                    a = null !== (r = null == i ? void 0 : i.defaultAttributes) && void 0 !== r ? r : {};
                e(a)
            }))
        }))]).finally((() => clearTimeout(e)))
    }))
}

function Ao(...e) {
    return _(this, void 0, void 0, (function*() {
        var t;
        if (!l.ShopifyAnalytics && !l.analytics) return {};
        let n;
        Boolean(null === (t = l.trekkie) || void 0 === t ? void 0 : t.ready) ? n = jo() : (l.trekkie = l.trekkie || [], n = new Promise((e => {
            l.trekkie.push(["ready", () => {
                e(jo())
            }])
        })));
        const o = yield n;
        return e.reduce(((e, t) => {
            const n = o[t];
            return void 0 !== n && (e[t] = n), e
        }), {})
    }))
}
var No;
const Lo = "unspecified",
    Uo = function() {
        const e = new Oo({
            version: "v1"
        });
        return [new io({
            provider: e
        })]
    }(),
    Do = ["authorize_step_changed", "createprequal", "resize_iframe", "setcomponentstyle", "verification_step_changed"],
    Ro = class e {
        static createLogProducer(t) {
            return new e(new oo(t.debugMode), t.middleware || [])
        }
        static createHttpProducerWithEndpoint(t, n = []) {
            return new e(to.withEndpoint(t), n)
        }
        static createHttpProducer(t) {
            return new e(t.production ? new to(Bn, t.options) : new to(Fn, t.options), t.middleware || [])
        }
        static buildMiddlewareChain(e, t = 0) {
            return t === e.length ? this.identityFn : n => e[t].do(n, this.buildMiddlewareChain(e, t + 1))
        }
        constructor(t, n) {
            this.producer = t, this.middleware = n, this.executeChain = e.buildMiddlewareChain(this.middleware.concat(new Wn(t)))
        }
        produce(e) {
            return e.metadata = $n({
                eventCreatedAtMs: Date.now(),
                clientMessageId: qn()
            }, e.metadata), this.executeChain(e)
        }
        produceBatch(e) {
            return this.executeChain(e)
        }
    }.createHttpProducer({
        production: !0,
        middleware: Uo
    });
class zo {
    constructor({
        analyticsData: e,
        devMode: t = !1,
        notify: n,
        recordCounter: o
    }) {
        var r;
        No.set(this, void 0), this.featureInitializationEventAlreadyEmitted = !1, this.trackedPageImpressions = new Set, w(this, No, Object.assign(Object.assign({}, e), {
            flowVersion: null !== (r = e.flowVersion) && void 0 !== r ? r : Lo
        }), "f"), this.devMode = t, this.notify = n, this.recordCounter = o, this.clearTrackedPageImpressions = this.clearTrackedPageImpressions.bind(this), this.produceMonorailEvent = this.produceMonorailEvent.bind(this), this.trackFeatureInitialization = this.trackFeatureInitialization.bind(this), this.trackModalStateChange = this.trackModalStateChange.bind(this), this.trackPageImpression = this.trackPageImpression.bind(this), this.trackUserAction = this.trackUserAction.bind(this), this.trackPostMessageTransmission = this.trackPostMessageTransmission.bind(this)
    }
    get analyticsData() {
        return y(this, No, "f")
    }
    set analyticsData(e) {
        const t = Object.assign(Object.assign({}, y(this, No, "f")), e);
        so(t, y(this, No, "f")) || w(this, No, t, "f")
    }
    clearTrackedPageImpressions() {
        this.trackedPageImpressions.clear()
    }
    produceMonorailEvent({
        event: e,
        onError: t,
        trekkieAttributes: n
    }) {
        this.devMode || (!n || Object.keys(n).length ? (e.payload = Object.assign(e.payload, n), Ro.produce(e).catch((e => {
            var n;
            if (null == t || t(e), function(e) {
                    var t, n, o, r, i, a, s;
                    const l = e instanceof eo && 200 === e.status;
                    return !(e instanceof Qn || e instanceof Gn || (null === (t = null == e ? void 0 : e.message) || void 0 === t ? void 0 : t.includes("Invalid agent:")) || (null === (n = null == e ? void 0 : e.message) || void 0 === n ? void 0 : n.includes(".text is not a function")) || (null === (o = null == e ? void 0 : e.message) || void 0 === o ? void 0 : o.includes("event_sent_at_ms metadata field cannot be empty")) || (null === (r = null == e ? void 0 : e.message) || void 0 === r ? void 0 : r.includes("event_created_at_ms metadata field cannot be empty.")) || (null === (i = null == e ? void 0 : e.message) || void 0 === i ? void 0 : i.match(/Cannot read properties of (null|undefined) \(reading 'status'\)/)) || (null === (a = null == e ? void 0 : e.message) || void 0 === a ? void 0 : a.match(/(null|undefined) is not an object \(evaluating '[a-zA-Z]+\.status'\)/)) || (null === (s = null == e ? void 0 : e.message) || void 0 === s ? void 0 : s.match(/[a-zA-Z]+ is (null|undefined)/)) || l)
                }(e)) {
                const t = e instanceof Error ? e : new Sn(String(e), "MonorailProducerError");
                if (null === (n = this.notify) || void 0 === n || n.call(this, t), this.recordCounter) {
                    const e = function(e) {
                        const t = Object.values(fn).find((([t, n]) => e.message.includes(n)));
                        return (null == t ? void 0 : t[0]) || "otherErrors"
                    }(t);
                    this.recordCounter("shop_js_monorail_producer_error", {
                        attributes: {
                            error: e
                        }
                    })
                }
            }
        }))) : null == t || t({
            message: "trekkie attributes are empty"
        }))
    }
    trackFeatureInitialization() {
        return _(this, void 0, void 0, (function*() {
            var e, t, n, o;
            const {
                analyticsTraceId: r,
                apiKey: i,
                checkoutToken: a,
                flow: s,
                flowVersion: c = Lo,
                shopId: d,
                source: u = "unspecified",
                uxMode: p
            } = this.analyticsData;
            if (!s) return;
            this.featureInitializationEventAlreadyEmitted && (null === (e = this.notify) || void 0 === e || e.call(this, new Sn(`Feature Initialize Event already emitted once for the feature ${s}`, "MonorailLogicError", r)));
            const h = Io(),
                f = null !== (t = null == h ? void 0 : h.pageType) && void 0 !== t ? t : "",
                m = yield Ao("customerId", "isPersistentCookie", "path", "uniqToken", "visitToken"), g = Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, i && {
                    apiKey: i
                }), a && {
                    checkoutToken: a
                }), d && {
                    shopId: d
                }), m), {
                    analyticsTraceId: r,
                    flow: s,
                    flowVersion: c,
                    sdkVersion: "1.0.34-beta",
                    shopPermanentDomain: null !== (o = null === (n = l.Shopify) || void 0 === n ? void 0 : n.shop) && void 0 !== o ? o : "",
                    source: u,
                    storefrontPageType: f,
                    uxMode: p
                });
            this.featureInitializationEventAlreadyEmitted = !0, this.produceMonorailEvent({
                event: {
                    schemaId: "shopify_pay_login_with_shop_sdk_feature_initialize/1.1",
                    payload: g
                }
            })
        }))
    }
    trackModalStateChange({
        currentState: e,
        dismissMethod: t,
        reason: n
    }) {
        var o;
        const {
            analyticsTraceId: r,
            checkoutToken: i,
            flow: a,
            flowVersion: s = "unspecified"
        } = this.analyticsData;
        a && (this.produceMonorailEvent({
            event: {
                schemaId: "shop_identity_modal_state_change/1.4",
                payload: {
                    analyticsTraceId: r,
                    checkoutToken: i,
                    currentState: e,
                    dismissMethod: t,
                    flow: a,
                    flowVersion: s,
                    previousState: this.previousModalState,
                    reason: n,
                    zoom: `${null===(o=l.visualViewport)||void 0===o?void 0:o.scale}`
                }
            }
        }), this.previousModalState = e)
    }
    trackPageImpression(e) {
        return _(this, arguments, void 0, (function*({
            allowDuplicates: e = !1,
            analyticsTraceId: t = this.analyticsData.analyticsTraceId,
            flow: n = this.analyticsData.flow,
            page: o,
            shopAccountUuid: r
        }) {
            var i, a, s;
            if (!e && this.trackedPageImpressions.has(o)) return;
            const {
                apiKey: c,
                checkoutToken: d,
                flowVersion: u = Lo
            } = this.analyticsData;
            if (!n) return;
            this.trackedPageImpressions.add(o);
            const p = Io(),
                h = null !== (i = null == p ? void 0 : p.pageType) && void 0 !== i ? i : "",
                f = yield Ao("customerId", "isPersistentCookie", "path", "uniqToken", "visitToken"), m = Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, c && {
                    apiKey: c
                }), d && {
                    checkoutToken: d
                }), r && {
                    shopAccountUuid: r
                }), f), {
                    analyticsTraceId: t,
                    flow: n,
                    flowVersion: u,
                    pageName: o,
                    sdkVersion: "1.0.34-beta",
                    shopPermanentDomain: null !== (s = null === (a = l.Shopify) || void 0 === a ? void 0 : a.shop) && void 0 !== s ? s : "",
                    storefrontPageType: h
                });
            this.produceMonorailEvent({
                event: {
                    payload: m,
                    schemaId: "shopify_pay_login_with_shop_sdk_page_impressions/3.3"
                },
                onError: () => {
                    this.trackedPageImpressions.delete(o)
                },
                trekkieAttributes: f
            })
        }))
    }
    trackUserAction({
        userAction: e
    }) {
        var t, n;
        const {
            analyticsTraceId: o,
            apiKey: r,
            checkoutToken: i,
            checkoutVersion: a,
            flow: s,
            flowVersion: c = Lo,
            shopId: d
        } = this.analyticsData;
        if (!s) return;
        const u = Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, r && {
            apiKey: r
        }), i && {
            checkoutToken: i
        }), a && {
            checkoutVersion: a
        }), d && {
            shopId: d
        }), {
            analyticsTraceId: o,
            flow: s,
            flowVersion: c,
            sdkVersion: "1.0.34-beta",
            shopPermanentDomain: null !== (n = null === (t = l.Shopify) || void 0 === t ? void 0 : t.shop) && void 0 !== n ? n : "",
            userAction: e
        });
        this.produceMonorailEvent({
            event: {
                schemaId: "shopify_pay_login_with_shop_sdk_user_actions/2.2",
                payload: u
            }
        })
    }
    trackPostMessageTransmission({
        direction: e,
        event: t
    }) {
        var n;
        const o = t.type;
        if (Do.includes(o)) return;
        const r = Date.now(),
            i = t.messageId,
            {
                analyticsTraceId: a,
                checkoutToken: s,
                shopPermanentDomain: l
            } = this.analyticsData,
            c = function(e) {
                return "email" in e
            }(t) ? t.email : void 0,
            d = {
                eventType: o,
                direction: e,
                actor: "shop-js"
            };
        null === (n = this.recordCounter) || void 0 === n || n.call(this, "shop_js_post_message_transmission", {
            attributes: d
        }), this.produceMonorailEvent({
            event: {
                schemaId: "shop_identity_post_message_transmission/1.0",
                payload: {
                    messageId: i,
                    messageDirection: e,
                    actor: "shop-js",
                    payloadType: o,
                    clientTimestampMs: r,
                    analyticsTraceId: a,
                    checkoutToken: s,
                    shopifyDomain: l,
                    email: c
                }
            }
        })
    }
}
No = new WeakMap;
const $o = ({
    analyticsContext: e = "loginWithShop",
    apiKey: t,
    checkoutVersion: n,
    checkoutToken: o,
    children: r,
    flow: i,
    flowVersion: a,
    shopId: s = 0,
    shopPermanentDomain: l,
    source: c,
    uxMode: d
}) => {
    const {
        notify: u
    } = wt(), {
        recordCounter: p
    } = Ct(), {
        devMode: h,
        instanceId: f
    } = Mt(), m = Te({
        analyticsContext: e,
        analyticsTraceId: f,
        apiKey: t,
        checkoutVersion: n,
        checkoutToken: o,
        flow: i,
        flowVersion: a,
        shopId: s,
        shopPermanentDomain: l,
        source: c,
        uxMode: d
    }), g = je((() => new zo({
        analyticsData: m.current,
        devMode: h,
        notify: u,
        recordCounter: p
    })), [h, u, p]);
    g.analyticsData = Object.assign(Object.assign({}, m.current), {
        analyticsTraceId: f,
        analyticsContext: e,
        apiKey: t,
        checkoutVersion: n,
        checkoutToken: o,
        flow: i,
        flowVersion: a,
        shopId: s,
        shopPermanentDomain: l,
        source: c,
        uxMode: d
    }), Me((() => () => {
        g.clearTrackedPageImpressions()
    }), [g]);
    const v = Dn((() => {
        g.trackFeatureInitialization()
    }), 100);
    Me((() => {
        v()
    }), [v]);
    const _ = je((() => ({
        analyticsData: g.analyticsData,
        getTrekkieAttributes: Ao,
        produceMonorailEvent: g.produceMonorailEvent,
        trackModalStateChange: g.trackModalStateChange,
        trackPageImpression: g.trackPageImpression,
        trackUserAction: g.trackUserAction,
        trackPostMessageTransmission: g.trackPostMessageTransmission
    })), [g.analyticsData, g.produceMonorailEvent, g.trackModalStateChange, g.trackPageImpression, g.trackUserAction, g.trackPostMessageTransmission]);
    return ue(kt.Provider, {
        value: _,
        children: r
    })
};

function Fo({
    children: e
}) {
    const {
        featureName: t
    } = Mt(), n = je((() => new pn({
        exporter: mn()
    })), []), o = Ae((({
        body: e,
        attributes: o
    }) => {
        n.log({
            body: e,
            attributes: Object.assign({
                beta: !0,
                feature: t
            }, o)
        })
    }), [n, t]), r = Ae(((e, o = {}) => {
        const {
            attributes: r,
            unit: i,
            value: a = 1
        } = o;
        n.counter({
            attributes: Object.assign({
                beta: !0,
                feature: t
            }, r),
            name: e,
            value: a,
            unit: i
        })
    }), [n, t]), i = Ae(((e, o = {}) => {
        const {
            attributes: r,
            unit: i,
            value: a = 1
        } = o;
        n.gauge({
            attributes: Object.assign({
                beta: !0,
                feature: t
            }, r),
            name: e,
            value: a,
            unit: i
        })
    }), [n, t]), a = Ae(((e, o = {}) => {
        const {
            attributes: r,
            unit: i,
            value: a = 1,
            bounds: s
        } = o;
        n.histogram({
            attributes: Object.assign({
                beta: !0,
                feature: t
            }, r),
            bounds: s,
            name: e,
            value: a,
            unit: i
        })
    }), [n, t]), s = je((() => ({
        client: n,
        log: o,
        recordCounter: r,
        recordGauge: i,
        recordHistogram: a
    })), [n, o, r, i, a]);
    return ue(St.Provider, {
        value: s,
        children: e
    })
}
const Bo = "gravity-font-faces",
    Ho = ({
        authorizeStateEnabled: e = !0,
        children: n,
        devMode: o = !1,
        element: r,
        featureName: i,
        getFeatureDictionary: s,
        metricsEnabled: l = !0,
        monorailProps: c,
        overrideLocale: d
    }) => {
        Me((() => {
            if (t.querySelector(`style[data-description="${Bo}"]`)) return;
            const e = t.createElement("style");
            e.dataset.description = Bo, e.appendChild(t.createTextNode("\n@font-face {\n  font-family: 'GTStandard-M';\n  src: url('https://cdn.shopify.com/shop-assets/static_uploads/shoplift/GTStandard-MRegular.woff2')\n    format('woff2');\n  font-style: normal;\n  font-weight: 450;\n  font-display: swap;\n}\n\n@font-face {\n  font-family: 'GTStandard-M';\n  src: url('https://cdn.shopify.com/shop-assets/static_uploads/shoplift/GTStandard-MMedium.woff2')\n    format('woff2');\n  font-style: normal;\n  font-weight: 500;\n  font-display: swap;\n}\n\n@font-face {\n  font-family: 'GTStandard-M';\n  src: url('https://cdn.shopify.com/shop-assets/static_uploads/shoplift/GTStandard-MSemibold.woff2')\n    format('woff2');\n  font-style: normal;\n  font-weight: 600;\n  font-display: swap;\n}")), t.head.appendChild(e)
        }), []);
        const u = je((() => a()), []);
        Me((() => {
            r && r.setAttribute("data-instance-id", u)
        }), [r, u]);
        const p = je((() => ({
            devMode: o,
            element: r,
            featureName: i,
            instanceId: u
        })), [o, r, i, u]);
        return ue(Pt.Provider, {
            value: p,
            children: ue(Vo, {
                enabled: l,
                monorailProps: c,
                children: ue(Un, {
                    getFeatureDictionary: s,
                    overrideLocale: d,
                    children: ue(Wo, {
                        enabled: e,
                        children: n
                    })
                })
            })
        })
    };

function Vo({
    children: e,
    enabled: t = !0,
    monorailProps: n
}) {
    return t ? ue(xn, {
        children: ue(Cn, {
            children: ue(Fo, {
                children: ue($o, Object.assign({}, n, {
                    children: e
                }))
            })
        })
    }) : ue(F, {
        children: e
    })
}

function Wo({
    children: e,
    enabled: t = !0
}) {
    return t ? ue(It, {
        children: e
    }) : e
}
const qo = () => Ne(Tn),
    Ko = ["string", void 0],
    Xo = () => {
        const {
            locale: e,
            translations: t
        } = qo();
        return {
            locale: e,
            translate: (n, o) => {
                const r = n.split(".");
                if (!t || !e) throw new ReferenceError;
                const i = o || {},
                    {
                        count: a,
                        defaultValue: s
                    } = i,
                    l = v(i, ["count", "defaultValue"]);
                let c = t.get(e);
                if (!c && (null == o ? void 0 : o.defaultValue)) return o.defaultValue;
                try {
                    for (const e of r) switch (typeof c) {
                        case "object":
                            c = c[e];
                            break;
                        case "string":
                        case "undefined":
                            throw new ReferenceError
                    }
                    if (void 0 === c) throw new ReferenceError;
                    if ("string" != typeof t && a) {
                        let e = 1 === a ? "one" : "other";
                        0 === a && "string" != typeof t && "zero" in t && (e = "zero"), c = c[e]
                    }
                    if ("string" != typeof c) throw new ReferenceError;
                    let e = !1;
                    const n = Object.keys(l),
                        o = c.split(new RegExp(`({${n.join("}|{")}})`, "g"));
                    return n.forEach((t => {
                        e || Ko.includes(typeof l[t]) || (e = !0), o.forEach(((e, n) => {
                            e === `{${t}}` && (o[n] = l[t])
                        }))
                    })), e ? ue(F, {
                        children: o
                    }) : o.join("")
                } catch (e) {
                    return s || n
                }
            }
        }
    };

function Yo(e) {
    const {
        element: t
    } = Mt(), {
        loading: n
    } = qo();
    Me((() => {
        if (t && !1 === n) return Object.entries(e).forEach((([e, n]) => {
            t.addEventListener(e, n)
        })), null == t || t._eventListenerReadyPromiseResolve(), () => {
            Object.entries(e).forEach((([e, n]) => {
                null == t || t.removeEventListener(e, n)
            }))
        }
    }), [t, n, e])
}
const Go = l.HTMLElement,
    Jo = e => {
        const t = l.HTMLElement;
        l.HTMLElement = Go;
        const n = e();
        return l.HTMLElement = t, n
    },
    Zo = e => Jo((() => t.createElement(e))),
    Qo = {
        boolean: {
            stringify: e => "" === e ? "true" : e ? /^[ty1-9]/i.test(e).toString() : "false",
            parse: (e, t, n) => "" === e || (e ? /^[ty1-9]/i.test(e) : n.hasAttribute(t) && null === e)
        },
        function: {
            stringify: e => "function" == typeof e ? e.name.replace("bound ", "") : "string" == typeof e ? e.replace("bound ", "") : e,
            parse: (e, t, n) => {
                if (!e) return null;
                const o = "undefined" != typeof window ? window[e] : "undefined" != typeof global ? global[e] : void 0;
                return "function" == typeof o ? o.bind(n) : void 0
            }
        },
        number: {
            stringify: e => `${e}`,
            parse: e => {
                if (e) return parseFloat(e)
            }
        },
        string: {
            stringify: e => e,
            parse: e => {
                if (e) return e
            }
        }
    };

function er(e, {
    methods: t,
    name: n,
    props: o,
    shadow: r
}) {
    var i;
    if ("undefined" == typeof window) return;
    const {
        notify: a
    } = new bn(n);

    function s() {
        const t = (e => Jo((() => Reflect.construct(HTMLElement, [], e))))(s);
        if (t._eventListenerReadyPromise = new Promise((e => {
                t._eventListenerReadyPromiseResolve = e
            })), t._vdomComponent = e, t._root = r ? t.attachShadow({
                mode: r
            }) : t, r) {
            const e = new CSSStyleSheet;
            e.replaceSync(bt), t._root.adoptedStyleSheets = [e]
        }
        return t
    }
    const l = new Map;
    Object.entries(o || {}).forEach((([e, t]) => {
        const n = En(e);
        l.set(n, {
            attribute: n,
            preactProp: e,
            type: t
        })
    }));
    const c = Array.from(l.values()).map((({
        attribute: e
    }) => e));

    function d(e) {
        this.getChildContext = () => e.context;
        const {
            context: t,
            children: n
        } = e;
        return le(n, v(e, ["context", "children"]))
    }

    function u(e) {
        return z("slot", Object.assign({}, e))
    }

    function p(e, t) {
        if (3 === e.nodeType) return e.data;
        if (1 !== e.nodeType) return null;
        const n = {},
            o = [],
            {
                childNodes: r
            } = e;
        l.forEach((({
            attribute: t,
            preactProp: o,
            type: r
        }) => {
            const i = Qo[r],
                a = e.getAttribute(t);
            let s = a;
            ("boolean" === r || a) && (s = i.parse(a, t, e)), null !== s && (n[t] = s, n[o] = s)
        }));
        for (const e of r) {
            const t = p(e, null);
            o.push(t)
        }
        const i = t ? z(u, null, o) : o;
        return z(t, n, i)
    }
    s.prototype = Object.create(HTMLElement.prototype), s.prototype.constructor = s, s.observedAttributes = c, s.prototype.attributeChangedCallback = function(e, t, n) {
        if (!this._vdom) return;
        const o = l.get(e);
        if (!o) return;
        const {
            preactProp: r,
            type: i
        } = o, a = Qo[i], s = {};
        if (n || "boolean" !== i) {
            if (i && n) {
                const t = a.parse(n, e, this);
                s[e] = t, s[r] = t
            }
        } else {
            const t = a.parse(n, e, this);
            s[e] = t, s[r] = t
        }
        this._vdom = le(this._vdom, s), se(this._vdom, this._root)
    }, s.prototype.connectedCallback = function() {
        const e = new CustomEvent("_preact", {
            detail: {},
            bubbles: !0,
            cancelable: !0
        });
        this.dispatchEvent(e);
        const t = e.detail.context;
        this._vdom = z(d, Object.assign(Object.assign({}, this._props), {
            context: t,
            element: this
        }), p(this, this._vdomComponent)), se(this._vdom, this._root)
    }, null == t || t.forEach((e => {
        s.prototype[e] = function(t) {
            this._eventListenerReadyPromise.then((() => {
                this.dispatchEvent(new CustomEvent(e, {
                    detail: t
                }))
            })).catch((() => {
                a(new Sn(`Custom element ${n}: Error listening for methods`, "CustomElementMethodListenerError"))
            }))
        }
    })), s.prototype.disconnectedCallback = function() {
        se(this._vdom = null, this._root)
    }, l.forEach((({
        attribute: e,
        type: t
    }) => {
        const n = Qo[t];
        Object.defineProperty(s.prototype, e, {
            get() {
                return this._vdom && this._vdom.props ? this._vdom.props[e] : null
            },
            set(o) {
                let r = o;
                this._vdom ? this.attributeChangedCallback(e, null, o) : (("boolean" === t || o) && (r = n.parse(o, e, this)), this._props || (this._props = {}), this._props[e] = r, this.connectedCallback()), this.setAttribute(e, n.stringify(r))
            }
        })
    }));
    return customElements.get(n) ? void 0 : (null === (i = Reflect.defineProperty) || void 0 === i || i.call(Reflect, s, "componentVersion", {
        value: "preact"
    }), ((e, t) => {
        Jo((() => {
            customElements.define(e, t)
        }))
    })(n, s))
}

function tr({
    className: e
}) {
    return ue("svg", {
        className: e,
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 50 50",
        children: [ue("path", {
            fill: "currentColor",
            d: "M50 12.5C50 5.597 44.403 0 37.5 0h-25C5.597 0 0 5.597 0 12.5v25C0 44.403 5.597 50 12.5 50h25C44.403 50 50 44.403 50 37.5v-25z"
        }), ue("path", {
            fill: "#fff",
            d: "M14.551 17.49v12.2a.09.09 0 0 0 .092.092h2.249a.091.091 0 0 0 .091-.091v-5.203c0-1.007.676-1.726 1.761-1.726 1.189 0 1.484.969 1.484 1.96v4.969a.09.09 0 0 0 .027.065.09.09 0 0 0 .066.026h2.24a.092.092 0 0 0 .09-.091v-5.266c0-.18-.007-.357-.022-.53a4.681 4.681 0 0 0-.416-1.628c-.52-1.084-1.505-1.785-2.989-1.785a2.989 2.989 0 0 0-2.336 1.195l-.056.066V17.49a.092.092 0 0 0-.091-.092h-2.098a.092.092 0 0 0-.092.092zm-3.441 6.862s-1.088-.256-1.489-.357c-.4-.102-1.101-.328-1.101-.848 0-.544.562-.696 1.138-.696.576 0 1.21.137 1.261.771a.09.09 0 0 0 .09.08l2.108-.008a.091.091 0 0 0 .086-.06.092.092 0 0 0 .005-.036c-.13-2.027-1.915-2.752-3.563-2.752-1.953 0-3.377 1.28-3.377 2.698 0 1.03.294 2 2.597 2.673.402.118.954.27 1.433.4.577.16.884.4.884.784 0 .443-.652.75-1.277.75-.916 0-1.567-.338-1.62-.946a.09.09 0 0 0-.09-.08l-2.104.01a.09.09 0 0 0-.066.028.092.092 0 0 0-.025.066c.096 1.914 1.951 2.945 3.68 2.945 2.57 0 3.74-1.45 3.74-2.796.003-.628-.143-2.075-2.31-2.627zm25.703-2.588V20.54a.088.088 0 0 0-.026-.064.09.09 0 0 0-.065-.027h-2.1a.09.09 0 0 0-.09.09v11.994a.088.088 0 0 0 .026.064.089.089 0 0 0 .065.026h2.249a.09.09 0 0 0 .09-.09v-3.937h.034c.356.542 1.334 1.192 2.608 1.192 2.401 0 4.397-1.98 4.397-4.66 0-2.569-1.984-4.651-4.51-4.651-1.125 0-2.069.62-2.677 1.369v-.082zm2.468 5.747c-1.292 0-2.32-1.072-2.32-2.38 0-1.308 1.027-2.368 2.32-2.368 1.294 0 2.33 1.06 2.33 2.368 0 1.308-1.036 2.38-2.33 2.38zm-11.406-7.554c-2.096 0-3.142.708-3.983 1.28l-.024.016a.205.205 0 0 0-.063.275l.867 1.487a.213.213 0 0 0 .322.056l.065-.054c.432-.36 1.086-.905 2.761-1.04.933-.074 1.74.176 2.33.72.653.601 1.044 1.57 1.044 2.594 0 1.88-1.114 3.064-2.902 3.088-1.474-.008-2.466-.774-2.466-1.906 0-.599.237-1.04.77-1.43a.207.207 0 0 0 .061-.263l-.744-1.402a.215.215 0 0 0-.297-.083c-.836.493-1.822 1.446-1.767 3.182.067 2.21 1.912 3.896 4.31 3.965h.273c2.85-.092 4.907-2.198 4.907-5.048 0-2.637-1.914-5.437-5.463-5.437z"
        })]
    })
}

function nr(...e) {
    return e.map((e => "object" == typeof e && "string" == typeof(null == e ? void 0 : e.value) ? e.value : e)).filter((e => "string" == typeof e)).join(" ")
}
const or = () => Ne(Ot);

function rr(e) {
    if (e.match(/\.shop\.dev$/) && !("web-shop-client.shop.dev" === e)) return "shop.dev";
    const t = e.match(/([^.]*[.]){2}(eu|us|asia).spin.dev/);
    return t && t.length ? t[0] : void 0
}
const ir = function(e) {
        const t = rr(e.hostname);
        return t ? {
            coreAuthDomain: `https://shop1.my.${t}`,
            payAuthDomain: `https://shop-server.${t}`,
            payAuthDomainAlt: `https://pay-shopify-com.${t}`
        } : {
            coreAuthDomain: e.origin,
            payAuthDomain: "https://shop.app",
            payAuthDomainAlt: "https://pay.shopify.com"
        }
    }(l.location),
    ar = ir.coreAuthDomain,
    sr = ir.payAuthDomain,
    lr = ir.payAuthDomainAlt;

function cr() {
    const {
        notify: e
    } = wt(), {
        element: t
    } = Mt();
    return Ae(((n, o, r = !1) => {
        t ? t.dispatchEvent(new CustomEvent(n, {
            bubbles: r,
            cancelable: !1,
            composed: !0,
            detail: o
        })) : e(new Error("dispatchEvent called without a reference to the custom element."))
    }), [t, e])
}

function dr(e, t) {
    try {
        const n = new l.URL(e).host.split(".").reverse(),
            o = new l.URL(t).host.split(".").reverse();
        for (let e = 0; e < Math.min(n.length, o.length); e++)
            if (n[e] !== o[e]) return !1;
        return !0
    } catch (e) {
        return !1
    }
}

function ur(e) {
    return !("string" != typeof e || !e) && RegExp(/^[^@]+@[^@]+\.[^@]{2,}$/i).test(e)
}

function pr(e) {
    const t = new l.URL(e);
    if (("localhost" === t.hostname || "127.0.0.1" === t.hostname) && "https:" !== t.protocol) throw new Error("using_localhost");
    if ("https:" !== t.protocol) throw new Error("not_using_https");
    if ("/" !== t.pathname) throw new Error("has_path");
    if (t.hash) throw new Error("has_hash");
    if (t.search) throw new Error("has_search");
    return !0
}

function hr({
    allowedOrigins: e,
    destination: t = l,
    handler: n,
    source: o
}) {
    const {
        trackPostMessageTransmission: r
    } = Et(), i = je((() => new Set), []);
    Me((() => (i.add(n), () => {
        i.delete(n)
    })), [n, i]), Me((() => {
        const e = e => function(e) {
            return "object" == typeof e && null !== e && "messageId" in e && "type" in e
        }(e) && r({
            direction: "incoming",
            event: e
        });
        return i.add(e), () => {
            i.delete(e)
        }
    }), [r, i]);
    const a = Ae((e => {
            i.forEach((t => t(e)))
        }), [i]),
        s = Ae((t => {
            const n = o.current instanceof HTMLIFrameElement ? o.current.contentWindow : o.current;
            (function(e, t) {
                return e.source === t
            })(t, n || null) && (e.some((e => dr(e, t.origin))) ? a(t.data) : console.error("Origin mismatch for message event", t))
        }), [e, a, o]),
        c = Ae((() => {
            t.removeEventListener("message", s, !1)
        }), [t, s]);
    Me((() => (t.addEventListener("message", s, !1), () => {
        c()
    })), [t, c, s]);
    const d = Ae(((e, t) => _(this, void 0, void 0, (function*() {
        let n;
        return new Promise(((o, r) => {
            function a() {
                r(new Sn("Abort signal received", "AbortSignalReceivedError"))
            }(null == t ? void 0 : t.aborted) && a(), n = n => {
                n.type === e && (null == t || t.removeEventListener("abort", a), o(n))
            }, i.add(n), null == t || t.addEventListener("abort", a)
        })).finally((() => {
            i.delete(n)
        }))
    }))), [i]);
    return {
        destroy: c,
        waitForMessage: d
    }
}

function fr(e) {
    var {
        includeCore: t,
        source: n,
        storefrontOrigin: o
    } = e, r = v(e, ["includeCore", "source", "storefrontOrigin"]);
    const i = cr(),
        a = Ae((e => _(this, void 0, void 0, (function*() {
            const {
                onAuthorizeStepChanged: t,
                onClose: n,
                onComplete: o,
                onConfirmSuccess: a,
                onContinueToCheckout: s,
                onCustomFlowSideEffect: l,
                onDiscountSaved: c,
                onEmailChangeRequested: d,
                onError: u,
                onLeadCaptureLoaded: p,
                onLoaded: h,
                onModalOpened: f,
                onPopUpOpened: m,
                onPrequalError: g,
                onPrequalMissingInformation: v,
                onPrequalReady: _,
                onPrequalSuccess: y,
                onProcessingStatusUpdated: w,
                onPromptChange: b,
                onPromptContinue: x,
                onResizeIframe: k,
                onRestarted: E,
                onShopUserMatched: S,
                onShopUserNotMatched: C,
                onStripeLinkUserFound: P,
                onUnloaded: M,
                onUserVerified: O,
                onVerificationStepChanged: T
            } = r;
            switch (e.type) {
                case "authorize_step_changed":
                    null == t || t(e);
                    break;
                case "close":
                case "close_requested":
                    null == n || n();
                    break;
                case "completed":
                    {
                        const {
                            avatar: t,
                            email: n,
                            givenName: r,
                            loggedIn: a,
                            shouldFinalizeLogin: s
                        } = e;o && (yield o(e)),
                        i("completed", e),
                        a && s && i("storefront:signincompleted", {
                            avatar: (() => {
                                const e = Zo("shop-user-avatar"),
                                    o = (null == r ? void 0 : r[0]) || (null == n ? void 0 : n[0]) || "";
                                return e.setAttribute("src", t || ""), e.setAttribute("initial", o), e
                            })()
                        }, !0);
                        break
                    }
                case "confirm_success":
                    null == a || a();
                    break;
                case "continue_to_checkout":
                    null == s || s();
                    break;
                case "custom_flow_side_effect":
                    null == l || l(e);
                    break;
                case "discount_saved":
                    null == c || c();
                    break;
                case "email_change_requested":
                    null == d || d();
                    break;
                case "error":
                    null == u || u(e), i("error", {
                        code: e.code,
                        message: e.message,
                        email: e.email
                    });
                    break;
                case "loaded":
                    i("loaded", e), "loginTitle" in e ? null == p || p(e) : null == h || h(e);
                    break;
                case "stripe_link_user_found":
                    null == P || P(e);
                    break;
                case "unloaded":
                    null == M || M(e);
                    break;
                case "modalopened":
                    null == f || f();
                    break;
                case "pop_up_opened":
                    null == m || m(e), i("popuploading", e);
                    break;
                case "processing_status_updated":
                    null == w || w();
                    break;
                case "prequal_error":
                    null == g || g();
                    break;
                case "prequal_missing_information":
                    null == v || v();
                    break;
                case "prequal_ready":
                    null == _ || _();
                    break;
                case "prequal_success":
                    null == y || y();
                    break;
                case "resize_iframe":
                    null == k || k(e);
                    break;
                case "restarted":
                    null == E || E(), i("restarted");
                    break;
                case "shop_user_matched":
                    null == S || S(e);
                    break;
                case "shop_user_not_matched":
                    null == C || C(e);
                    break;
                case "user_verified":
                    null == O || O(e);
                    break;
                case "verification_step_changed":
                    null == T || T(e);
                    break;
                case "prompt_change":
                    null == b || b();
                    break;
                case "prompt_continue":
                    null == x || x()
            }
        }))), [i, r]);
    return hr({
        allowedOrigins: je((() => [sr, lr, ...t ? [ar] : [], ...o ? [o] : []]), [t, o]),
        handler: a,
        source: n
    })
}
const mr = "temporarily_unavailable",
    gr = "Shop login is temporarily unavailable";

function vr() {
    const e = cr(),
        t = Te(null),
        n = Ae((() => {
            t.current && (clearTimeout(t.current), t.current = null)
        }), []);
    return {
        initLoadTimeout: Ae((() => {
            n(), t.current = setTimeout((() => {
                e("error", {
                    message: gr,
                    code: mr
                }), n()
            }), 1e4)
        }), [n, e]),
        clearLoadTimeout: n
    }
}

function _r(e) {
    const t = Te(e);
    return Me((() => {
        t.current = e
    })), t.current
}

function yr({
    contentWindow: e,
    event: t,
    onMessageSent: n
}) {
    if (!e) return;
    const o = [sr, lr],
        r = Object.assign(Object.assign({}, t), {
            messageId: a()
        });
    o.forEach((t => {
        e.postMessage(r, t)
    })), null == n || n(r)
}
class wr {
    constructor(e) {
        this._source = e
    }
    isSourceOf(e) {
        return e.source === this._source.contentWindow
    }
}
const br = ({
        iframe: e,
        src: t
    }) => {
        const n = null == e ? void 0 : e.parentNode;
        n && e && (n.removeChild(e), e.setAttribute("src", ""), e.setAttribute("src", t), n.appendChild(e))
    },
    xr = {
        mobile: ["max-width: 448px"],
        tablet: ["min-width: 449px", "max-width: 1000px", "max-height: 920px"]
    };

function kr() {
    const e = xr.mobile.every((e => l.matchMedia(`(${e})`).matches)),
        t = !e && xr.tablet.every((e => l.matchMedia(`(${e})`).matches));
    return {
        isMobile: e,
        isTablet: t,
        isDesktop: !e && !t
    }
}

function Er() {
    return Boolean(Ft.userAgent) && /(android|iphone|ipad|mobile|phone)/i.test(Ft.userAgent) || Cr()
}

function Sr(e) {
    return "/" === e ? e : e.endsWith("/") ? e.slice(0, -1) : e
}

function Cr() {
    return function() {
        const e = Ft.userAgent.toLowerCase();
        return e.includes("fban/fbios") || e.includes("fb_iab/fb4a")
    }() || Ft.userAgent.toLowerCase().includes("instagram") || Ft.userAgent.toLowerCase().includes("messenger") || function() {
        const e = Ft.userAgent;
        return RegExp(Mr).test(e) || RegExp(Or).test(e)
    }() || /Mozilla\/5.0 \([^)]*Android[^)]*; wv\).+Chrome\//.test(Ft.userAgent)
}

function Pr() {
    return Boolean("undefined" != typeof IntersectionObserver && IntersectionObserver)
}
const Mr = "(iPod|iPod touch|iPhone|iPad);.*CPU.*OS[ +](\\d+)_(\\d+)(?:_(\\d+)|).* AppleNews",
    Or = "(iPod|iPod touch|iPhone|iPad);.*CPU.*OS[ +](\\d+)_(\\d+)(?:_(\\d+)|)(?!.*Version).*Mobile(?!.*Safari)";

function Tr({
    className: e
}) {
    return ue("svg", {
        className: e,
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 20 20",
        children: ue("path", {
            fill: "currentColor",
            "fill-rule": "evenodd",
            d: "M0 10C0 4.477 4.477 0 10 0s10 4.477 10 10-4.477 10-10 10S0 15.523 0 10Zm7.707-3.707a1 1 0 0 0-1.414 1.414L8.586 10l-2.293 2.293a1 1 0 1 0 1.414 1.414L10 11.414l2.293 2.293a1 1 0 0 0 1.414-1.414L11.414 10l2.293-2.293a1 1 0 0 0-1.414-1.414L10 8.586 7.707 6.293Z",
            "clip-rule": "evenodd"
        })
    })
}
const Ir = '\n  a[href],\n  area[href],\n  input:not([type="hidden"]):not([disabled]):not([tabindex="-1"]),\n  select:not([disabled]),\n  textarea:not([disabled]),\n  button:not([disabled]):not([tabindex="-1"]),\n  iframe,\n  object,\n  embed,\n  [tabindex="0"],\n  [contenteditable],\n  audio[controls],\n  video[controls]';

function jr(e) {
    return e.querySelector(Ir)
}

function Ar(e) {
    const t = e.querySelectorAll(Ir);
    return t[t.length - 1]
}

function Nr({
    className: e
}) {
    return ue("svg", {
        className: e,
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 60 25",
        role: "img",
        children: [ue("title", {
            children: "Shop"
        }), ue("path", {
            fill: "currentColor",
            d: "M7.74 11.067c-2.35-.509-3.396-.708-3.396-1.612 0-.85.708-1.274 2.125-1.274 1.246 0 2.157.544 2.828 1.609.05.082.155.11.24.066l2.644-1.334a.186.186 0 0 0 .076-.259c-1.098-1.9-3.125-2.94-5.794-2.94-3.507 0-5.686 1.727-5.686 4.47 0 2.914 2.653 3.65 5.006 4.16 2.353.509 3.403.708 3.403 1.612 0 .904-.765 1.33-2.293 1.33-1.41 0-2.457-.644-3.09-1.896a.185.185 0 0 0-.25-.082L.916 16.222a.188.188 0 0 0-.082.253c1.046 2.102 3.194 3.284 6.062 3.284 3.653 0 5.86-1.697 5.86-4.526 0-2.83-2.666-3.65-5.015-4.16v-.006ZM21.909 5.324c-1.5 0-2.824.53-3.776 1.476a.093.093 0 0 1-.158-.067V.7a.185.185 0 0 0-.187-.186H14.48a.185.185 0 0 0-.187.186v18.728c0 .105.083.187.187.187h3.308a.185.185 0 0 0 .187-.187v-8.215c0-1.586 1.217-2.803 2.859-2.803 1.641 0 2.83 1.191 2.83 2.803v8.215c0 .105.082.187.187.187h3.308a.185.185 0 0 0 .186-.187v-8.215c0-3.451-2.264-5.888-5.436-5.888ZM34.056 4.786c-1.796 0-3.478.55-4.687 1.344a.187.187 0 0 0-.06.25l1.458 2.487c.054.089.168.12.256.066a5.812 5.812 0 0 1 3.04-.834c2.887 0 5.01 2.035 5.01 4.725 0 2.292-1.7 3.99-3.853 3.99-1.755 0-2.973-1.022-2.973-2.463 0-.825.351-1.501 1.265-1.979a.183.183 0 0 0 .073-.259L32.21 9.787a.186.186 0 0 0-.224-.08c-1.844.683-3.137 2.327-3.137 4.533 0 3.338 2.66 5.829 6.369 5.829 4.333 0 7.448-3 7.448-7.302 0-4.611-3.624-7.98-8.609-7.98ZM52.342 5.295c-1.673 0-3.169.62-4.26 1.707a.092.092 0 0 1-.158-.066V5.627a.185.185 0 0 0-.186-.186h-3.223a.185.185 0 0 0-.187.186v18.7c0 .104.082.186.187.186h3.308a.185.185 0 0 0 .187-.187v-6.131c0-.083.098-.124.158-.07 1.088 1.012 2.527 1.602 4.174 1.602 3.88 0 6.907-3.138 6.907-7.216 0-4.077-3.03-7.216-6.907-7.216Zm-.626 11.265c-2.207 0-3.88-1.754-3.88-4.074s1.67-4.074 3.88-4.074 3.877 1.726 3.877 4.074c0 2.349-1.644 4.074-3.88 4.074h.003Z"
        })]
    })
}
const Lr = Ke(((e, t) => {
    var {
        children: n,
        className: o,
        disableTransition: r = !1
    } = e, i = v(e, ["children", "className", "disableTransition"]);
    return ue("button", Object.assign({}, i, {
        className: nr("relative m-0 flex w-auto items-center overflow-visible rounded-login-button bg-purple-primary p-0 hover_enabled_bg-purple-d0 focus_enabled_outline-none focus_enabled_ring focus_enabled_ring-purple-l1 focus-visible_enabled_outline-none focus-visible_enabled_ring focus-visible_enabled_ring-purple-l1 disabled_opacity-50", !r && "transition-all", o),
        ref: t,
        type: "button",
        children: n
    }))
}));
Lr.displayName = "Button";
const Ur = Ke(((e, t) => {
    var {
        bordered: n,
        buttonClassName: o,
        children: r,
        className: i,
        fullWidth: a
    } = e, s = v(e, ["bordered", "buttonClassName", "children", "className", "fullWidth"]);
    return ue(Lr, Object.assign({}, s, {
        className: nr("m-auto", n ? "border border-solid border-white/20" : "border-none", a ? "w-full justify-center" : void 0, o),
        ref: t,
        children: ue("span", {
            className: nr("mx-auto flex cursor-pointer items-center justify-center gap-text-icon whitespace-nowrap p-shop-button font-sans text-branded-button text-white", i),
            children: r
        })
    }))
}));

function Dr() {
    return ue(Nr, {
        className: "flex aspect-branded-button-icon h-branded-button-icon w-auto translate-y-[9.375%] self-center"
    })
}
Ur.displayName = "BrandedButton", Dr.displayName = "BrandedButtonIcon";
const Rr = ({
        defaultUxMode: e,
        uxMode: t
    }) => je((() => {
        const n = Er();
        return "windoid" === t && n ? e : t
    }), [e, t]),
    zr = e => {
        if (void 0 !== e) return !1 === e ? "false" : "true"
    };

function $r({
    analyticsContext: e,
    analyticsTraceId: t,
    apiKey: n,
    avoidSdkSession: o,
    checkoutRedirectUrl: r,
    checkoutToken: i,
    checkoutVersion: a,
    clientId: s,
    codeChallenge: c,
    codeChallengeMethod: d,
    consentChallenge: u,
    ctx: p,
    disableSignUp: h,
    embed: f,
    error: m,
    experiments: g,
    flow: v,
    flowVersion: _,
    hideCopy: y,
    isCompactLayout: w = !0,
    isFullView: b,
    locale: x,
    loginHint: k,
    modalCustomized: E,
    orderId: S,
    origin: C,
    personalizeAds: P,
    prompt: M,
    placement: O,
    popUpFeatures: T,
    popUpName: I,
    redirectType: j,
    redirectUri: A,
    requireVerification: N,
    responseMode: L,
    responseType: U,
    returnUri: D,
    scope: R,
    shopId: z,
    shopifyEssential: $,
    state: F,
    storefrontDomain: B,
    transactionParams: H,
    uxMode: V,
    uxRole: W,
    hideButtons: q,
    hideHeader: K,
    accentColor: X,
    darkMode: Y
}) {
    const G = void 0 === h ? void 0 : !1 === h,
        J = Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({
            analytics_context: e,
            analytics_trace_id: t,
            avoid_sdk_session: zr(o),
            api_key: n,
            checkout_redirect_url: r,
            checkout_token: i,
            checkout_version: a,
            client_id: s,
            code_challenge: c,
            code_challenge_method: d,
            compact_layout: zr(w),
            consent_challenge: zr(u),
            ctx: p,
            "customize-modal": zr(E),
            embed: f
        }, m && {
            error: m
        }), g && {
            experiments: g
        }), {
            flow: v ? v.toString() : void 0,
            flow_version: _,
            full_view: zr(b),
            hide_copy: zr(y),
            locale: x
        }), k && {
            login_hint: k
        }), {
            order_id: S ? S.toString() : void 0,
            origin: C,
            personalize_ads: zr(P),
            hide_buttons: zr(q),
            hide_header: zr(K),
            accent_color: X,
            dark_mode: zr(Y),
            placement: O,
            pop_up_features: "pop_up" === j ? T : void 0,
            pop_up_name: "pop_up" === j ? I : void 0,
            preact: "true",
            prompt: M,
            redirect_type: j,
            redirect_uri: A || l.location.origin,
            require_verification: zr(N),
            response_mode: L || "web_message",
            response_type: U || "id_token"
        }), D && {
            return_uri: D
        }), {
            scope: R || "openid email profile",
            sign_up_enabled: zr(G),
            shop_id: z ? z.toString() : void 0,
            shopify_essential: $,
            state: F,
            storefront_domain: B,
            target_origin: l.location.origin,
            transaction_params: H,
            ux_mode: V,
            ux_role: W
        });
    return Object.keys(J).forEach((e => void 0 === J[e] && delete J[e])), new URLSearchParams(J)
}

function Fr(e) {
    if (!e.proxy && void 0 === (null == e ? void 0 : e.clientId)) return "";
    if (e.proxy) {
        if (e.proxyCoreIdp) {
            const t = function(e) {
                const t = $r(e),
                    n = new Set(["return_to", "locale", "login_hint", "login_hint_mode"]),
                    o = {},
                    r = {};
                "windoid" === e.uxMode && (o.display = "popup");
                for (const [e, i] of t.entries()) n.has(e) ? o[e] = i : r[e] = i;
                return Object.keys(r).length > 0 && (o.shop_params = new URLSearchParams(r).toString()), new URLSearchParams(o)
            }(e);
            return `${ar}/customer_authentication/login?${t}`
        } {
            const t = $r(e);
            return `${ar}/services/login_with_shop/authorize?${t}`
        }
    }
    const t = $r(e);
    if (function(e) {
            return "loginWithShopSelfServe" === e.analyticsContext && "iframe" !== e.uxMode && "prompt" !== e.uxRole
        }(e)) return `${sr}/oauth/authorize?${t}`;
    const n = e.avoidPayAltDomain ? "/pay/sdk-authorize" : "/pay/sdk-session";
    return `${sr}${n}?${t}`
}

function Br(e) {
    var {
        analyticsContext: t,
        avoidPayAltDomain: n = !1,
        avoidSdkSession: o = !1,
        disableSignUp: r = !1,
        experiments: i,
        proxy: a,
        clientId: s,
        flow: c = "default",
        flowVersion: d = "unspecified",
        error: u,
        prompt: p = "login",
        responseMode: h,
        storefrontDomain: f
    } = e, m = v(e, ["analyticsContext", "avoidPayAltDomain", "avoidSdkSession", "disableSignUp", "experiments", "proxy", "clientId", "flow", "flowVersion", "error", "prompt", "responseMode", "storefrontDomain"]);
    const {
        locale: g
    } = qo(), {
        instanceId: _
    } = Mt(), y = Ae((e => {
        if ("prompt" === (null == e ? void 0 : e.uxRole) && !a && s) return function({
            analyticsTraceId: e,
            clientId: t,
            flow: n,
            flowVersion: o,
            locale: r,
            storefrontDomain: i
        }) {
            const a = new URLSearchParams({
                analytics_trace_id: e,
                client_id: t,
                flow: n,
                flow_version: o,
                locale: r,
                target_origin: l.location.origin,
                storefront_domain: i
            });
            return `${sr}/accounts/pre_auth?${a}`
        }({
            analyticsTraceId: _,
            clientId: s,
            flow: c,
            flowVersion: d,
            locale: g,
            storefrontDomain: f
        });
        const i = function(e, t) {
                if ("redirect" === t) return "query";
                if ("windoid" === t) return "web_message";
                return e
            }(h, m.uxMode),
            v = function(e, t) {
                if ("redirect" === t && "loginWithShop" === e) return "loginWithShopClassicCustomerAccounts";
                return e
            }(t, m.uxMode);
        return Fr(Object.assign(Object.assign(Object.assign({
            analyticsContext: v,
            analyticsTraceId: _,
            avoidPayAltDomain: n,
            avoidSdkSession: o,
            clientId: s,
            disableSignUp: r,
            error: u,
            flow: c,
            flowVersion: d,
            locale: g,
            prompt: p,
            proxy: a,
            storefrontDomain: f
        }, i && {
            responseMode: i
        }), m), e))
    }), [t, n, o, s, r, u, c, d, _, g, p, m, a, h, f]);
    return {
        authorizeUrl: je((() => y()), [y]),
        getAuthorizeUrl: y
    }
}

function Hr(e = l.location.origin, t) {
    const n = `${e}/services/login_with_shop/finalize`;
    return fetch(n).catch(t)
}
const Vr = ({
    storefrontOrigin: e
}) => {
    const {
        notify: t
    } = wt(), {
        log: n
    } = Ct();
    return Ae((o => _(void 0, [o], void 0, (function*({
        loggedIn: o,
        shouldFinalizeLogin: r,
        redirectUri: i
    }) {
        o && r && (yield Hr(e, t)), i && (! function(e) {
            try {
                return "https:" === new l.URL(e).protocol
            } catch (e) {
                return !1
            }
        }(i) ? n({
            body: "Invalid redirect URI",
            attributes: {
                redirectUri: i,
                storefrontOrigin: e
            }
        }) : l.location.href = i)
    }))), [t, n, e])
};

function Wr() {
    if (! function() {
            const e = Ft.userAgent,
                t = Boolean(e.match(/iPad/i)) || Boolean(e.match(/iPhone/i)),
                n = Boolean(e.match(/WebKit/i));
            return t && n && !e.match(/CriOS/i)
        }()) return;
    const e = "shop-pay-safari-unzoom",
        n = t.getElementById(e);
    if (n) return n.focus();
    const o = t.createElement("input");
    o.id = e, o.style.fontSize = "16px", o.style.width = "1px", o.style.height = "1px", o.style.position = "fixed", o.style.bottom = "-1000px", o.style.right = "-1000px", o.style.transform = "translate(1000px, 1000px)", o.setAttribute("aria-hidden", "true"), t.body.appendChild(o), o.focus({
        preventScroll: !0
    })
}

function qr({
    email: e,
    emailInputSelector: n,
    hideChange: o,
    iframeRef: r,
    shouldListen: i = !0
}) {
    const {
        loaded: a,
        modalVisible: s
    } = or(), {
        leaveBreadcrumb: l,
        notify: c
    } = wt(), {
        trackUserAction: d
    } = Et(), {
        isFilledWithPasswordManager: u
    } = function({
        emailInputSelector: e
    }) {
        const [n, o] = Ce(), [r, i] = Ce();
        return Me((() => {
            var n;

            function r(e) {
                "password" === this.type ? i(e.timeStamp) : o(e.timeStamp)
            }
            if (e) {
                const o = t.querySelector(e);
                if (o) {
                    o.addEventListener("input", r);
                    const e = null === (n = o.form) || void 0 === n ? void 0 : n.querySelector('input[type="password"]');
                    return e && e instanceof HTMLInputElement && e.addEventListener("input", r), () => {
                        o.removeEventListener("input", r), e && e.removeEventListener("input", r)
                    }
                }
            }
        }), [e]), {
            isFilledWithPasswordManager: je((() => void 0 !== n && void 0 !== r && Math.abs(n - r) < 100), [n, r])
        }
    }({
        emailInputSelector: n
    }), p = Te(null), [h, f] = Ce(), [m, g] = Ce(), [v, y] = Ce(), w = Te(null), b = Te(""), x = je((() => new Set), []), k = Ae(((e, ...t) => _(this, [e, ...t], void 0, (function*(e, t = "", n = "") {
        var i, h;
        const m = ur(e);
        if (u && !x.has("PASSWORD_MANAGER_AUTOFILL_DETECTED") && (x.add("PASSWORD_MANAGER_AUTOFILL_DETECTED"), d({
                userAction: "PASSWORD_MANAGER_AUTOFILL_DETECTED"
            })), m && !x.has("EMAIL_ENTERED") && (x.add("EMAIL_ENTERED"), d({
                userAction: "EMAIL_ENTERED"
            })), l("email entered", {}, "state"), !r.current || s) return;
        if (!a) return;
        const g = m ? e : "";
        p.current && !(null === (i = p.current) || void 0 === i ? void 0 : i.signal.aborted) && p.current.abort(), p.current = new AbortController;
        try {
            const {
                open: e,
                postMessage: i,
                waitForMessage: a
            } = r.current;
            b.current = g, i({
                firstName: t,
                lastName: n,
                type: "namesubmitted"
            }), i({
                email: g,
                hideChange: void 0 === o ? g.length > 0 : o,
                type: "emailsubmitted"
            }), l("email submitted", {
                email: g ? "redacted" : ""
            }, "state");
            const s = a("shop_user_matched", p.current.signal),
                c = new Promise(((e, t) => {
                    const n = () => _(this, void 0, void 0, (function*() {
                        try {
                            const t = yield a("error", p.current.signal);
                            "error" === t.type && "captcha_challenge" === t.code ? e(void 0) : yield n()
                        } catch (e) {
                            t(e)
                        }
                    }));
                    n()
                }));
            yield Promise.race([s, c]), e("event_shop_user_matched"), null === (h = null == w ? void 0 : w.current) || void 0 === h || h.blur(), Wr(), p.current.abort(), f(void 0)
        } catch (e) {
            if (e instanceof Sn && "AbortSignalReceivedError" === e.name) return;
            e instanceof Error && c(new Error(`Error updating user info: ${e.name} - ${e.message}`))
        }
    }))), [o, r, u, l, a, s, c, d, x]), E = Dn(((e, t, n) => {
        k(e, t, n)
    }), 200);
    Me((() => {
        void 0 !== h && a && E(h, m, v)
    }), [E, h, a, m, v]), Me((() => {
        if (!n) return;
        const e = t.querySelector(n);
        if (!e) return;
        w.current = e;
        const o = () => {
            e && f(e.value)
        };
        if ((null == e ? void 0 : e.value) && o(), i) return null == e || e.addEventListener("input", o), () => {
            null == e || e.removeEventListener("input", o)
        };
        null == e || e.removeEventListener("input", o)
    }), [n, i]), Me((() => {
        void 0 !== e && f(e)
    }), [e]);
    return {
        getSubmittedEmail: () => b.current,
        updateEmailToPost: e => f(e || ""),
        updateNamesToPost: (e, t) => ((e = "", t = "") => {
            g(e), y(t)
        })(e, t)
    }
}
const Kr = ({
        handleClose: e,
        handleComplete: t,
        handleError: n,
        handleOpen: o,
        windoidRef: r,
        handleCustomFlowSideEffect: i
    }) => {
        const a = cr();
        return Ae((s => _(void 0, void 0, void 0, (function*() {
            var l, c, d, u;
            switch (s.data.type) {
                case "completed":
                    t(s.data), a("completed", s.data, !0), null === (l = r.current) || void 0 === l || l.close();
                    break;
                case "custom_flow_side_effect":
                    null == i || i(s.data);
                    break;
                case "error":
                    null == n || n(s.data), a("error", s.data), null === (c = r.current) || void 0 === c || c.close();
                    break;
                case "windoidopened":
                    a("windoidopened"), null == o || o();
                    break;
                case "close":
                case "windoidclosed":
                    a("windoidclosed"), null == e || e(), null === (d = r.current) || void 0 === d || d.close();
                    break;
                case "prequal_buyer_upsert_successful":
                    null === (u = r.current) || void 0 === u || u.close(), a("buyerOnboardingSuccess")
            }
        }))), [a, t, e, i, n, o, r])
    },
    Xr = ({
        getAuthorizeUrl: e,
        getEmail: t,
        iframeRef: n,
        openWindoid: o
    }) => {
        const {
            trackUserAction: r
        } = Et();
        return Ae((() => {
            var i;
            r({
                userAction: "SIGN_IN_WITH_SHOP_PROMPT_CONTINUE_CLICK"
            }), null === (i = null == n ? void 0 : n.current) || void 0 === i || i.close({
                dismissMethod: "windoid_continue",
                reason: "user_prompt_continue_clicked"
            });
            const a = t(),
                s = e(Object.assign(Object.assign({}, a && {
                    loginHint: a
                }), {
                    origin: "preauth_prompt",
                    prompt: void 0
                }));
            o(s)
        }), [e, t, n, o, r])
    },
    Yr = {},
    Gr = (e, n, o = "SignInWithShop") => {
        var r;
        const i = ((e, n) => {
            const o = void 0 === l.screenLeft ? l.screenX : l.screenLeft,
                r = void 0 === l.screenTop ? l.screenY : l.screenTop;
            let i, a;
            i = l.innerWidth ? l.innerWidth : t.documentElement.clientWidth ? t.documentElement.clientWidth : screen.width, a = l.innerHeight ? l.innerHeight : t.documentElement.clientHeight ? t.documentElement.clientHeight : screen.height;
            const s = Math.max(1, i / l.screen.availWidth);
            return {
                height: n / s,
                left: (i - e) / 2 / s + o,
                top: (a - n) / 2 / s + r,
                width: e / s
            }
        })(365, 554);
        null === (r = Yr[o]) || void 0 === r || r.call(Yr);
        const a = l.open(e, "SignInWithShop", `popup,width=${i.width},height=${i.height},top=${i.top},left=${i.left}`),
            s = () => (e => {
                null == e || e.close()
            })(a);
        n(new MessageEvent("message", {
            data: {
                type: "windoidopened"
            }
        }));
        const c = setInterval((() => {
            (null == a ? void 0 : a.closed) && (n(new MessageEvent("message", {
                data: {
                    type: "windoidclosed"
                }
            })), clearInterval(c))
        }), 200);
        return ["beforeunload", "unload", "pagehide"].forEach((e => {
            l.addEventListener(e, s, {
                once: !0
            })
        })), l.addEventListener("message", n), Yr[o] = () => {
            ["beforeunload", "unload", "pagehide"].forEach((e => {
                l.removeEventListener(e, s)
            })), l.removeEventListener("message", n), clearInterval(c)
        }, a
    };

function Jr(e, t) {
    const n = ei(e),
        o = ei(t);
    return (Math.max(n, o) + .05) / (Math.min(n, o) + .05)
}

function Zr(e) {
    let t = 0,
        n = 0,
        o = 0;
    return 4 === e.length ? (t = Number(`0x${e[1]}${e[1]}`), n = Number(`0x${e[2]}${e[2]}`), o = Number(`0x${e[3]}${e[3]}`)) : 7 === e.length && (t = Number(`0x${e[1]}${e[2]}`), n = Number(`0x${e[3]}${e[4]}`), o = Number(`0x${e[5]}${e[6]}`)), [t, n, o]
}

function Qr(e) {
    var n;
    if (!e) return "#ffffff";
    const o = null === (n = l.getComputedStyle(e).getPropertyValue("--color-background")) || void 0 === n ? void 0 : n.trim();
    if (o) return o;
    for (const n of function*(e) {
            let n = e;
            for (; n;) {
                if (n.parentElement) n = n.parentElement;
                else if (n instanceof ShadowRoot) n = n.host;
                else {
                    if (!(n instanceof Element)) break; {
                        const e = n.getRootNode();
                        if (!(e instanceof ShadowRoot)) break;
                        n = e.host
                    }
                }
                if (yield n, n === t.body) break
            }
        }(e)) {
        const e = l.getComputedStyle(n).getPropertyValue("background-color");
        if (e && "rgba(0, 0, 0, 0)" !== e) return e
    }
    return "#ffffff"
}

function ei(e) {
    const t = [e[0], e[1], e[2]].map((function(e) {
        const t = e / 255;
        return t <= .03928 ? t / 12.92 : Math.pow((t + .055) / 1.055, 2.4)
    }));
    return .2126 * t[0] + .7152 * t[1] + .0722 * t[2]
}

function ti(e) {
    const t = e.match(/\d+/g) || [],
        [n = 0, o = 0, r = 0] = t.map((e => Number(e)));
    return [n, o, r]
}

function ni(e) {
    return e <= .04045 ? e / 12.92 : Math.pow((e + .055) / 1.055, 2.4)
}

function oi(e) {
    let t;
    if (e.startsWith("#") && (t = Zr(e)), e.startsWith("rgb(") && (t = ti(e)), !t) return !1;
    const n = function(e) {
        return e <= 216 / 24389 ? e * (24389 / 27) : 116 * Math.pow(e, 1 / 3) - 16
    }(function(e) {
        return .2126 * ni(e[0]) + .7152 * ni(e[1]) + .0722 * ni(e[2])
    }([t[0] / 255, t[1] / 255, t[2] / 255]));
    return n < 50
}

function ri({
    source: e
}) {
    const {
        notify: t
    } = wt(), {
        recordCounter: n
    } = Ct(), o = Ae((e => {
        "completed" === e.type && (n("shop_js_cart_sync_finalize_fetch"), function({
            onError: e,
            onResolve: t
        }) {
            fetch(`${l.location.origin}/services/login_with_shop/buyer/finalize`).then((e => t(e.status))).catch((t => e(t)))
        }({
            onError: e => {
                const o = function(e) {
                    if (e instanceof Error) return e;
                    switch (typeof e) {
                        case "string":
                            return new Error(e);
                        case "object":
                            return "message" in e ? new Error(e.message) : new Error(JSON.stringify(e));
                        default:
                            return new Error(String(e))
                    }
                }(e);
                n("shop_js_cart_sync_finalize_error"), t(o)
            },
            onResolve: e => {
                n("shop_js_cart_sync_finalize_resolve", {
                    attributes: {
                        status: e
                    }
                })
            }
        }))
    }), [t, n]), {
        destroy: r
    } = hr({
        allowedOrigins: [sr, l.location.origin],
        handler: o,
        source: e
    });
    return {
        destroy: r
    }
}
const ii = e => {
    const {
        log: t
    } = Ct(), n = Te(null), {
        instanceId: o
    } = Mt(), {
        destroy: r
    } = ri({
        source: n
    });
    Me((() => {
        const e = n.current;
        return () => {
            e && r()
        }
    }), [r]);
    const i = je((() => {
        var e, n;
        const r = l.location.origin,
            i = null === (e = l.Shopify) || void 0 === e ? void 0 : e.shop;
        if (!i) return t({
            body: "Missing Shopify domain from window.Shopify",
            attributes: {
                analyticsTraceId: o,
                domain: l.location.origin
            }
        }), "";
        if (null === (n = l.Shopify) || void 0 === n ? void 0 : n.designMode) return "";
        const a = new URLSearchParams({
            analytics_trace_id: o,
            target_origin: r,
            client_handle: i
        });
        return `${sr}/pay/hop?${a}`
    }), [o, t]);
    return ue("iframe", {
        className: "hidden",
        "data-testid": "shop-cart-sync-iframe",
        ref: n,
        src: i
    })
};
er((e => {
    var {
        element: t
    } = e, n = v(e, ["element"]);
    return ue(Ho, {
        element: t,
        featureName: "ShopCartSync",
        children: ue(ii, Object.assign({}, n))
    })
}), {
    name: "shop-cart-sync",
    shadow: "open"
});
const ai = e => {
    const t = e || l.location.origin;
    try {
        return new l.URL(t).hostname
    } catch (e) {
        return console.error(`[Shop Pay] Store URL (${t}) is not valid`, e), null
    }
};

function si({
    channel: e,
    paymentOption: t,
    source: n,
    sourceToken: o,
    storeUrl: r,
    variants: i
}) {
    const a = ai(r);
    if (!a) return "#";
    let s = new l.URL(`https://${a}/checkout`);
    if (i) {
        const e = i.split(",").map((e => {
                const [t, n] = e.split(":"), o = n ? Number(n) : 1;
                return {
                    id: Number(t),
                    quantity: isNaN(o) ? 1 : o
                }
            })),
            t = e.map((e => `${e.id}:${e.quantity}`)).join(",");
        s = new l.URL(`https://${a}/cart/${t}`)
    }
    const c = new URLSearchParams(s.search);
    return c.append("payment", t || "shop_pay"), n && c.append("source", n), o && c.append("source_token", o), e && c.append("channel", e), `${s.href}?${c}`
}

function li(e, t) {
    Boolean(l.customElements) && (l.Shopify || (l.Shopify = {}), l.Shopify.SignInWithShop || (l.Shopify.SignInWithShop = {}), l.Shopify.SignInWithShop[e] = t)
}

function ci() {
    var e;
    const n = null === (e = t.querySelector("script#shop-js-features")) || void 0 === e ? void 0 : e.innerHTML;
    return n ? JSON.parse(n) : {}
}
const di = new Error("Operation aborted");

function ui(e) {
    return _(this, arguments, void 0, (function*(e, t = {}, {
        maxRetries: n = 3,
        retryDelay: o = 1e3,
        signal: r
    } = {}) {
        try {
            if (null == r ? void 0 : r.aborted) return Promise.reject(di);
            const n = yield fetch(e, t);
            if (!n.ok) throw new Error(`HTTP error! status: ${n.status}`);
            return n
        } catch (i) {
            if (null == r ? void 0 : r.aborted) return Promise.reject(di);
            if (n - 1 > 0) return yield new Promise((e => setTimeout(e, o))), (null == r ? void 0 : r.aborted) ? Promise.reject(di) : ui(e, t, {
                maxRetries: n - 1,
                retryDelay: o,
                signal: r
            });
            throw i
        }
    }))
}
class pi extends Error {
    constructor() {
        super("FedCM is not supported")
    }
}
class hi extends Error {
    constructor() {
        super("FedCM was cancelled")
    }
}
const fi = e => _(void 0, void 0, void 0, (function*() {
    if (!("IdentityCredential" in l)) throw new pi;
    const {
        mediation: t = "optional",
        analyticsTraceId: n,
        monorailTracker: o,
        signal: r
    } = e, i = yield function(e) {
        return _(this, void 0, void 0, (function*() {
            let t = "/services/login_with_shop/fedcm/provider";
            e && (t += `?analytics_trace_id=${encodeURIComponent(e)}`);
            try {
                const e = yield ui(t, {
                    method: "GET"
                }, {
                    maxRetries: 5,
                    retryDelay: 1e3
                }), n = yield e.json();
                return {
                    configURL: n.configURL,
                    clientId: n.clientId,
                    state: n.state,
                    nonce: n.nonce,
                    params: {
                        nonce: n.nonce
                    }
                }
            } catch (e) {
                throw new Sn("Failed to fetch FedCM Provider", "FetchFedCMProviderError")
            }
        }))
    }(n);
    if (!i) return;
    const a = yield function(e, t, n) {
        return Ft.credentials.get({
            identity: {
                providers: [t]
            },
            mediation: e,
            signal: n
        })
    }(t, i, r);
    if (!a) throw null == o || o.trackUserAction({
        userAction: "FEDCM_CANCELLED"
    }), new hi;
    return function(e, t, n) {
        return _(this, void 0, void 0, (function*() {
            try {
                const o = yield ui("/services/login_with_shop/fedcm/callback", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded"
                    },
                    body: new URLSearchParams({
                        raw_id_token: e,
                        state: t
                    }).toString()
                }, {
                    maxRetries: 5,
                    retryDelay: 1e3
                });
                return null == n || n.trackUserAction({
                    userAction: "FEDCM_COMPLETED"
                }), o
            } catch (e) {
                throw new Sn("Failed to fetch FedCM Callback", "FetchFedCMPCallbackError")
            }
        }))
    }(null == a ? void 0 : a.token, i.state, o)
}));

function mi({
    onElementFound: e,
    selector: n
}) {
    const o = new WeakSet,
        r = new MutationObserver((e => {
            let t = !1;
            for (const n of e)
                if (n.addedNodes.length > 0) {
                    t = !0;
                    break
                }
            t && i()
        }));

    function i() {
        t.querySelectorAll(n).forEach((t => {
            o.has(t) || (e(t), o.add(t))
        }))
    }
    return function() {
        _(this, void 0, void 0, (function*() {
            yield function() {
                if (t.body) return Promise.resolve();
                return new Promise((e => {
                    l.addEventListener("DOMContentLoaded", (() => e()))
                }))
            }(), i(), r.observe(t.body || t.documentElement, {
                childList: !0,
                subtree: !0
            })
        }))
    }(), r
}

function gi({
    onFallback: e,
    onVisible: t
}) {
    const n = new IntersectionObserver((r => {
        for (const i of r) {
            const {
                isIntersecting: r,
                target: a
            } = i;
            r && (o(a) ? t(a) : e(a), n.unobserve(a))
        }
    }), {
        threshold: 1
    });

    function o(e) {
        let t = e;
        for (; t;) {
            if (!["", "1"].includes(getComputedStyle(t).opacity)) return !1;
            t = t.parentElement
        }
        return !0
    }
    return n
}
var vi, _i;
class yi {
    constructor(e, t) {
        vi.set(this, void 0), _i.set(this, void 0), e && (w(this, vi, e, "f"), w(this, _i, (e => {
            t(e.target.value)
        }), "f"), y(this, vi, "f").addEventListener("input", y(this, _i, "f")))
    }
    destroy() {
        y(this, vi, "f") && y(this, _i, "f") && y(this, vi, "f").removeEventListener("input", y(this, _i, "f"))
    }
}
vi = new WeakMap, _i = new WeakMap;
const wi = "shop-toast-manager";

function bi(e) {
    let n = t.querySelector(wi);
    n || (n = t.createElement(wi), t.body.appendChild(n)), customElements.whenDefined(wi).then((() => {
        n.renderToast(e)
    })).catch((() => {}))
}
li("renderToast", bi);
export {
    rt as $, Te as A, _ as B, Tr as C, Ke as D, Sn as E, Ie as F, yr as G, Pn as H, er as I, Rr as J, qr as K, Yo as L, Vr as M, g as N, m as O, xt as P, e as Q, Ho as R, tr as S, je as T, Br as U, Kr as V, Gr as W, Dn as X, Xr as Y, Dr as Z, v as _, so as a, Ur as a0, Er as a1, h as a2, ce as a3, Ne as a4, Pe as a5, ur as a6, Wr as a7, qo as a8, $r as a9, hi as aA, d as aB, En as aC, pr as aD, Hr as aE, Zr as aF, ti as aG, Jr as aH, ar as aI, hr as aJ, Lr as aK, kn as aL, si as aM, ai as aN, zr as aO, sr as aa, Qr as ab, oi as ac, rr as ad, Cr as ae, a as af, Fr as ag, li as ah, lr as ai, bn as aj, dr as ak, wr as al, pn as am, mn as an, zo as ao, Ao as ap, Ft as aq, Zo as ar, ci as as, fi as at, gi as au, mi as av, yi as aw, u as ax, Sr as ay, pi as az, Oe as b, Ar as c, Ce as d, or as e, jr as f, Xo as g, Mt as h, l as i, t as j, F as k, Pr as l, kr as m, nr as n, wt as o, cr as p, Ae as q, vr as r, Et as s, Ct as t, ue as u, _r as v, fr as w, Nr as x, Me as y, br as z
};
//# sourceMappingURL=chunk.common_CUHEfi5Q.esm.js.map