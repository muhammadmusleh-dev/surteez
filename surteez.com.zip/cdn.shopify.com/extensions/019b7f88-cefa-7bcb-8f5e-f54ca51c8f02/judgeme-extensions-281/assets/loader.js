(function() {
    function S() {
        return window.location.search.includes("jdgm_debug=true")
    }
    const b = S();

    function n(...e) {
        b && console.log(...e)
    }
    window.jdgm = window.jdgm || {}, window.jdgm.debugLog = n, n("[Judge.me Widget Loader] Script loaded and executing...");
    const L = ".jdgm-widget[data-entry-point]",
        w = document.querySelectorAll(L);
    if (w.length === 0) {
        n("[Judge.me Widget Loader] No containers found with selector:", L);
        return
    }
    n("[Judge.me Widget Loader] Found " + w.length + " container(s), processing each...");
    const v = new Set,
        l = {
            REVIEW: "review",
            ALL_REVIEWS_V2025: "all-reviews-v2025",
            CAROUSEL: "carousel"
        },
        _ = {
            review: l.REVIEW,
            "all-reviews-v2025": l.ALL_REVIEWS_V2025,
            "testimonials-carousel": l.CAROUSEL,
            "cards-carousel": l.CAROUSEL
        };

    function I(e) {
        const t = e.dataset.widget;
        return _[t] || null
    }

    function J(e) {
        const t = e.querySelector(".jdgm-legacy-widget-content");
        return t ? t.innerHTML.trim().length > 20 : !1
    }

    function V(e, t) {
        if (t === l.ALL_REVIEWS_V2025) {
            const a = window.jdgm ? .data ? .allReviewsWidgetV2025;
            return !!(a && Object.keys(a).length > 0)
        }
        const o = e.dataset.productId,
            c = window.jdgm ? .data ? .reviewWidget ? .[o];
        return !!(c && c.reviews !== void 0)
    }

    function h(e, t, o) {
        const c = window.jdgmSettings ? .[t],
            a = e.dataset.productId,
            r = J(e),
            s = V(e, o);
        let i = null,
            d = "",
            g = "",
            m = !1;
        return c ? s ? (m = !0, r ? (i = 1, d = "Revamp enabled + both data sources available", g = "Loading revamp widget (preferred)") : (i = 3, d = "Revamp enabled + only revamp data", g = "Loading revamp widget (only option available)")) : r ? (i = 2, d = "Revamp enabled + only legacy data", g = "Falling back to legacy widget (revamp data not available)", m = !1) : (i = "edge-revamp-no-data", d = "Revamp enabled + no data sources", g = "Loading revamp widget for empty state", m = !0) : r ? (m = !1, s ? (i = 4, d = "Revamp disabled + both data sources available", g = "Showing legacy widget (preferred)") : (i = 6, d = "Revamp disabled + only legacy data", g = "Showing legacy widget (only option available)")) : s ? (i = 5, d = "Revamp disabled + only revamp data", g = "Falling back to revamp widget (legacy not available)", m = !0) : (i = "edge-no-data", d = "Revamp disabled + no data sources", g = "No widget will be shown (no data available)", m = !1), {
            scenarioId: i,
            scenarioName: d,
            decision: g,
            shouldLoadRevamp: m,
            metadata: {
                productId: a,
                revampEnabled: c,
                hasLegacyData: r,
                hasRevampData: s
            }
        }
    }

    function E(e, t, o, c) {
        n("[Judge.me Widget Loader] " + o + " - Scenario " + t.scenarioId + ": " + t.scenarioName), n("[Judge.me Widget Loader] " + o + " - Decision:", t.decision), n("[Judge.me Widget Loader] " + o + " - Debug info:", { ...t.metadata,
            willLoadRevamp: t.shouldLoadRevamp
        });
        let a;
        c === l.ALL_REVIEWS_V2025 ? a = window.jdgm ? .data ? .allReviewsWidgetV2025 : a = window.jdgm ? .data ? .reviewWidget ? .[t.metadata.productId];
        const r = !!a;
        t.metadata.hasRevampData !== r && (console.warn("[Judge.me Widget Loader] ⚠️ Data mismatch detected!!"), console.warn("[Judge.me Widget Loader] Liquid says hasRevamp:", t.metadata.hasRevampData), console.warn("[Judge.me Widget Loader] JavaScript sees data:", r), console.warn("[Judge.me Widget Loader] Actual data:", a));
        const s = e.querySelector(".jdgm-legacy-widget-content");
        if (s) {
            const i = s.innerHTML.trim().length;
            if (i > 0 && i <= 20) {
                const d = s.innerHTML.trim().substring(0, 50);
                n("[Judge.me Widget Loader] 📏 Legacy widget is small (" + i + ' chars), treating as empty. Content: "' + d + '"')
            }
        }
    }

    function W(e) {
        const t = e.querySelector(".jdgm-legacy-widget-content");
        t && (t.style.display = ""), n("[Judge.me Widget Loader] ✅ Legacy widget displayed")
    }

    function y(e) {
        const t = e.dataset.entryPoint,
            o = e.dataset.entryKey;
        if (!t || !o) {
            n("[Judge.me Widget Loader] ⚠️ Missing entryPoint or entryKey, skipping container");
            return
        }
        const c = window.jdgm.CDN_BASE_URL,
            a = c + t,
            r = e.querySelector(".jdgm-rev-widg");
        if (r && (r.style.display = "none", n("[Judge.me Widget Loader] 🙈 Hidden legacy widget element (.jdgm-rev-widg)")), n("[Judge.me Widget Loader] ⏳ Loading revamp widget:", t), v.has(a) || document.querySelector('script[src="' + a + '"]')) {
            n("[Judge.me Widget Loader] ⏭️ Script already loaded, skipping:", t);
            return
        }
        v.add(a), C(c, o, t).finally(() => {
            const s = document.createElement("script");
            s.type = "module", s.src = a, s.onload = () => {
                n("[Judge.me Widget Loader] ✅ Revamp widget script loaded successfully:", t)
            }, s.onerror = () => {
                console.error("[Judge.me Widget Loader] ❌ Failed to load revamp widget script:", t)
            }, document.head.appendChild(s)
        })
    }
    async function C(e, t, o) {
        if (!(e + o).includes("localhost")) try {
            let g = function(m) {
                const u = i[m];
                u && (u.css && u.css.forEach(p => {
                    const R = e + p;
                    if (!document.querySelector('link[href="' + R + '"]')) {
                        const f = document.createElement("link");
                        f.rel = "stylesheet", f.href = R, document.head.appendChild(f)
                    }
                }), u.imports && u.imports.forEach(g))
            };
            var a = g;
            const r = e + "manifest.json?v=" + Date.now(),
                i = await (await fetch(r)).json(),
                d = i[t];
            d && d.css && d.css.forEach(m => {
                const u = e + m;
                if (!document.querySelector('link[href="' + u + '"]')) {
                    const p = document.createElement("link");
                    p.rel = "stylesheet", p.href = u, document.head.appendChild(p)
                }
            }), d && d.imports && d.imports.forEach(g)
        } catch (r) {
            console.warn("Could not load manifest or CSS files:", r)
        }
    }
    w.forEach((e, t) => {
        const o = I(e),
            c = e.dataset.entryPoint;
        if (n("[Judge.me Widget Loader] Processing container " + (t + 1) + "/" + w.length + " - Type: " + o + ", Entry: " + c), !o) {
            n("[Judge.me Widget Loader] ⏭️ Unknown widget type, skipping container");
            return
        }
        switch (o) {
            case l.REVIEW:
                {
                    const a = h(e, "review_widget_revamp_enabled", l.REVIEW);E(e, a, "Review Widget", l.REVIEW),
                    a.shouldLoadRevamp ? y(e) : W(e);
                    break
                }
            case l.ALL_REVIEWS_V2025:
                {
                    const a = h(e, "all_reviews_widget_v2025_enabled", l.ALL_REVIEWS_V2025);E(e, a, "All Reviews V2025 Widget", l.ALL_REVIEWS_V2025),
                    a.shouldLoadRevamp ? y(e) : W(e);
                    break
                }
            case l.CAROUSEL:
                n("[Judge.me Widget Loader] Carousel widget - always loading revamp"), y(e);
                break
        }
    })
})();